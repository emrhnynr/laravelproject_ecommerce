<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ProductFeatures extends Model
{
    

    protected $table = 'productfeatures';
    protected $guarded = [];
    protected $primaryKey = 'feature_id';
    public $timestamps = false;


}
