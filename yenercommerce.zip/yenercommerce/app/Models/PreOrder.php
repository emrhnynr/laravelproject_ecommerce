<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PreOrder extends Model
{
    protected $table = 'preorder';
    protected $guarded = [];
    protected $primaryKey = 'preorder_id';
}
