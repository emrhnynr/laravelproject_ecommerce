<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Auth;
use App\Models\Category;
use App\Models\CartProduct;
use App\Models\User;




class AppServiceProvider extends ServiceProvider
{
    
    public function register()
    {
        //
    }

   
    public function boot()
    {

    	 view()->composer('*', function($view)
         {

         if (Auth::guard('user')->check()) {

            $count_cart_products = count(CartProduct::where('user_id','=',Auth::guard('user')->user()->user_id)->get());

            $view->with('count_cart_products', $count_cart_products);
            $view->with('user', Auth::guard('user')->user());
            

        } else {

            $user_ip = $_SERVER['REMOTE_ADDR'];

            $count_cart_products = count(CartProduct::where('user_ip','=',$user_ip)->get());

            $view->with('count_cart_products', $count_cart_products);
            $view->with('user', null);
        }

         });

         //Fetched authenticated user to all pages above.


         $settings = DB::table('settings')->first(); //General Settings

         $top_categories = Category::where('category_top','=','0')->where('category_active','=','1')->orderBy('category_order','ASC')->get(); //Categories Schema

         View::share(['settings' => $settings, 'top_categories' => $top_categories]);
         




        
    }
}
