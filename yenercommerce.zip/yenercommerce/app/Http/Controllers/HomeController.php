<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Homelist;

class HomeController extends Controller
{
    
    public function home(){

  $homelist = Homelist::orderBy('list_order')->get();

  return view('home', compact('homelist'));

    }

}
