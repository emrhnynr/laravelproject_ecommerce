<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use App\Models\User;
use App\Models\Product;
use App\Models\CartProduct;
use App\Models\PreOrder;
use App\Models\Order;
use App\Models\OrderProduct;
use App\Models\Favourite;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Mail;
use App\Mail\UserSignupMail;


class UserController extends Controller
{
    
    public function signin(){

    return view('signin');

    }


    public function signup(){

    
    return view('signup');

    }


    public function signup_process(Request $request){

    $this->validate(request(),[

    'user_name' => 'required|min:2|max:100',
    'user_surname' => 'required|min:2|max:100',
    'user_email' => 'required|min:6|max:150|email', 
    'user_password' => 'required|confirmed|min:8|max:100'

    ]);

    $mailcheck = User::where('user_email','=',trim(request('user_email')))->first();
 	
 	  if ($mailcheck != null) {
 		
 		echo 'existmail';
 		exit;

 	  }


    $user_name = trim(request('user_name'));
    $user_surname = trim(request('user_surname'));
    $user_email = trim(request('user_email'));
    $user_password = bcrypt(request('user_password'));
    $user_activationcode = Str::random(60);


    $user = User::create([

  	'user_name' => $user_name,
  	'user_surname' => $user_surname,
  	'user_email' => $user_email,
  	'user_password' => $user_password,
  	'user_activationcode' => $user_activationcode

    ]);

    //Cart transfer start

    $user_ip = $request->ip();
    $user_id = $user->user_id;
    $cartproducts = CartProduct::where('user_ip','=',$user_ip)->get();

    if (count($cartproducts)>0) {
       
     CartProduct::where('user_ip','=',$user_ip)->update([

     'user_ip' => null,
     'user_id' => $user_id
   
     ]);

    }

    //Cart Transfer End


  
  	
  	 Auth::guard('user')->login($user);

  	 return 'ok';

  

     }

     public function signin_process(Request $request){

     $user_email = trim(request('user_email'));
     $user_password = request('user_password');


     if (Auth::guard('user')->attempt([ 'user_email' => $user_email, 'password' => $user_password, 'user_type' => 'user', 'user_banned' => '0' ])) {
	
     request()->session()->regenerate();

     //Cart Transfer Start

     $user_ip = $request->ip();
     $user_id = Auth::guard('user')->user()->user_id;
     $cartproducts = CartProduct::where('user_ip','=',$user_ip)->get();

     if (count($cartproducts)>0) {
       
     CartProduct::where('user_ip','=',$user_ip)->update([

     'user_ip' => null,
     'user_id' => $user_id
   
     ]);

     }

     //Cart Transfer End

     echo "ok";


     } else {

     echo 'loginfail';

     }

     }


    public function userlogout(){


   

    Auth::guard('user')->logout();

    request()->session()->flush();
    request()->session()->regenerate();

    return redirect()->route('home');


    }


    public function my_account(){


    return view('my_account');

    }



    public function change_password(){


    return view('change-password');

    }



    public function forgot_password(){

    return view('forgot-password');

    }



    public function update_process(){

    $user_email = trim(request('user_email'));
    $auth = Auth::guard('user')->user();
    $user = User::find($auth->user_id);

    if ( ($auth->user_email) == ($user_email) ) {

    $this->validate(request(),[

    'user_name' => 'required|min:2|max:100',
    'user_surname' => 'required|min:2|max:100'

    ]);
      
    $user->user_name = trim(request('user_name'));
    $user->user_surname = trim(request('user_surname'));
    $user->save();

    echo "ok";

    } else {

    $this->validate(request(),[

    'user_name' => 'required|min:2|max:100',
    'user_surname' => 'required|min:2|max:100',
    'user_email' => 'required|min:6|max:150|email'

    ]);

    $mailcheck = User::where('user_email','=',trim(request('user_email')))->first();
  
    if ($mailcheck != null) {
    
    echo 'existmail';
    exit;

    }


    $user_name = trim(request('user_name'));
    $user_surname = trim(request('user_surname'));
    $user_email = trim(request('user_email'));

    $user = User::where('user_id','=',$auth->user_id)
    ->update([

    'user_name' => $user_name,
    'user_surname' => $user_surname,
    'user_email' => $user_email

    ]);

    echo 'ok';



    }

    }

    public function change_password_process(){

    $this->validate(request(),[

    'user_password' => 'required|min:8|max:100|confirmed'

    ]);

    $auth_email = Auth::guard('user')->user()->user_email;
    $user = User::where('user_email', '=', $auth_email)->first();

    if (Hash::check(request('user_currentpassword'), $user->user_password)) {
     
     $user->user_password = bcrypt(request('user_password'));
     $user->save();

     echo "ok";

    } else {

     echo 'wrongpassword';

    }
 

    }



    public function forgot_password_process(){

    $this->validate(request(),[

    'user_email' => 'required|min:6|max:150|email'

    ]);

    $user_email = trim(request('user_email'));

    $user = User::where('user_email','=',$user_email)->first();

    if ($user==null) {
      
    echo 'mailnotexist';

    } else {

    $user->user_forgotcode = Str::random(60);
    $user->save();

    echo "ok";

    }

    }


    public function reset_password_process(){

    $this->validate(request(),[

    'user_password' => 'required|min:8|max:100|confirmed'

    ]);

    $user_forgotcode = request('user_forgotcode');
    $user_email = request('user_email');
    $user_password = request('user_password');

    $user = User::where('user_email','=',$user_email)->where('user_forgotcode','=',$user_forgotcode)->first();

    if ($user!=null) {
      
    $user->user_password = bcrypt($user_password);
    $user->save();

    echo "ok";

    }

    }



    public function reset_password($user_forgotcode){

    $user1 = User::where('user_forgotcode','=',$user_forgotcode)->first();

    if ($user1==null) {

    return view('404');

    } else {

    return view('reset-password', compact('user1','user_forgotcode'));

    }

    }



    public function add_to_wishlist_process(){

    $product_id = request('product_id');

    $product_check = Product::where('product_id','=',$product_id)->first();

    $favourite_check = Favourite::where('user_id','=',Auth::guard('user')->user()->user_id)->where('product_id','=',$product_id)->first();

    if ($product_check==null or $favourite_check!=null) {
      
    exit;

    }

    
    $create = Favourite::create([

     'user_id' => Auth::guard('user')->user()->user_id,
     'product_id' => $product_id

    ]);


    if ($create) {
      
      echo "ok";

    }


    }



   public function remove_from_wishlist_process(){

   $product_id = request('product_id');

   $product_check = Product::where('product_id','=',$product_id)->first();

   $favourite_check = Favourite::where('user_id','=',Auth::guard('user')->user()->user_id)->where('product_id','=',$product_id)->first();

   if ($product_check==null or $favourite_check==null) {
      
    exit;

   }


  

    
   $delete = $favourite_check->delete();


   if ($delete) {
      
      echo "ok";

   }


   }

    
   public function remove_from_wishlist_table_process(){
   

   $product_id = request('product_id');

   $product_check = Product::where('product_id','=',$product_id)->first();

   $favourite_check = Favourite::where('user_id','=',Auth::guard('user')->user()->user_id)->where('product_id','=',$product_id)->first();

   if ($product_check==null or $favourite_check==null) {
      
   exit;

   }

    
   $delete = $favourite_check->delete();


   if ($delete) {
      
      echo "ok";

   }


    }
  

   public function wishlist(){


   if (Auth::guard('user')->check()) {

   $user = Auth::guard('user')->user();

   $products = $user->favouriteproducts;
     
   return view('wishlist', compact('products'));  

   } else {

   return view('wishlist_nosession');

   }
 

   }



   public function cart(Request $request){
 
   if (Auth::guard('user')->check()) {
  
   $user_id = Auth::guard('user')->user()->user_id;
   $cartproducts = CartProduct::where('user_id','=',$user_id)->get();

   } else {

   $user_ip = $request->ip();
   $cartproducts = CartProduct::where('user_ip','=',$user_ip)->get();

   }

   $count_cartproducts = count($cartproducts);

   return view('cart', compact('cartproducts','count_cartproducts'));

   }



   public function add_to_cart_process(Request $request){

   $product_id = request('product_id');
   $product_quantity = request('product_quantity');

   $product = Product::where('product_id','=',$product_id)->first();

   if ($product==null or $product_quantity<1 or $product_quantity>10 or ctype_digit($product_quantity)==false) {
  
   exit;

   } else if ($product->product_stock<$product_quantity){

   return 'nostock'; exit;

   }

   //Check is over. Now add.


   if (Auth::guard('user')->check()) {
     
   $user_id = Auth::guard('user')->user()->user_id;
   $cart_product = new CartProduct;
   $cart_product->product_id = $product_id;
   $cart_product->user_id = $user_id;
   $cart_product->product_quantity = $product_quantity;

   } else {

   $user_ip = $request->ip();
   $cart_product = new CartProduct;
   $cart_product->product_id = $product_id;
   $cart_product->user_ip = $user_ip;
   $cart_product->product_quantity = $product_quantity;

   }
   
   $save = $cart_product->save();

   if ($save) {
     
   return 'ok';

   }


   }


    public function checkout(){
 
    
    if (Auth::guard('user')->check()) {

      
    $cartproducts = CartProduct::where('user_id','=',Auth::guard('user')->id())->get();

    if (count($cartproducts)==0) {
      
      return redirect()->route('home');

    } else {

      /* Clear exist data to prepare new datas.*/

      PreOrder::where('user_id','=',Auth::guard('user')->id())->delete();

      $products_total = 0;

      foreach ($cartproducts as $cartproduct) {



      //Add cart items to preorder. -Start
      
      $cartproduct_id = $cartproduct->cartproduct_id;

      $product = Product::where('product_id','=',$cartproduct->product_id)->first();

      if ($product->product_sale=='1') {
      
      $product_price = $product->product_price;  

      } else {

      $product_price = $product->product_nodiscount_price;

      }

      $products_total += $product_price * $cartproduct->product_quantity;


      $preorder = new PreOrder;

      $preorder->cartproduct_id = $cartproduct_id;
      $preorder->product_price = $product_price;
      $preorder->user_id = Auth::guard('user')->id();
      $preorder->save();

      //Add cart items to preorder. -End

      }

      

      $settings = \DB::table('settings')->first();

      if ($products_total >= $settings->freeshipping) {
        
        $shipping_fee = 0.00;

      } else {

        $shipping_fee = $settings->shipping_fee;

      }

      //Update user's table preorder columns. -Start

      $id = Auth::guard('user')->id();
      $user = User::find($id);

      //2 are null because they will be obvious by installment radio choise.

      $total = $products_total + $shipping_fee;

      $user->preorder_interest_rate = null;
      $user->preorder_interest = null;
      $user->preorder_shipping_fee = $shipping_fee;
      $user->preorder_subtotal = $products_total;
      $user->preorder_total = $total;
      $user->save();


      //Update user's table preorder columns. -End

      //Get cities

      $cities = \DB::table('cities')->orderBy('city_name')->get();

      $installments = \DB::table('installments')->orderBy('installment_amount')->get();

      return view('checkout', compact('cartproducts','shipping_fee','products_total','total','cities','installments'));

    }





    } else {


     $errors = ['error1' => 'You need to sign-in or sign-up for proceeding to checkout.']; 
     return redirect()->route('signin')->withErrors($errors);
 

    }


    }



    public function remove_from_cart(Request $request){

    $cartproduct_id = request('cartproduct_id');

    //Hack Control Start----------

    if (Auth::guard('user')->check()) {
      
    $user_id = Auth::guard('user')->id();
    $wasitlastcheck = count(CartProduct::where('user_id','=',$user_id)->get());

    $cartproduct = CartProduct::where('user_id','=',$user_id)->where('cartproduct_id','=',$cartproduct_id)->first();

    if ($cartproduct==null) {

    exit;

    }


    } else {

    $user_ip = $request->ip();
    $wasitlastcheck = count(CartProduct::where('user_id','=',$user_ip)->get());

    $cartproduct = CartProduct::where('user_ip','=',$user_ip)->where('cartproduct_id','=',$cartproduct_id)->first();

    if ($cartproduct==null) {

    exit;

    }

    }

    //Hack Control End----------


    $cartproduct->delete();


    //Load Cart Page Start-----------------

    if ($wasitlastcheck==1) { ?>
      
    <p style="font-size: 22px;" align="center"><i class="fa fa-shopping-cart"></i><br>There is no item in your cart yet. <br> <a href="/">Keep Shopping</a></p>

    <?php } else { ?>


    <div class="col-xl-8 col-lg-12 col-md-12 col-12">

    <form class="woocommerce-cart-form" action="#" method="post">
    <table class="shop_table cart">
    <tr>
    <th class="product-thumbnail">&nbsp;</th>
    <th class="product-name">Product</th>
    <th class="product-price">Unit Price</th>
    <th class="product-quantity">Quantity</th>
    <th class="product-subtotal">Subtotal</th>
    <th class="product-remove">&nbsp;</th>
    </tr>

    <?php 

    if (Auth::guard('user')->check()) {
  
    $user_id = Auth::guard('user')->user()->user_id;
    $cartproducts = CartProduct::where('user_id','=',$user_id)->get();

    } else {

    $user_ip = $request->ip();
    $cartproducts = CartProduct::where('user_ip','=',$user_ip)->get();

    }

    $total = 0;

    foreach ($cartproducts as $cartproduct) {
      
    $cartproduct_id = $cartproduct->cartproduct_id;
    $quantity = $cartproduct->product_quantity;
    $product_id = $cartproduct->product_id;

    $product = \App\Models\Product::where('product_id','=',$product_id)->first();

    $brand_name = $product->brand_name;
    $product_name = $product->product_name;
    $product_coverimage = $product->product_coverimage;
    $product_slug = $product->product_slug;

    if ($product->product_sale=='1') {
                                    
    $product_price = $product->product_price;

    } else {

    $product_price = $product->product_nodiscount_price;

    }


    $subtotal = $product_price*$quantity;
    $total += $subtotal;

    ?>

    <tr class="woocommerce-cart-form__cart-item cart_item">
    
    <td class="product-thumbnail">

    <a target="_blank" href="/product/<?php echo $product_slug."/".$product_id; ?>">
    <img src="/<?php echo $product_coverimage; ?>" alt="Product image">
    </a>

    </td>

    <td class="product-name">

    <a target="_blank" href="/product/<?php echo $product_slug."/".$product_id; ?>"><?php echo $brand_name; ?> <br>

    <span style="color: #707070;">

    <?php if(strlen($product_name)>50){

    echo substr($product_name,0,50)."...";

    } else {

    echo $product_name;

    } ?>


    </span>



    </a>
                                        
    </td>
    <td class="product-price">
                                        
    <?php if ($product->product_sale==1){ ?>

    <span style="color: #0A327B;"><?php echo $product_price; ?> USD</span>

    <?php } else { ?>

    <span style="color: #0A327B;"><?php echo $product->product_nodiscount_price; ?> USD</span>

    <?php } ?>

    </td>
    <td class="product-quantity">

    <?php if ($quantity!=1){ ?>

    <i style="color: #0A327B;cursor: pointer;" name='minus_<?php echo $cartproduct_id; ?>' class="fa fa-minus quantityminus"></i>

    <?php } ?>

    <input style="width: 50px;" readonly="" type="number" name="quantity" value="<?php echo $quantity; ?>">

    <?php if ($quantity<10){ ?>

    <i style="color: #0A327B;cursor: pointer;" name='plus_<?php echo $cartproduct_id; ?>' class="fa fa-plus quantityplus"></i>

    <?php } ?>

    </div>
    </td>
    <td class="product-subtotal">
    <span style="color: #0A327B;"><?php echo number_format((float)$subtotal, 2, '.', ''); ?> USD</span>
    </td>
    <td class="product-remove">
    <a style="cursor: pointer;" name="remove_<?php echo $cartproduct_id ?>" class="remove removebtn">×</a>
    </td>
    

    </tr>

    <?php } ?>

                          


                                
    </table>
    </form>
                        
    </div>
                    
    <div class="col-xl-4 col-lg-12 col-md-12 col-12">

    <?php $settings = \DB::table('settings')->first(); ?>

    <div class="cart-collaterals">
    <div class="cart_totals ">
    <h2>Cart totals</h2>
    <table>
    <tr>
    <th>Subtotal</th>
    <td>
    <span style="color: #0A327B;font-weight: 500;"><?php echo number_format((float)$total, 2, '.', ''); ?> USD</bdi>
    </span>
    </td>
    </tr>
    <tr>
    <th>Shipping</th>
    <td>

                                        

    <?php if ($total >= $settings->freeshipping){

    $shipping_fee = 0;

    } else {

    $shipping_fee = $settings->shipping_fee; 

    } ?>

                                       

    <ul>
    <li>

                                                                                                        
    <label style="color: #0A327B;font-weight: 500;" for="shipping_method_0_free_shipping1"><?php echo number_format((float)$shipping_fee, 2, '.', ''); ?> USD</label>

    </li>
                                                
    </ul>
                                            
    </td>
    </tr>
    <tr class="order-total">
    <th>Total</th>
    <td><strong><span class="woocommerce-Price-amount amount"><?php echo number_format((float)$total+$shipping_fee, 2, '.', ''); ?> USD</span></strong> </td>
    </tr>
    </table>
    <div class="wc-proceed-to-checkout">
    <a href="/checkout" class="checkout-button">Checkout</a>
    </div>
    </div>
    </div>
    
    </div>

    <script type="text/javascript">
    
    //Remove-----------
    
    $('.removebtn').click(function(){

    $('.contentt').html('<p style="font-size:22px;" align="center">Loading...</p>');

    var button = $(this);
    var id1=$(this).attr("name");
    var cartproduct_id=id1.substring(7);

    var token = $("input[name=_token]").val();

    var data = { 'cartproduct_id':cartproduct_id, '_token': token };

    $.ajax({


    type : 'POST',
    url : '/remove_from_cart',
    data : $.param(data),
    success : function(sonuc){

    sonuc=$.trim(sonuc);
           
    $('.contentt').html(sonuc);


    }

    });

    });

    //Remove End------------------

    //Plus Start------------------

    $('.quantityplus').click(function(){

    var button = $(this);
    var id1=$(this).attr("name");
    var cartproduct_id=id1.substring(5);

    var token = $("input[name=_token]").val();

    var data = { 'cartproduct_id':cartproduct_id, '_token': token };

    $.ajax({


    type : 'POST',
    url : '/cart_quantity_plus',
    data : $.param(data),
    success : function(sonuc){

    sonuc=$.trim(sonuc);

    if (sonuc=='nostock') {

    alert('Stock is not enough for that quantity.');

    } else {

    $('.contentt').html(sonuc);

    }


    }

    });

    });

    //Plus End--------------------

    //Minus Start------------------

    $('.quantityminus').click(function(){

    var button = $(this);
    var id1=$(this).attr("name");
    var cartproduct_id=id1.substring(6);

    var token = $("input[name=_token]").val();

    var data = { 'cartproduct_id':cartproduct_id, '_token': token };

    $.ajax({


    type : 'POST',
    url : '/cart_quantity_minus',
    data : $.param(data),
    success : function(sonuc){

    sonuc=$.trim(sonuc);


    $('.contentt').html(sonuc);



    }

    });

    });

    //Minus End--------------------

    </script> 

    <?php } ?>


    <?php

    //Load Cart Page End-------------------



    }


    public function cart_quantity_plus(){

    $cartproduct_id = request('cartproduct_id');

    //Hack Control Start----------

    if (Auth::guard('user')->check()) {
      
    $user_id = Auth::guard('user')->id();
    $cartproduct = CartProduct::where('user_id','=',$user_id)->where('cartproduct_id','=',$cartproduct_id)->first();

    if ($cartproduct==null or $cartproduct->product_quantity==10) {

    exit;

    }


    } else {

    $user_ip = $request->ip();
    $cartproduct = CartProduct::where('user_ip','=',$user_ip)->where('cartproduct_id','=',$cartproduct_id)->first();

    if ($cartproduct==null  or $cartproduct->product_quantity==10) {

    exit;

    }

    }

    //Hack Control End----------

    //Stock Control Start------------

    $product_idx = $cartproduct->product_id;
    $productx = Product::where('product_id','=',$product_idx)->first();

    $product_stock = $productx->product_stock;

    if ($product_stock < ($cartproduct->product_quantity+1)) {
      
      echo "nostock"; exit;

    }

    //Stock Control End--------------

    $cartproduct->product_quantity = $cartproduct->product_quantity+1;
    $cartproduct->save();

    //Load Cart Page Start-----------------

    ?>

    <div class="col-xl-8 col-lg-12 col-md-12 col-12">

    <form class="woocommerce-cart-form" action="#" method="post">
    <table class="shop_table cart">
    <tr>
    <th class="product-thumbnail">&nbsp;</th>
    <th class="product-name">Product</th>
    <th class="product-price">Unit Price</th>
    <th class="product-quantity">Quantity</th>
    <th class="product-subtotal">Subtotal</th>
    <th class="product-remove">&nbsp;</th>
    </tr>

    <?php 

    if (Auth::guard('user')->check()) {
  
    $user_id = Auth::guard('user')->user()->user_id;
    $cartproducts = CartProduct::where('user_id','=',$user_id)->get();

    } else {

    $user_ip = $request->ip();
    $cartproducts = CartProduct::where('user_ip','=',$user_ip)->get();

    }

    $total = 0;

    foreach ($cartproducts as $cartproduct) {
      
    $cartproduct_id = $cartproduct->cartproduct_id;
    $quantity = $cartproduct->product_quantity;
    $product_id = $cartproduct->product_id;

    $product = \App\Models\Product::where('product_id','=',$product_id)->first();

    $brand_name = $product->brand_name;
    $product_name = $product->product_name;
    $product_coverimage = $product->product_coverimage;
    $product_slug = $product->product_slug;

    if ($product->product_sale=='1') {
                                    
    $product_price = $product->product_price;

    } else {

    $product_price = $product->product_nodiscount_price;

    }


    $subtotal = $product_price*$quantity;
    $total += $subtotal;

    ?>

    <tr class="woocommerce-cart-form__cart-item cart_item">
    
    <td class="product-thumbnail">

    <a target="_blank" href="/product/<?php echo $product_slug."/".$product_id; ?>">
    <img src="/<?php echo $product_coverimage; ?>" alt="Product image">
    </a>

    </td>

    <td class="product-name">

    <a target="_blank" href="/product/<?php echo $product_slug."/".$product_id; ?>"><?php echo $brand_name; ?> <br>

    <span style="color: #707070;">

    <?php if(strlen($product_name)>50){

    echo substr($product_name,0,50)."...";

    } else {

    echo $product_name;

    } ?>


    </span>



    </a>
                                        
    </td>
    <td class="product-price">
                                        
    <?php if ($product->product_sale==1){ ?>

    <span style="color: #0A327B;"><?php echo $product_price; ?> USD</span>

    <?php } else { ?>

    <span style="color: #0A327B;"><?php echo $product->product_nodiscount_price; ?> USD</span>

    <?php } ?>

    </td>
    <td class="product-quantity">

    <?php if ($quantity!=1){ ?>

    <i style="color: #0A327B;cursor: pointer;" name='minus_<?php echo $cartproduct_id; ?>' class="fa fa-minus quantityminus"></i>

    <?php } ?>

    <input style="width: 50px;" readonly="" type="number" name="quantity" value="<?php echo $quantity; ?>">

    <?php if ($quantity<10){ ?>

    <i style="color: #0A327B;cursor: pointer;" name='plus_<?php echo $cartproduct_id; ?>' class="fa fa-plus quantityplus"></i>

    <?php } ?>

    </div>
    </td>
    <td class="product-subtotal">
    <span style="color: #0A327B;"><?php echo number_format((float)$subtotal, 2, '.', ''); ?> USD</span>
    </td>
    <td class="product-remove">
    <a style="cursor: pointer;" name="remove_<?php echo $cartproduct_id ?>" class="remove removebtn">×</a>
    </td>
    

    </tr>

    <?php } ?>

                          


                                
    </table>
    </form>
                        
    </div>
                    
    <div class="col-xl-4 col-lg-12 col-md-12 col-12">

    <?php $settings = \DB::table('settings')->first(); ?>

    <div class="cart-collaterals">
    <div class="cart_totals ">
    <h2>Cart totals</h2>
    <table>
    <tr>
    <th>Subtotal</th>
    <td>
    <span style="color: #0A327B;font-weight: 500;"><?php echo number_format((float)$total, 2, '.', ''); ?> USD</bdi>
    </span>
    </td>
    </tr>
    <tr>
    <th>Shipping</th>
    <td>

                                        

    <?php if ($total >= $settings->freeshipping){

    $shipping_fee = 0;

    } else {

    $shipping_fee = $settings->shipping_fee; 

    } ?>

                                       

    <ul>
    <li>

                                                                                                        
    <label style="color: #0A327B;font-weight: 500;" for="shipping_method_0_free_shipping1"><?php echo number_format((float)$shipping_fee, 2, '.', ''); ?> USD</label>

    </li>
                                                
    </ul>
                                            
    </td>
    </tr>
    <tr class="order-total">
    <th>Total</th>
    <td><strong><span class="woocommerce-Price-amount amount"><?php echo number_format((float)$total+$shipping_fee, 2, '.', ''); ?> USD</span></strong> </td>
    </tr>
    </table>
    <div class="wc-proceed-to-checkout">
    <a href="/checkout" class="checkout-button">Checkout</a>
    </div>
    </div>
    </div>
    
    </div>

    <script type="text/javascript">
    
    //Remove-----------
    
    $('.removebtn').click(function(){

    $('.contentt').html('<p style="font-size:22px;" align="center">Loading...</p>');

    var button = $(this);
    var id1=$(this).attr("name");
    var cartproduct_id=id1.substring(7);

    var token = $("input[name=_token]").val();

    var data = { 'cartproduct_id':cartproduct_id, '_token': token };

    $.ajax({


    type : 'POST',
    url : '/remove_from_cart',
    data : $.param(data),
    success : function(sonuc){

    sonuc=$.trim(sonuc);
           
    $('.contentt').html(sonuc);


    }

    });

    });

    //Remove End------------------

    //Plus Start------------------

    $('.quantityplus').click(function(){

    var button = $(this);
    var id1=$(this).attr("name");
    var cartproduct_id=id1.substring(5);

    var token = $("input[name=_token]").val();

    var data = { 'cartproduct_id':cartproduct_id, '_token': token };

    $.ajax({


    type : 'POST',
    url : '/cart_quantity_plus',
    data : $.param(data),
    success : function(sonuc){

    sonuc=$.trim(sonuc);

    if (sonuc=='nostock') {

    alert('Stock is not enough for that quantity.');

    } else {

    $('.contentt').html(sonuc);

    }


    }

    });

    });

    //Plus End--------------------

    //Minus Start------------------

    $('.quantityminus').click(function(){

    var button = $(this);
    var id1=$(this).attr("name");
    var cartproduct_id=id1.substring(6);

    var token = $("input[name=_token]").val();

    var data = { 'cartproduct_id':cartproduct_id, '_token': token };

    $.ajax({


    type : 'POST',
    url : '/cart_quantity_minus',
    data : $.param(data),
    success : function(sonuc){

    sonuc=$.trim(sonuc);


    $('.contentt').html(sonuc);



    }

    });

    });

    //Minus End--------------------

    </script> 


    <?php

    //Load Cart Page End-------------------

    }







    public function cart_quantity_minus(){

    $cartproduct_id = request('cartproduct_id');

    //Hack Control Start----------

    if (Auth::guard('user')->check()) {
      
    $user_id = Auth::guard('user')->id();
    $cartproduct = CartProduct::where('user_id','=',$user_id)->where('cartproduct_id','=',$cartproduct_id)->first();

    if ($cartproduct==null or $cartproduct->product_quantity==1) {

    exit;

    }


    } else {

    $user_ip = $request->ip();
    $cartproduct = CartProduct::where('user_ip','=',$user_ip)->where('cartproduct_id','=',$cartproduct_id)->first();

    if ($cartproduct==null  or $cartproduct->product_quantity==1) {

    exit;

    }

    }

    //Hack Control End----------

    

    $cartproduct->product_quantity = $cartproduct->product_quantity-1;
    $cartproduct->save();

    //Load Cart Page Start-----------------

    ?>

    <div class="col-xl-8 col-lg-12 col-md-12 col-12">

    <form class="woocommerce-cart-form" action="#" method="post">
    <table class="shop_table cart">
    <tr>
    <th class="product-thumbnail">&nbsp;</th>
    <th class="product-name">Product</th>
    <th class="product-price">Unit Price</th>
    <th class="product-quantity">Quantity</th>
    <th class="product-subtotal">Subtotal</th>
    <th class="product-remove">&nbsp;</th>
    </tr>

    <?php 

    if (Auth::guard('user')->check()) {
  
    $user_id = Auth::guard('user')->user()->user_id;
    $cartproducts = CartProduct::where('user_id','=',$user_id)->get();

    } else {

    $user_ip = $request->ip();
    $cartproducts = CartProduct::where('user_ip','=',$user_ip)->get();

    }

    $total = 0;

    foreach ($cartproducts as $cartproduct) {
      
    $cartproduct_id = $cartproduct->cartproduct_id;
    $quantity = $cartproduct->product_quantity;
    $product_id = $cartproduct->product_id;

    $product = \App\Models\Product::where('product_id','=',$product_id)->first();

    $brand_name = $product->brand_name;
    $product_name = $product->product_name;
    $product_coverimage = $product->product_coverimage;
    $product_slug = $product->product_slug;

    if ($product->product_sale=='1') {
                                    
    $product_price = $product->product_price;

    } else {

    $product_price = $product->product_nodiscount_price;

    }


    $subtotal = $product_price*$quantity;
    $total += $subtotal;

    ?>

    <tr class="woocommerce-cart-form__cart-item cart_item">
    
    <td class="product-thumbnail">

    <a target="_blank" href="/product/<?php echo $product_slug."/".$product_id; ?>">
    <img src="/<?php echo $product_coverimage; ?>" alt="Product image">
    </a>

    </td>

    <td class="product-name">

    <a target="_blank" href="/product/<?php echo $product_slug."/".$product_id; ?>"><?php echo $brand_name; ?> <br>

    <span style="color: #707070;">

    <?php if(strlen($product_name)>50){

    echo substr($product_name,0,50)."...";

    } else {

    echo $product_name;

    } ?>


    </span>



    </a>
                                        
    </td>
    <td class="product-price">
                                        
    <?php if ($product->product_sale==1){ ?>

    <span style="color: #0A327B;"><?php echo $product_price; ?> USD</span>

    <?php } else { ?>

    <span style="color: #0A327B;"><?php echo $product->product_nodiscount_price; ?> USD</span>

    <?php } ?>

    </td>
    <td class="product-quantity">

    <?php if ($quantity!=1){ ?>

    <i style="color: #0A327B;cursor: pointer;" name='minus_<?php echo $cartproduct_id; ?>' class="fa fa-minus quantityminus"></i>

    <?php } ?>

    <input style="width: 50px;" readonly="" type="number" name="quantity" value="<?php echo $quantity; ?>">

    <?php if ($quantity<10){ ?>

    <i style="color: #0A327B;cursor: pointer;" name='plus_<?php echo $cartproduct_id; ?>' class="fa fa-plus quantityplus"></i>

    <?php } ?>

    </div>
    </td>
    <td class="product-subtotal">
    <span style="color: #0A327B;"><?php echo number_format((float)$subtotal, 2, '.', ''); ?> USD</span>
    </td>
    <td class="product-remove">
    <a style="cursor: pointer;" name="remove_<?php echo $cartproduct_id ?>" class="remove removebtn">×</a>
    </td>
    

    </tr>

    <?php } ?>

                          


                                
    </table>
    </form>
                        
    </div>
                    
    <div class="col-xl-4 col-lg-12 col-md-12 col-12">

    <?php $settings = \DB::table('settings')->first(); ?>

    <div class="cart-collaterals">
    <div class="cart_totals ">
    <h2>Cart totals</h2>
    <table>
    <tr>
    <th>Subtotal</th>
    <td>
    <span style="color: #0A327B;font-weight: 500;"><?php echo number_format((float)$total, 2, '.', ''); ?> USD</bdi>
    </span>
    </td>
    </tr>
    <tr>
    <th>Shipping</th>
    <td>

                                        

    <?php if ($total >= $settings->freeshipping){

    $shipping_fee = 0;

    } else {

    $shipping_fee = $settings->shipping_fee; 

    } ?>

                                       

    <ul>
    <li>

                                                                                                        
    <label style="color: #0A327B;font-weight: 500;" for="shipping_method_0_free_shipping1"><?php echo number_format((float)$shipping_fee, 2, '.', ''); ?> USD</label>

    </li>
                                                
    </ul>
                                            
    </td>
    </tr>
    <tr class="order-total">
    <th>Total</th>
    <td><strong><span class="woocommerce-Price-amount amount"><?php echo number_format((float)$total+$shipping_fee, 2, '.', ''); ?> USD</span></strong> </td>
    </tr>
    </table>
    <div class="wc-proceed-to-checkout">
    <a href="/checkout" class="checkout-button">Checkout</a>
    </div>
    </div>
    </div>
    
    </div>

    

    <script type="text/javascript">
    
    //Remove-----------
    
    $('.removebtn').click(function(){

    $('.contentt').html('<p style="font-size:22px;" align="center">Loading...</p>');

    var button = $(this);
    var id1=$(this).attr("name");
    var cartproduct_id=id1.substring(7);

    var token = $("input[name=_token]").val();

    var data = { 'cartproduct_id':cartproduct_id, '_token': token };

    $.ajax({


    type : 'POST',
    url : '/remove_from_cart',
    data : $.param(data),
    success : function(sonuc){

    sonuc=$.trim(sonuc);
           
    $('.contentt').html(sonuc);


    }

    });

    });

    //Remove End------------------

    //Plus Start------------------

    $('.quantityplus').click(function(){

    var button = $(this);
    var id1=$(this).attr("name");
    var cartproduct_id=id1.substring(5);

    var token = $("input[name=_token]").val();

    var data = { 'cartproduct_id':cartproduct_id, '_token': token };

    $.ajax({


    type : 'POST',
    url : '/cart_quantity_plus',
    data : $.param(data),
    success : function(sonuc){

    sonuc=$.trim(sonuc);

    if (sonuc=='nostock') {

    alert('Stock is not enough for that quantity.');

    } else {

    $('.contentt').html(sonuc);

    }


    }

    });

    });

    //Plus End--------------------

    //Minus Start------------------

    $('.quantityminus').click(function(){

    var button = $(this);
    var id1=$(this).attr("name");
    var cartproduct_id=id1.substring(6);

    var token = $("input[name=_token]").val();

    var data = { 'cartproduct_id':cartproduct_id, '_token': token };

    $.ajax({


    type : 'POST',
    url : '/cart_quantity_minus',
    data : $.param(data),
    success : function(sonuc){

    sonuc=$.trim(sonuc);


    $('.contentt').html(sonuc);



    }

    });

    });

    //Minus End--------------------

    </script> 


    <?php

    //Load Cart Page End-------------------




    }


    public function select_city(){

    $city_id = request('city_id');

    $city = \DB::table('cities')->where('city_id','=',$city_id)->first();

    if ($city==null) {
     
     exit;

    }

    $districts = \DB::table('districts')->where('city_id','=',$city_id)->get();

    foreach ($districts as $district) { ?>
      
    <option value="<?php echo $district->district_id; ?>"><?php echo $district->district_name; ?></option>

    <?php }

    }




    public function change_installment(){

    $installment_id = request('installment_id');

    $installment = \DB::table('installments')->where('installment_id','=',$installment_id)->first();

    if ($installment==null and $installment_id!='oneshot') {
      
      exit;

    }

    $user = User::find(Auth::guard('user')->id());

    if ($installment_id=='oneshot') {
     
    $total = $user->preorder_subtotal + $user->preorder_shipping_fee; 

    $user->preorder_interest_rate = null;
    $user->preorder_interest = null;
    $user->preorder_total = $total;
    $user->save(); ?>

    <tr class="order-total interesttr">
    <th>Interest</th>
    <td><strong><span style="color: #0A327B;" class="woocommerce-Price-amount amount">0.00 USD</span></strong> </td>
    </tr>

                                                                
    <tr class="order-total totaltr">
    <th>Total</th>
    <td><strong><span style="color: #0A327B;" class="woocommerce-Price-amount amount">
    <?php echo number_format((float)$total, 2, '.', '') ?> USD
    </span></strong> </td>
    </tr>


    <?php } else {

    
    $interest_rate = \DB::table('installments')->where('installment_id','=',$installment_id)->first()->installment_interest;
    $interest = ($user->preorder_subtotal / 100) * $interest_rate;
    $total = $user->preorder_subtotal + $interest + $user->preorder_shipping_fee;

    $user->preorder_interest_rate = $interest_rate;
    $user->preorder_interest = $interest;
    $user->preorder_total = $user->preorder_subtotal + $user->preorder_shipping_fee + $interest;
    $user->save(); ?>


    <tr class="order-total interesttr">
    <th>Interest</th>
    <td><strong><span style="color: #0A327B;" class="woocommerce-Price-amount amount"><?php echo number_format((float)$interest, 2, '.', '') ?> USD</span></strong> </td>
    </tr>

                                                                
    <tr class="order-total totaltr">
    <th>Total</th>
    <td><strong><span style="color: #0A327B;" class="woocommerce-Price-amount amount">
    <?php echo number_format((float)$total, 2, '.', '') ?> USD
    </span></strong> </td>
    </tr>


    <?php } ?>

    <script type="text/javascript">
      
      $('input[type=radio][name=installment]').change(function() {

var id1=$(this).attr("id");
var installment_id=id1.substring(8);

$('input[type=radio][name=installment]').attr('disabled',true);
$('.checkoutbutton').attr('disabled',true);
$('.interesttr,.totaltr').remove();

var data = { 'installment_id':installment_id, '_token': "{{ csrf_token() }}" };

$.ajax({

type : 'POST',
url : '/change_installment',
data : $.param(data),
success : function(sonuc){

sonuc=$.trim(sonuc);

$('input[type=radio][name=installment]').attr('disabled',false);
$('.checkoutbutton').attr('disabled',false);

$('.interesttr,.totaltr').remove();
$('.installmenttr').after(sonuc);




            
}

});



});

    </script>

    <?php }



  public function checkout_process(){

  //Hack Control Start ---

  $this->validate(request(),[

    'order_firstname' => 'required|min:2|max:100',
    'order_lastname' => 'required|min:2|max:100',
    'order_phonenumber' => 'required|min:10|max:20', 
    'order_address' => 'required|min:15|max:1000',
    'order_note' => 'max:500',
    'cardnumber' => 'required|min:16|max:22',
    'cardholder' => 'required|min:4|max:100',
    'cvc' => 'required|digits:3'

  ]);


  $order_city = request('order_city');
  $order_district = request('order_district');

  $city = \DB::table('cities')->where('city_id','=',$order_city)->first();
  $district = \DB::table('districts')->where('district_id','=',$order_district)->first();

  if ($city==null or $district==null) {
    
    exit;

  }

  //Hack Control End ---

  //Create Order Start ---

  $user = User::find(Auth::guard('user')->id());

  $order = new Order;

  $order->user_id = $user->user_id;
  $order->order_firstname = request('order_firstname');
  $order->order_lastname = request('order_lastname');
  $order->order_phonenumber = request('order_phonenumber');
  $order->order_location = $city->city_name." / ".$district->district_name;
  $order->order_mail = $user->user_email;
  $order->order_address = request('order_address');
  $order->order_subtotal = $user->preorder_subtotal;
  $order->order_shipping_fee = $user->preorder_shipping_fee;
  $order->order_interest_rate = $user->preorder_interest_rate;
  $order->order_interest = $user->preorder_interest;
  $order->order_total = $user->preorder_total;
  $order->order_note = request('order_note');
  $order->save();



  //Create Order End ---

  //Create Order Items Start ---

  $preorders = PreOrder::where('user_id','=',$user->user_id)->get();

  foreach ($preorders as $preorder) {
  
  $cartproduct = CartProduct::find($preorder->cartproduct_id);
  

  OrderProduct::create([

  'user_id' => $user->user_id,
  'order_id' => $order->order_id,
  'product_id' => $cartproduct->product_id,
  'product_quantity' => $cartproduct->product_quantity,
  'product_price' => $preorder->product_price,
  'product_total' => ($cartproduct->product_quantity)*($preorder->product_price)


  ]);

  }

  //Create Order Items End ---


  //Clear cart and all preorder stuff start ---

  $delete_cart = CartProduct::where('user_id','=',$user->user_id)->delete();
  $delete_preorders = PreOrder::where('user_id','=',$user->user_id)->delete();

  $user->preorder_shipping_fee = null;
  $user->preorder_interest = null;
  $user->preorder_interest_rate = null;
  $user->preorder_subtotal = null;
  $user->preorder_total = null;
  $user->save();

  //Clear cart and all preorder stuff end ---

  echo "ok";

  }




  public function orders(){

  $orders = Order::where('user_id','=',Auth::guard('user')->id())->latest()->get();

  return view('orders', compact('orders'));

  }



  public function order_details($order_id){

  $order = Order::where('user_id','=',Auth::guard('user')->id())->where('order_id','=',$order_id)->firstOrFail();

  

  $orderproducts = OrderProduct::where('order_id','=',$order_id)->get();

  return view('order_details', compact('order','orderproducts'));

  }

 
    
    }
