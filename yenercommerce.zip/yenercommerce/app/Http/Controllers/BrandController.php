<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Brand;
use App\Models\Product;
use Illuminate\Support\Facades\DB;

class BrandController extends Controller
{

	public function brands (){

    $brands = Brand::orderBy('brand_name')->get();

    return view('brands', compact('brands'));

	}


	public function brand_details ($brand_slug, $brand_id){

    $brand = Brand::where('brand_id','=',$brand_id)->where('brand_slug','=',$brand_slug)->firstOrFail();

    if (empty(request('page'))) {

    $page=1;                           

    } else {

    $page = request('page');

    }


    $productscount = count(DB::select("SELECT product_id from products where brand_id='$brand_id'"));

    $resultsperpage = 1;

    $countofpages = ceil($productscount/$resultsperpage);

    if (!is_numeric($page) or ($page < 0) or ($page > $countofpages)) {

    
    return view('404');


    } else {
    
    $products = Product::where('brand_id','=',$brand_id)->orderBy('brand_name')->paginate(1);

    return view('brand_details',compact('brand','products','productscount','resultsperpage','page','countofpages'));

    }

	}
    
} 
