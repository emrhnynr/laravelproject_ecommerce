<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use App\Models\User;
use App\Models\Product;
use App\Models\CartProduct;
use App\Models\PreOrder;
use App\Models\Order;
use App\Models\OrderProduct;
use App\Models\Category;
use App\Models\Favourite;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Mail;
use App\Mail\UserSignupMail;

class AdminController extends Controller
{
    
    public function home(){

    if (Auth::guard('admin')->check()) {
    	
    return view('admin.home');	

    } else {

    return redirect()->route('admin.signin');

    }

    }


    public function signin(){

    if (Auth::guard('admin')->check()) {

    return redirect()->route('admin.home');exit;	 

    }

    return view('admin.signin');

    }



    public function signin_process(){

    $user_email = trim(request('user_email'));
    $user_password = request('user_password');

    if (Auth::guard('admin')->attempt([ 'user_email' => $user_email, 'password' => $user_password, 'user_type' => 'admin', 'user_banned' => '0' ])) {
	
    request()->session()->regenerate();

    return redirect()->route('admin.home');

    } else {

    $errors = ['error1' => 'E-Mail or Password is incorrect.'];
    return redirect()->route('admin.signin')->withErrors($errors);

    }

    }
   



    public function adminlogout(){

    Auth::guard('admin')->logout();

    request()->session()->flush();
    request()->session()->regenerate();

    return redirect()->route('admin.signin');

    }



    public function general_settings(){

    $settings = \DB::table('settings')->first();

    return view('admin.general-settings', compact('settings'));

    }



    public function general_settings_process(){

    $this->validate(request(),[

    'phonenumber' => 'max:30',
    'mail' => 'max:150',
    'address' => 'max:1000', 
    'instagram_link' => 'max:30',
    'facebook_link' => 'max:30',
    'twitter_link' => 'max:30'

    ]);



    $update = \DB::table('settings')->update([

    'phonenumber' => request('phonenumber'),
    'mail' => request('mail'),
    'address' => request('address'),
    'shipping_fee' => request('shipping_fee'),
    'freeshipping' => request('freeshipping'),
    'instagram_link' => request('instagram_link'),
    'facebook_link' => request('facebook_link'),
    'twitter_link' => request('twitter_link')

    ]);

    
    
    return "ok";

    


    }



    public function categories($category_top){

    if ($category_top!='0') {
    
    $category = Category::findOrFail($category_top);

    } else {

    $category = null;
     
    }

    $categories = Category::where('category_top','=',$category_top)->orderBy('category_order')->get();

    return view('admin.categories', compact('category_top','categories','category'));


    }




    public function edit_category($category_id){

    $category = Category::findOrFail($category_id);

    return view('admin.edit-category', compact('category'));

    }




    public function edit_category_process(){

    $this->validate(request(),[

    'category_name' => 'required',
    'category_active' => 'in:0,1'

    ]);

    $category_name = request('category_name');
    $category_slug = Str::slug($category_name, '-');
    $category_active = request('category_active');
    $category_id = request('category_id');

    $category = Category::findOrFail($category_id);

    $category->category_name = $category_name;
    $category->category_slug = $category_slug;
    $category->category_active = $category_active;
    $category->save();

    return 'ok';



    }

}
