<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Product;
use App\Models\ProductFeatures;
use App\Models\ProductImages;
use App\Models\Brand;
use App\Models\Favourite;
use Illuminate\Support\Facades\Auth;

class ProductController extends Controller
{


public function product_details($product_slug,$product_id){


$product = Product::where('product_id','=',$product_id)->where('product_slug','=',$product_slug)->firstOrFail();

$product_category = $product->category_id;
$product_brand = $product->brand_id;

$similar_products = Product::where('category_id','=',$product_category)->where('product_id','!=',$product_id)->get();

$features = ProductFeatures::where('product_id','=',$product_id)->get();

$images = ProductImages::where('product_id','=',$product_id)->orderBy('image_order')->get();

$categories = $product->categories()->orderBy('category_top','ASC')->get();

$brand = Brand::where('brand_id','=',$product_brand)->first();

if (Auth::guard('user')->check()) {

$check = Favourite::where('product_id','=',$product_id)->where('user_id','=',Auth::guard('user')->user()->user_id)->first();

if ($check!=null) {
   
   $in_favourites = 'yes';

} else {

   $in_favourites = 'no';

}

} else {

$in_favourites = '';

}

return view('product_details', compact('product','categories','similar_products','brand','features','images','in_favourites'));




}
    
public function search(){

$query = trim(request()->get('query'));

if (empty($query)) {
	
	return view('404');

} else {

	if (empty(request('page'))) {

    $page=1;                           

    } else {

    $page = request('page');

    }



    $productscount = count(\DB::table('products')

    ->where('product_id','=',$query)
    ->orWhere('product_name','like',"%$query%")
    ->orWhere('brand_name','like',"%$query%")
    ->get()
    ->pluck('product_id'));


    $resultsperpage = 1;

    $countofpages = ceil($productscount/$resultsperpage);

    if (!is_numeric($page) or ($page < 0) or ($page > $countofpages)) {

    
    return view('404');


    } else {


    $products = Product::
    where('product_id','=',$query)
    ->orWhere('product_name','like',"%$query%")
    ->orWhere('brand_name','like',"%$query%")
    ->orderBy('product_id')
    ->paginate(1);

    request()->flash();

    return view('search_results', compact('products','query','productscount','resultsperpage','page','countofpages'));

    }

}

}

}
