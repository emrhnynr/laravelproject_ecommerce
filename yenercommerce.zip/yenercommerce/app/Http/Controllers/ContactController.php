<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ContactController extends Controller
{
    
    public function contact(){

 return view('contact');

    }



    public function submitcontactform(){

    $this->validate(request(),[
 
    'full_name' => 'required|min:3|max:100',
    'email' => 'required|min:6|max:150|email',
    'subject' => 'required|min:2|max:150',
    'message' => 'required|min:10|max:1500'

    ]);

    

    //If no hack trying then:

    $full_name = request('full_name');
    $email = request('email');
    $subject = request('subject');
    $message = request('message');

    return "ok";


    }

}
