<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Category;
use Illuminate\Support\Facades\DB;

class CategoryController extends Controller
{
    

    public function category_details($category_slug,$category_id){

    $category = Category::where('category_slug','=',$category_slug)->where('category_id','=',$category_id)->firstOrFail();

    if (empty(request('page'))) {

    $page=1;                           

    } else {

    $page = request('page');

    }


    $productscount = count(DB::select("SELECT categoryproducts_id from categoryproducts where category_id='$category_id'"));

    $resultsperpage = 1;

    $countofpages = ceil($productscount/$resultsperpage);


    if (!is_numeric($page) or ($page < 0) or ($page > $countofpages)) {

    
    return view('404');


    } else {


    $products = $category->products()->paginate($resultsperpage);
    
    return view('category_details', compact('category','products','productscount','resultsperpage','page','countofpages'));


    }

    

    }

}
