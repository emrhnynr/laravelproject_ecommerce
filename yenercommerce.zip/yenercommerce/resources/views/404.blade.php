@extends('layouts.app')

@section('title') Page not found @endsection

@section('content')

<div class="full-row" style="padding: 100px 0">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-md-6 col-lg-5">
                        <div class="text-center">
                            <span class="fa fa-exclamation-triangle text-primary" style="font-size: 60px"></span>
                            <h2 class="my-4">404 Page not found</h2>
                            <p>The page you are looking for dosen’t exist or another error occourd go back to home or another source</p>
                            <a class="btn btn-secondary mt-5" href="{{route('home')}}">Return to home</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

@endsection