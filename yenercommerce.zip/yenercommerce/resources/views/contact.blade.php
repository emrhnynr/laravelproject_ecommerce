@extends('layouts.app')

@section('title') Contact Us @endsection

@section('content')

 <!-- breadcrumb -->
        <div class="full-row bg-light py-5">
            <div class="container">
                <div class="row text-secondary">
                    <div class="col-sm-6">
                        <h3 class="mb-2 text-secondary">Contact</h3>
                    </div>
                    <div class="col-sm-6">
                        <nav aria-label="breadcrumb" class="d-flex justify-content-sm-end align-items-center h-100">
                            <ol class="breadcrumb mb-0 d-inline-flex bg-transparent p-0">
                                <li class="breadcrumb-item"><a href="{{route('home')}}"><i class="fas fa-home me-1"></i>Home</a></li>
                                <li class="breadcrumb-item active" aria-current="page">Contact</li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
        <!-- breadcrumb -->

      

        <!--==================== Contact Section Start ====================-->
        <div class="full-row">
            <div class="container">
                <div class="row">
                    <div class="col-lg-7 col-md-7">
                        <h3 class="down-line mb-5">Send Message</h3>
                        <div class="form-simple mb-5">
                            <form id="contact-form" onsubmit="return false;">
                               
                               @csrf

                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label>Full Name:</label>
                                            <input type="text" class="form-control bg-gray" id="full_name" name="full_name" maxlength="100">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label>Your Email:</label>
                                            <input type="email" class="form-control bg-gray" id="email" name="email"  maxlength="150">
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="mb-3">
                                            <label>Subject:</label>
                                            <input type="text" class="form-control bg-gray" id="subject" name="subject"  maxlength="150">
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="mb-3">
                                            <label>Message:</label>
                                            <textarea class="form-control bg-gray" name="message" id="message" rows="8" maxlength="1500"></textarea>
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <button class="btn btn-primary" id="submitbtn" name="submit" type="submit">Send Message</button>
                                    </div>


                                    <div style="margin-top: 20px;" class="col-md-12">
                                    <div class="alert alert-warning warning" style="display: none;"></div>
                                </div>
                                </div>
                            </form>
                        </div>
                    </div>
                    <div class="col-lg-5 col-md-5">
                        <h3 class="down-line mb-5">Get In Touch</h3>
                        <p>Need help? Contact us now!</p>
                        <div class="d-flex mb-3">
                            <ul>
                                <li class="mb-3">
                                    <strong>Office Address :</strong><br> {{$settings->address}}
                                </li>
                                <li class="mb-3">
                                    <strong>Contact Number :</strong><br> <a href="tel:{{$settings->phonenumber}}">{{$settings->phonenumber}}</a>
                                </li>
                                
                            </ul>
                        </div>
                        <h4 class="mb-2">Career Info</h4>
                        <p>If you’re interested in employment opportunities at Unicoder, please email us:<br> <a href="mailto:{{$settings->mail}}">{{$settings->mail}}</a></p>
                    </div>
                </div>
            </div>
        </div>

@endsection


@section('extrascript')

<script type="text/javascript">
	
$('#contact-form').submit(function(event){

var full_name = $.trim($('#full_name').val());
var email = $.trim($('#email').val());
var subject = $.trim($('#subject').val());
var message = $.trim($('#message').val());

if (full_name.length<3) {


$('.warning').show();
$('.warning').html("<i class='fa fa-info-circle'></i> Full name can't be shorter than 3 characters.");

} else if (email.length<6) {


$('.warning').show();
$('.warning').html("<i class='fa fa-info-circle'></i> Email can't be shorter than 6 characters.");

} else if (subject.length<6) {


$('.warning').show();
$('.warning').html("<i class='fa fa-info-circle'></i> Subject can't be shorter than 2 characters.");

} else if (message.length<10) {


$('.warning').show();
$('.warning').html("<i class='fa fa-info-circle'></i> Message can't be shorter than 10 characters.");

} else {

$('.warning').hide();
$('#submitbtn').attr('disabled',true);
$('#submitbtn').html('Sending...');

var data = $("#contact-form").serializeArray();
var csrf_token = $("input[name=_token]").val();
data.push({name: "_token", value: csrf_token});

$.ajax({
            type : 'POST',
            url : '/contact/submitcontactform',
            data : $.param(data),
            success : function(sonuc){

              sonuc = $.trim(sonuc);

              if (sonuc=='ok') {


$('#submitbtn').css('background-color','green');
$('#submitbtn').html('Message has sent. Thank you!');

              }

         }

 });

}



});

</script>

@endsection