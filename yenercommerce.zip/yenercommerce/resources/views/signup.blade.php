@extends('layouts.app')

@section('title') Sign-Up @endsection

@section('content')

<div class="full-row">
            <div class="container">
                <div class="row">
                    <div class="col">
                        <div class="woocommerce">
                            <div class="row">
                                <div class="col-lg-6 col-md-8 col-12 mx-auto">
                                    <div class="registration-form">
                                        <h3>Sign-Up</h3>
                                        <form id="signupform" onsubmit="return false;">

                                           @csrf

                                            <p>
                                                <label for="reg_email">Name&nbsp;<span class="required">*</span></label>
                                                <input type="text" class="form-control" maxlength="100" name="user_name" id="user_name" />
                                            </p>

                                            <p>
                                                <label for="reg_email">Surname&nbsp;<span class="required">*</span></label>
                                                <input type="text" class="form-control" maxlength="100" name="user_surname" id="user_surname" />
                                            </p>

                                            <p>
                                                <label for="reg_email">Email address&nbsp;<span class="required">*</span></label>
                                                <input type="email" class="form-control" maxlength="150" name="user_email" id="user_email" />
                                            </p>

                                           
                                            <p>
                                                <label for="reg_email">Password&nbsp;<span class="required">*</span></label>
                                                <input type="password" class="form-control" maxlength="100" name="user_password" id="user_password" />
                                            </p>


                                            <p>
                                                <label for="reg_email">Password (Again)&nbsp;<span class="required">*</span></label>
                                                <input type="password" class="form-control" maxlength="100" name="user_password_confirmation" id="user_password_confirmation" />
                                            </p>

                                            <div style="display: none;" class="alert alert-warning warning"><i class="fa fa-info-circle"></i></div>
                                            
                                            <p>
                                                <button type="submit" class="btn btn-primary rounded-0 signupbtn" value="Sign-Up">Sign-Up</button>
                                            </p>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

@endsection

@section('extrascript')

<script type="text/javascript">
    
$('#signupform').submit(function(){

 var user_name = $.trim($('#user_name').val());
 var user_surname = $.trim($('#user_surname').val());
 var user_email = $.trim($('#user_email').val());
 var user_password = $('#user_password').val();
 var user_password_confirmation = $('#user_password_confirmation').val();


if (user_name.length<2) {

$('.warning').show();
$('.warning').html("<i class='fa fa-info-circle'></i> Name field can't be shorter than 2 characters.");

} else if (user_surname.length<2){

$('.warning').show();
$('.warning').html("<i class='fa fa-info-circle'></i> Surname field can't be shorter than 2 characters.");

} else if (user_email.length<6){

$('.warning').show();
$('.warning').html("<i class='fa fa-info-circle'></i> Email field can't be shorter than 6 characters.");

} else if (user_password.length<8){

$('.warning').show();
$('.warning').html("<i class='fa fa-info-circle'></i> Password field can't be shorter than 8 characters.");

} else if (user_password_confirmation!=user_password){

$('.warning').show();
$('.warning').html("<i class='fa fa-info-circle'></i> Passwords don't match. Please type again.");

} else {

$('.warning').hide();
$('.signupbtn').attr('disabled',true);
$('.signupbtn').html('Processing...');

var data = $("#signupform").serializeArray();
var csrf_token = $("input[name=_token]").val();
data.push({name: "_token", value: csrf_token});


$.ajax({


            type : 'POST',
            url : '/user/signup_process',
            data : $.param(data),
            success : function(sonuc){

              sonuc = $.trim(sonuc);

              if (sonuc=='existmail'){

              $('.warning').show();
              $('.warning').html("<i class='fa fa-info-circle'></i> This email address is already exist.");
              $('.signupbtn').attr('disabled',false);
              $('.signupbtn').html('Sign-Up');


              } else if (sonuc=='ok') {

              location.href = '/';

              }

         }

 });

}

});

</script>

@endsection