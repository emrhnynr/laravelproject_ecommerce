@extends('layouts.app')

@section('title') Home @endsection

@section('content')

 <!--==================== Slider Section Start ====================-->
        <!-- Slider HTML markup -->
        <div class="full-row p-0 overflow-hidden bg-white sm-mx-none">
            <div id="slider" style="width:100%; margin:0 auto; margin-bottom: 0px;">
                <!-- Slide 1-->
                <div class="ls-slide" data-ls="duration:12000; transition2d:4; kenburnsscale:1.2;">

                    <div style="width:100%; height:100%; top:50%; left:50%;" class="ls-l ls-hide-phone" data-ls="easingin:easeOutQuint; durationout:400; parallaxlevel:0; position:fixed;"></div>

                    <p style="font-weight:700; font-size:240px; line-height:240px; color:#fafafa; top:50%; left:50%;" class="ls-l" data-ls="offsetxin:left; durationin:3000; delayin:1000; easingin:easeOutExpo; offsetxout:right; durationout:500; rotatexin:20; scalexin:1; parallaxlevel:0;">OPTICAL</p>

                    <p style="width:580px; font-weight:500; font-size:18px; line-height:30px; text-transform: uppercase; top:10%; left:150px; white-space:normal;" class="ls-l ls-hide-phone text-dark ordenery-font" data-ls="offsetxin:150; durationin:700; easingin:easeOutBack; rotatexin:20; scalexin:1; offsetyout:600; durationout:400; parallaxlevel:0; delayin:300;">Starting At</p>

                    <p style="font-weight:700; width:700px; font-size:50px; line-height:76px; color:#181a1d; top:16%; left: 150px; white-space:normal;" class="ls-l ls-hide-phone higlight-font" data-ls="offsetxin:150; durationin:700; delayin:500; easingin:easeOutBack; rotatexin:20; scalexin:1; offsetyout:600; durationout:400; parallaxlevel:0;">
                        <small class="font-small">$</small><span class="text-primary">79.00</span>
                    </p>

                    <p style="width:180px; font-weight:600; font-size:16px; line-height:30px; text-transform: uppercase; top:20%; left:150px; white-space:normal;" class="ls-l ls-hide-phone ordenery-font" data-ls="offsetxin:150; durationin:700; easingin:easeOutBack; rotatexin:20; scalexin:1; offsetyout:600; durationout:400; parallaxlevel:0; delayin:700;">Frame + Lanse</p>

                    <p style="width:280px; font-weight:400; font-size:18px; line-height:30px; color:#333333; top:28%; left:150px; white-space:normal;" class="ls-l ls-hide-phone ordenery-font" data-ls="offsetxin:150; durationin:700; easingin:easeOutBack; rotatexin:20; scalexin:1; offsetyout:600; durationout:400; parallaxlevel:0; delayin:900;">Made for living in the moment, express your authentic style with Ray-Ban. You’re on.</p>

                    <img width="802" height="500" src="assets/images/slider/28.png" class="ls-l" alt="" style="top:50%; left:50%; text-align:initial; font-weight:400; font-style:normal; text-decoration:none;" data-ls="showinfo:1; offsetxin:300;">

                    <p style="text-align:left; white-space:pre-wrap; font-size:16px; font-weight: 400; line-height:30px; width:270px; top:75%; left:39.5%; white-space:normal;" class="ls-l" data-ls="offsetyin:40; delayin:2000; easingin:easeOutQuint; filterin:blur(10px); offsetyout:-200; durationin:1500; durationout:400; parallax:false; parallaxlevel:3">Per integer est egestas, maecenas eleifend. Varius iaculis pretium adipiscing.</p>

                    <p style="font-weight:600; text-transform: uppercase; text-align:left; width:200px; font-size:18px; line-height:80px; top:68%; left:37.5%; white-space:normal;" class="ls-l text-dark higlight-font" data-ls="offsetyin:40; delayin:1500; easingin:easeOutQuint; filterin:blur(10px); offsetyout:-200; durationin:1500; durationout:400; parallax:false; parallaxlevel:3;">Since <span class="text-primary">1986</span></p>

                    <div style="font-size:15px; top:58%; left:34%" class="ls-l ls-hide-phone ls-hide-tablet" data-ls="offsetyin:40; delayin:1000; easingin:easeOutQuint; offsetyout:-300; durationin:1500; durationout:400; parallax:false; parallaxlevel:1;">
                        <div class="simple-video-play d-table ml-auto mt-3">
                            <a data-fancybox href="https://www.youtube.com/watch?v=bh-klGboIg8" class="rounded-circle bg-primary"><i class="flaticon-right-arrow-black-triangle position-relative xy-center flat-mini rounded-circle text-white"></i></a>
                        </div>
                    </div>

                    <img width="490" height="180" src="assets/images/slider/29.png" class="ls-l ls-hide-phone ls-hide-tablet" alt="" style="top:35%; left:62%; text-align:initial; font-weight:400; font-style:normal; text-decoration:none;" data-ls="showinfo:1; offsetxin:300; delayin:300;">

                    <p style="text-align:left; white-space:pre-wrap; font-size:16px; font-weight: 400; line-height:30px; width:270px; top:28%; left:82%; white-space:normal;" class="ls-l text-dark ls-hide-phone ls-hide-tablet" data-ls="offsetyin:40; delayin:1000; easingin:easeOutQuint; filterin:blur(10px); offsetyout:-200; durationin:1500; durationout:400; parallax:false; parallaxlevel:3">With safety glasses tight, youll surely keep your sight.</p>

                    <img width="177" height="26" src="assets/images/slider/30.png" class="ls-l ls-hide-phone ls-hide-tablet" alt="" style="top:39%; left:70%; text-align:initial; font-weight:400; font-style:normal; text-decoration:none;" data-ls="showinfo:1; offsetxin:300; delayin:500;">

                    <p style="text-align:left; white-space:pre-wrap; font-size:16px; font-weight: 400; line-height:30px; width:270px; top:39%; left:82%; white-space:normal;" class="ls-l text-dark ls-hide-phone ls-hide-tablet" data-ls="offsetyin:40; delayin:1200; easingin:easeOutQuint; filterin:blur(10px); offsetyout:-200; durationin:1500; durationout:400; parallax:false; parallaxlevel:3">Strong Optical Frame.</p>

                    <img width="177" height="26" src="assets/images/slider/30.png" class="ls-l ls-hide-phone ls-hide-tablet" alt="" style="top:50%; left:70%; text-align:initial; font-weight:400; font-style:normal; text-decoration:none;" data-ls="showinfo:1; offsetxin:300; delayin:700;">

                    <p style="text-align:left; white-space:pre-wrap; font-size:16px; font-weight: 400; line-height:30px; width:270px; top:50%; left:82%; white-space:normal;" class="ls-l text-dark ls-hide-phone ls-hide-tablet" data-ls="offsetyin:40; delayin:1400; easingin:easeOutQuint; filterin:blur(10px); offsetyout:-200; durationin:1500; durationout:400; parallax:false; parallaxlevel:3">Keep Calm and Wear Glasses</p>

                </div>
            </div>
        </div>
        <!--==================== Slider Section End ====================-->

        @foreach($homelist as $list)

        <?php 

        $list_id = $list->list_id;
        $list = \App\Models\Homelist::where('list_id','=',$list_id)->first();

        $products = $list->products;
      
         ?>

        <div class="full-row">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-8">
                        <h3 class="main-title down-line mb-5 text-center text-dark text-uppercase">{{ $list->list_name }}</h3>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12">
                        <div class="products product-style-1 owl-mx-15">
                            <div class="owl-carousel four-carousel dot-active-one nav-arrow-middle-show e-title-general e-title-hover-primary e-image-bg-gray e-hover-image-zoom e-info-center">
                                

                           
                            

                           @foreach($products as $product)


                           <?php 
                                
                                $product_id = $product->product_id;
                                $product_name = $product->product_name;
                                $product_slug = $product->product_slug;
                                $product_coverimage = $product->product_coverimage;
                                $product_price = $product->product_price;
                                $product_sale = $product->product_sale;
                                $brand_name = $product->brand_name;                               
  
                           ?>
                               
                            


                                <div class="item">
                                    <div class="product type-product">
                                        <div class="product-wrapper">
                                            <div class="product-image">

                                                 <a href="{{ route('product_details', ['product_slug' => $product_slug, 'product_id' => $product_id]) }}" class="woocommerce-LoopProduct-link"><img src="{{ asset($product_coverimage) }}" alt="Product Image"></a>
                                                
                                            </div>
                                            <div class="product-info">
                                                <h4 class="product-brandname">{{ $brand_name }}</h4>
                                                <h3 class="product-title"><a href="{{ route('product_details', ['product_slug' => $product_slug, 'product_id' => $product_id]) }}">{{ $product_name }}</a></h3>
                                                <div class="product-price">
                                                    <div class="price">
                                                        

                                                       @if($product_sale==1)

                                                       <ins><del>{{ $product->product_nodiscount_price }}</del> - {{ $product_price }} USD</ins>

                                                       @else

                                                       <ins>{{ $product->product_nodiscount_price }} USD</ins>

                                                       @endif
                                                    
                                                    </div>
                                                </div>
                                                
                                            </div>
                                        </div>
                                    </div>
                                </div>



                           @endforeach

                           


                              




                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        @endforeach

       

        

       

     

       

@endsection


