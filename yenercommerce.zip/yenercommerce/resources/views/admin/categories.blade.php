@extends('admin.layouts.app')

@section('content')

<div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>
                    @if($category_top=='0')

                    Top Categories

                    @else

                    '{{$category->category_name}}' Sub Categories

                    @endif
                    </h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <a target="_blank" class="btn btn-success" href="{{ route('admin.add_category', ['category_top' => '0']) }}">Add Sub Category +</a>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">



                    


                    @if (count($categories)==0)

                    <h4 align="center">Sub-Categories Not Found.</h4>


                    @else

                    <table id="datatable" class="table table-striped table-bordered">
                      <thead>
                        <tr>
                         
                          <th>Category Name</th>
                          <th>Order</th>
                          <th>Status</th>

                          

                          
                          
                         
                          <th></th>
                          
                          
                          
                         
                        </tr>
                      </thead>


                      <tbody>

        

        @foreach($categories as $categoryx)

        <?php 

        $category_id = $categoryx['category_id'];
        $category_name = $categoryx['category_name'];
        $category_order = $categoryx['category_order'];
        $category_active = $categoryx['category_active']; 

        ?>

        <tr class="category_<?php echo $category_id; ?>">
                          
                          

        <td><?php echo $category_name; ?></td>
        <td><?php echo $category_order; ?></td>

        @if($category_active=='1')

        <td style="color: green;">Active</td>

        @else

        <td style="color: red;">Not Active</td>

        @endif
                                       
        <td align="right">

        <a class="btn btn-warning btn-sm" href="{{ route('admin.edit_category', ['category_id' => $category_id]) }}">Edit</a>

        <a class="btn btn-primary btn-sm" href="{{ route('admin.categories', ['category_top' => $category_id]) }}">Sub-Categories</a>

        

        
        </td>



                            

                            

                         </div>
                        
                          
                          
        </tr>
          
       
        @endforeach

                        
                        
                        
                      </tbody>
                    </table>


        @endif



                   
                    
                  </div>
                </div>
              </div>

             

              

            </div>

@endsection