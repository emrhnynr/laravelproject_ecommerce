@extends('admin.layouts.app')

@section('content')

            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">

<div class="x_title">
                    <h2>General Settings</h2>
                    
                    <div class="clearfix"></div>
                  </div>

<div class="x_content">
                    <br />
                    <form id="demo-form2" class="form-horizontal form-label-left settingsform" onsubmit="return false;">

                      @csrf

                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name">Phone Number
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input type="text" id="first-name" value="{{ $settings->phonenumber }}" maxlength="30" name="phonenumber" class="form-control col-md-7 col-xs-12">
                        </div>
                      </div>
                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Mail
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input type="email" id="last-name" name="mail" value="{{ $settings->mail }}" maxlength="150" class="form-control col-md-7 col-xs-12">
                        </div>
                      </div>
                      <div class="form-group">
                        <label for="middle-name" class="control-label col-md-3 col-sm-3 col-xs-12">Address</label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                         <textarea name="address" maxlength="1000" class="form-control" rows="6" cols="4">{{ $settings->address }}</textarea>
                        </div>
                      </div>
                      
                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12">Shipping Fee 
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input id="birthday" value="{{ $settings->shipping_fee }}" max="100" name="shipping_fee" class="form-control col-md-7 col-xs-12" step="any" required="required" type="number">
                        </div>
                      </div>

                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12">Free Shipping Limit (USD) 
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input id="birthday" max="999999" value="{{ $settings->freeshipping }}" name="freeshipping" class="form-control col-md-7 col-xs-12" step="any" required="required" type="number">
                        </div>
                      </div>

                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name">Instagram Link
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input type="text" id="first-name" value="{{ $settings->instagram_link }}" maxlength="30" name="instagram_link" class="form-control col-md-7 col-xs-12">
                        </div>
                      </div>

                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name">Facebook Link
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input type="text" id="first-name" value="{{ $settings->facebook_link }}" maxlength="30" name="facebook_link" class="form-control col-md-7 col-xs-12">
                        </div>
                      </div>

                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name">Twitter Link
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input type="text" id="first-name" value="{{ $settings->twitter_link }}" maxlength="30" name="twitter_link" class="form-control col-md-7 col-xs-12">
                        </div>
                      </div>

                      <div class="ln_solid"></div>
                      <div class="form-group">
                        <div align="right" class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">

                          <div align="left" class="alert alert-success successalert" style="display: none;"></div>
                         
                          <button id="submitbtn" type="submit" class="btn btn-success">Submit</button>

                        </div>
                      </div>

                    </form>
                  </div>
              </div>
          </div>
      </div>

@endsection


@section('extrascript')

<script type="text/javascript">
	
$('.settingsform').submit(function(){

$('#submitbtn').attr('disabled',true);
$('#submitbtn').html('Submitting...');

var data = $(".settingsform").serializeArray();
var csrf_token = $("input[name=_token]").val();
data.push({name: "_token", value: csrf_token});


$.ajax({

type : 'POST',
url : '/admin/general_settings_process',
data : $.param(data),
success : function(sonuc){


sonuc = $.trim(sonuc);



if (sonuc=='ok') {


$('#submitbtn').attr('disabled',false);
$('#submitbtn').html('Submit');
$('.successalert').show(); 
$('.successalert').html('<i class="fa fa-check"></i> Settings has been updated.');


}

}

});

});

</script>

@endsection