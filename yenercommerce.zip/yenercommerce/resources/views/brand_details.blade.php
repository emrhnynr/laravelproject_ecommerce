@extends('layouts.app')

@section('title') {{$brand->brand_name}} Products @endsection

@section('content')


@php 

$brand_id = $brand->brand_id;
$brand_slug = $brand->brand_slug;

@endphp

<!-- breadcrumb -->
        <div class="full-row py-5">
            <div class="container">
                <div class="row text-center">
                    <div class="col-12">
                        <h3 class="mb-2">{{$brand->brand_name}} Products</h3>
                    </div>
                    <div class="col-12">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb mb-0 d-inline-flex bg-transparent p-0">
                                <li class="breadcrumb-item"><a href="{{route('home')}}">Home</a></li>
                                <li class="breadcrumb-item"><a href="{{route('brands')}}">Brands</a></li>
                                <li class="breadcrumb-item active" aria-current="page">{{ $brand->brand_name }}</li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
        <!-- breadcrumb -->

        <div class="full-row pt-0">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                       
                        <div class="showing-products pt-30 pb-50 border-2 border-bottom border-light">
                            <div class="row row-cols-xl-5 row-cols-md-3 row-cols-sm-2 row-cols-1 product-style-3 e-hover-image-zoom e-image-bg-light g-4">

                                @foreach($products as $product)

                                <?php 
                                
                                $product_id = $product->product_id;
                                $product_name = $product->product_name;
                                $product_slug = $product->product_slug;
                                $product_coverimage = $product->product_coverimage;
                                $product_price = $product->product_price;
                                $product_sale = $product->product_sale;
                                $brand_name = $product->brand_name;                               
  
                                ?>


                                <div class="col">
                                    <div class="product type-product">
                                        <div class="product-wrapper">
                                            <div class="product-image">
                                                <a href="{{ route('product_details', ['product_slug' => $product_slug, 'product_id' => $product_id]) }}" class="woocommerce-LoopProduct-link"><img src="{{ asset($product_coverimage) }}" alt="Product Image"></a>
                                               
                                                <div class="wishlist-view">
                                                    
                                                </div>
                                                <div class="product-labels">

                                                    @if($product_sale==1)

                                                    <div class="shape1-badge3"><span>Sale</span></div>

                                                    @endif
                                                    
                                                </div>
                                            </div>
                                            <div class="product-info">
                                               
                                                <h4 class="product-brandname">{{ $brand_name }}</h4>
                                                <h3 class="product-title"><a href="{{ route('product_details', ['product_slug' => $product_slug, 'product_id' => $product_id]) }}">{{ $product_name }}</a></h3>
                                                <div class="product-price">
                                                    <div class="price">

                                                       @if($product_sale==1)

                                                       <ins><del>{{ $product->product_nodiscount_price }}</del> - {{ $product_price }} USD</ins>

                                                       @else

                                                       <ins>{{ $product->product_nodiscount_price }} USD</ins>

                                                       @endif
                                                    </div>
                                                </div>
                                                
                                               
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                @endforeach


                                
                            </div>
                        </div>

                       

                       
                        


                        @if($productscount > $resultsperpage)




                        <div class="d-flex justify-content-between align-items-center pt-3">
                            
                            <div class="pagination-style-one">
                                <nav aria-label="Page navigation example">
                                    <ul class="pagination">

                                    @if($page!=1)

                                        <li class="page-item">
                                            <a class="page-link" href="/brands/{{$brand_slug}}/{{$brand_id}}?page={{$page-1}}" aria-label="Previous">
                                                <span aria-hidden="true">&laquo;</span>
                                            </a>
                                        </li>

                                    @endif    

                                    @for($i=1; $i <= $countofpages; $i++)

                                        <li class="page-item"><a class="page-link" href="/brands/{{$brand_slug}}/{{$brand_id}}?page={{$i}}">{{ $i }}</a></li>

                                    @endfor    

                                    @if($page!=$countofpages)    
                                        
                                        <li class="page-item">
                                            <a class="page-link" href="/brands/{{$brand_slug}}/{{$brand_id}}?page={{$page+1}}" aria-label="Next">
                                                <span aria-hidden="true">&raquo;</span>
                                            </a>
                                        </li>

                                    @endif
                                        
                                    </ul>
                                </nav>
                            </div>
                        </div> 


                        @endif


                        
                    </div>
                </div>
            </div>
        </div>

@endsection