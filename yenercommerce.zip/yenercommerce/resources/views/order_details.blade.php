@extends('layouts.app')

@section('title') Order Details @endsection

@section('content')

<!--==================== Checkout Section Start ====================-->
<div id="main-content" class="full-row site-content">
<div class="container">
<div class="row ">
<div id="primary" class="content-area col-md-12">
<article id="post-19" class="post-19 page type-page status-publish hentry">
<div class="entry-content">
<div class="woocommerce">
                                    
<form onsubmit="return false;" class="checkout woocommerce-checkout" id="checkoutform">
<div class="row">

                                            
<div class="col-lg-6">
<div class="col2-set" id="customer_details">
<div class="woocommerce-billing-fields">
<h3 style="font-family: Arial;font-weight: 200;">Order Details</h3>

<?php

$created_at = $order->created_at;
$d = new DateTime($created_at);
$order_date =  $d->format('d/m/Y'); 

?>

@switch ($order->order_status)

@case ('preparing')

<h5 style="color:#FA3B12;font-family: Arial;font-weight: 200;"><i class="far fa-clock"></i> Preparing</h5>

@break
                            
case ('onshipping')
                                
<h5 style="color:#225E88;font-family: Arial;font-weight: 200;"><i class="fas fa-truck"></i> On Shipping</h5>
                               
@break

@case ('delivered')

<h5 style="color:green;font-family: Arial;font-weight: 200;"><i class="fas fa-check"></i> Delivered</h5>
                                
@break

@endswitch

<hr>
<div class="woocommerce-billing-fields__field-wrapper">

<div class="row">

<div class="col-lg-6 col-md-6 col-xs-12">

<p class="form-row form-row-first validate-required" id="billing_first_name_field" data-priority="10">
<label for="billing_first_name" class="">Order ID&nbsp;<abbr class="required" title="required"></abbr></label>
<span class="woocommerce-input-wrapper">
<input type="text" readonly="" class="input-text" value="{{ $order->order_id }}">
</span>
</p>

                                                             </div>

                                                            <div class="col-lg-6 col-md-6 col-xs-12">


                                                            <p class="form-row form-row-first validate-required" id="billing_first_name_field" data-priority="10">
                                                                <label for="billing_first_name" class="">Order Date&nbsp;<abbr class="required" title="required"></abbr></label>
                                                                <span class="woocommerce-input-wrapper">
                                                                    <input type="text" readonly="" class="input-text" value="{{ $order_date }}">
                                                                </span>
                                                            </p>

                                                            </div>

                                                            <div class="col-lg-6 col-md-6 col-xs-12">


                                                            <p class="form-row form-row-first validate-required" id="billing_first_name_field" data-priority="10">
                                                                <label for="billing_first_name" class="">Count of Products&nbsp;<abbr class="required" title="required"></abbr></label>
                                                                <span class="woocommerce-input-wrapper">
                                                                    <input type="text" readonly="" class="input-text" value="{{ count($orderproducts) }}">
                                                                </span>
                                                            </p>

                                                            </div>

                                                            <div class="col-lg-6 col-md-6 col-xs-12">


                                                            <p class="form-row form-row-first validate-required" id="billing_first_name_field" data-priority="10">
                                                                <label for="billing_first_name" class="">Phone Number&nbsp;<abbr class="required" title="required"></abbr></label>
                                                                <span class="woocommerce-input-wrapper">
                                                                    <input type="text" readonly="" class="input-text" value="{{ $order->order_phonenumber }}">
                                                                </span>
                                                            </p>

                                                            </div>

                                                            <div class="col-lg-6 col-md-6 col-xs-12">


                                                            <p class="form-row form-row-first validate-required" id="billing_first_name_field" data-priority="10">
                                                                <label for="billing_first_name" class="">First Name&nbsp;<abbr class="required" title="required"></abbr></label>
                                                                <span class="woocommerce-input-wrapper">
                                                                    <input type="text" readonly="" class="input-text" value="{{ $order->order_firstname }}">
                                                                </span>
                                                            </p>

                                                            </div>

                                                            <div class="col-lg-6 col-md-6 col-xs-12">


                                                            <p class="form-row form-row-first validate-required" id="billing_first_name_field" data-priority="10">
                                                                <label for="billing_first_name" class="">Last Name&nbsp;<abbr class="required" title="required"></abbr></label>
                                                                <span class="woocommerce-input-wrapper">
                                                                    <input type="text" readonly="" class="input-text" value="{{ $order->order_lastname }}">
                                                                </span>
                                                            </p>

                                                            </div>

                                                            <div class="col-lg-6 col-md-6 col-xs-12">


                                                            <p class="form-row form-row-first validate-required" id="billing_first_name_field" data-priority="10">
                                                                <label for="billing_first_name" class="">Shipping Fee&nbsp;<abbr class="required" title="required"></abbr></label>
                                                                <span class="woocommerce-input-wrapper">
                                                                    <input type="text" readonly="" class="input-text" value="{{ $order->order_shipping_fee }}">
                                                                </span>
                                                            </p>

                                                            </div>

                                                            <div class="col-lg-6 col-md-6 col-xs-12">


                                                            <p class="form-row form-row-first validate-required" id="billing_first_name_field" data-priority="10">
                                                                <label for="billing_first_name" class="">Location&nbsp;<abbr class="required" title="required"></abbr></label>
                                                                <span class="woocommerce-input-wrapper">
                                                                    <input type="text" readonly="" class="input-text" value="{{ $order->order_location }}">
                                                                </span>
                                                            </p>

                                                            </div>

                                                            <div class="col-lg-12 col-md-12 col-xs-12">


                                                            <p class="form-row form-row-first validate-required" id="billing_first_name_field" data-priority="10">
                                                                <label for="billing_first_name" class="">Sipariş Adresi&nbsp;<abbr class="required" title="required"></abbr></label>
                                                                <span class="woocommerce-input-wrapper">
                                                    <textarea readonly="" class="input-text" rows="3" cols="5">{{ $order->order_address }}</textarea>
                                                                </span>
                                                            </p>

                                                            </div>

                                                         @if(!empty($order->order_note))


                                                            <div class="col-lg-12 col-md-12 col-xs-12">


                                                            <p class="form-row form-row-first validate-required" id="billing_first_name_field" data-priority="10">
                                                                <label for="billing_first_name" class="">Order Note&nbsp;<abbr class="required" title="required"></abbr></label>
                                                                <span class="woocommerce-input-wrapper">
                                                        <textarea readonly="" class="input-text" rows="3" cols="5">{{ $order->order_note }}</textarea>
                                                                </span>
                                                            </p>

                                                            </div>

                                                         @endif




                                                           


                                                           
                                                            


                                                            </div>
                                                            
                                                        </div>
                                                    </div>

                                                    
                                                    
                                                </div>
                                            </div>
                                            <div class="col-lg-6">
                                                


                                                
                                    <div class="order-review-inner">
                                    <h3 style="font-family: arial;font-weight: 200;" id="order_review_heading">Products</h3>
                                    <div id="order_review" class="woocommerce-checkout-review-order">
                                    <table class="shop_table woocommerce-checkout-review-order-table">
                                    <thead>
                                    <tr>


                                    <th class="product-name">Product</th>
                                    <th class="product-total">Price</th>
                                    <th class="product-total">Quantity</th>
                                    <th class="product-total">Subtotal</th>

                                                                        
                                    </tr>
                                    </thead>
                                    <tbody>

                                    @foreach($orderproducts as $orderproduct)


                                    <?php 

                                    $product_id = $orderproduct->product_id;
                                    $product = \App\Models\Product::find($product_id);
                                    $brand_name = $product->brand_name;
                                    $product_name = $product->product_name;
                                    $product_slug = $product->product_slug;

                                    $product_price = $orderproduct->product_price;
                                    $product_quantity = $orderproduct->product_quantity;
                                    $product_total = $orderproduct->product_total;
                                    

                                    ?>
                                                                       
                                                                
                                    <tr class="cart_item">
                                        
                                    <td class="product-name">
                                     <a target="_blank" href="{{ route('product_details', ['product_slug' => $product_slug, 'product_id' => $product_id]) }}">
                                        {{$brand_name}} {{$product_name}}
                                     </a>
                                    </td>

                                    <td class="product-name">{{ $product_price }} USD</td>
                                    <td class="product-name">{{ $product_quantity }}</td>
                                    <td class="product-name">{{ $product_total }} USD</td>

                                    </tr>

                                    @endforeach
                                    
                                    </tbody>
                                    
                                    <tfoot>
                                    
                                    <tr class="cart-subtotal">
                                    
                                    <th>Sub-Total</th>
                                    
                                    <td><span class="woocommerce-Price-amount amount"><bdi>{{ $order->order_subtotal }} USD</bdi>
                                    
                                    </span>
                                    
                                    </td>
                                    
                                    </tr>
                                                            
                                    
                                    <tr class="order-total">
                                    
                                    <th>Interest</th>
                                    <td><strong><span class="woocommerce-Price-amount amount"><bdi>{{ $order->order_interest }} USD</bdi></span></strong> </td>
                                    
                                    </tr>


                                    <tr class="order-total">
                                    
                                    <th>Shipping Fee</th>
                                    
                                    <td><strong><span class="woocommerce-Price-amount amount"><bdi>{{ $order->order_shipping_fee }} USD</bdi></span></strong> </td>
                                    
                                    </tr>


                                    <tr class="order-total">
                                    <th>Total</th>
                                    <td><strong><span class="woocommerce-Price-amount amount"><bdi>{{ $order->order_total }} USD</bdi></span></strong> </td>
                                    </tr>
                                                            
                                    </tfoot>
                                    </table>
                                                        
                                    </div>
                                    </div>
                                            
                                            


                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                            <!-- .entry-content -->
                        </article>
                        <!-- #post-## -->
                    </div>
                    <!-- .entry-content-wrapper -->
                </div>
                <!-- .row -->
            </div>
            <!-- .container -->
        </div>
        <!--==================== Checkout Section End ====================-->

@endsection