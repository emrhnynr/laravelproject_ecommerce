<!DOCTYPE html>
<html lang="en">

<?php

 use App\Models\Category;


 if (Auth::guard('user')->check() and $user->user_banned=='1') { ?>
          
 <script>

 window.onload = function(){ document.getElementById('logoutform').submit() }

</script>

 <?php } ?>

 

<head>
    <!-- Meta Tag -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Yener Commerce">

    <meta name="author" content="root">
    
    <title>@yield('title') | Yener Commerce</title>

    <!-- Favicon -->
    <link rel="shortcut icon" href="{{asset('assets/images/favicon.png')}}">

    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css2?family=Jost:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">

    <!--  CSS Style -->
    <link rel="stylesheet" href="{{asset('assets/css/bootstrap.min.css')}}">
    <link rel="stylesheet" href="{{asset('assets/css/all.min.css')}}">
    <link rel="stylesheet" href="{{asset('assets/css/animate.min.css')}}">
    <link rel="stylesheet" href="{{asset('assets/webfonts/flaticon/flaticon.css')}}">
    <link rel="stylesheet" href="{{asset('assets/css/owl.carousel.min.css')}}">
    <link rel="stylesheet" href="{{asset('assets/css/jquery.fancybox.min.css')}}">
    <link rel="stylesheet" href="{{asset('assets/css/layerslider.css')}}">
    <link rel="stylesheet" href="{{asset('assets/css/template.css')}}">
    <link rel="stylesheet" href="{{asset('assets/css/style.css')}}">
    <link rel="stylesheet" href="{{asset('assets/css/category/optical-shop.css')}}">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" integrity="sha512-9usAa10IRO0HhonpyAIVpjrylPvoDwiPUiKdWk5t3PyolY1cOd4DSE0Ga+ri4AuTroPR5aQvXU9xC6qOPnzFeg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    
    @yield('extralink')


    @yield('extrastyle')

</head>

<body>

    <div id="page_wrapper" class="bg-light">
        <!--==================== Header Section Start ====================-->
        <header class="ecommerce-header bg-white p-0">
            <div class="top-header d-none d-lg-block py-2 border-0 font-400">
                <div class="container-lg-fluid px-lg-5">
                    <div class="row align-items-center">
                        <div class="col-lg-4 sm-mx-none">
                           
                        </div>
                        <div class="col-lg-8 d-flex">

        

                            <ul class="top-links d-flex ms-auto align-items-center">

                                @auth('user')
                               
                                <li class="my-account-dropdown">
                                    <a style="cursor: pointer;" class="has-dropdown"><i class="flaticon-user-3 flat-mini me-1"></i>Hi, {{$user->user_name}}</a>
                                    <ul class="my-account-popup">

                                        <li><a href="{{ route('my-account') }}"><span class="menu-item-text">My Account</span></a></li>
                                        <li><a href="{{ route('change-password') }}"><span class="menu-item-text">Change Password</span></a></li>
                                        <li><a href="{{ route('cart') }}"><span class="menu-item-text">Cart</span></a></li>
                                        <li><a href="{{ route('orders') }}"><span class="menu-item-text">Orders</span></a></li>
                                        <li><a href="javascript:void(0)" onclick=" $('#logoutform').submit(); ">Logout</a></li>

                                        <form id="logoutform" action="{{ route('userlogout') }}" method="POST">
                                            
                                        @csrf    

                                        </form>

                                    </ul>
                                </li>

                                @endauth

                                @guest('user')


                                <li class="my-account-dropdown">
                                    <a style="cursor: pointer;" class="has-dropdown"><i class="flaticon-user-3 flat-mini me-1"></i>Sign-In / Sign-Up</a>
                                    <ul class="my-account-popup">

                                        <li><a href="{{route('signin')}}"><span class="menu-item-text">Sign-In</span></a></li>
                                        <li><a href="{{route('signup')}}"><span class="menu-item-text">Sign-Up</span></a></li>
                                       
                                    </ul>
                                </li>

                                @endguest

                            </ul>
                        </div>
                    </div>
                </div>
            </div>



            <div class="main-nav py-4 d-none d-lg-block">
                <div class="container-fluid px-lg-5">
                    <div class="row">
                        <div class="col-xl-7 col-md-9">
                            <nav class="navbar navbar-expand-lg nav-dark nav-primary-hover nav-line-active">
                                <a class="navbar-brand" href="{{route('home')}}"><img class="nav-logo" src="{{asset('assets/images/logo/12.png')}}" alt="Image not found !"></a>
                                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                                <i class="flaticon-menu-2 flat-small text-primary"></i>
                                </button>
                                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                                    <ul class="navbar-nav ms-lg-5">
                                        <li class="nav-item dropdown">
                                            <a class="nav-link" href="{{route('home')}}">Home</a>


                                            
                                        </li>

                                       @foreach($top_categories as $top_category)

                                       <?php

                                       $category_id = $top_category->category_id;
                                       $category_slug = $top_category->category_slug;
                                       $category_name = $top_category->category_name;
                                       $bottomcategories1 = Category::where('category_top', '=' ,$category_id)->where('category_active','=','1')->orderBy('category_order','ASC')->get();
                                       $bottomcount = count($bottomcategories1); ?>

                                       
                                        <li class="nav-item dropdown mega-dropdown">
                                            <a class="nav-link dropdown-toggle" href="

                                            {{  route('category_details', ['category_slug' => $category_slug, 'category_id' => $category_id])  }}

                                            ">{{ $category_name }}</a>

                                 
                                       @if ($bottomcount!=0)



                                            <ul class="dropdown-menu mega-dropdown-menu">
                                                <li class="mega-container">

                                        
                                        

                                        <div class="row row-cols-lg-4 row-cols-sm-2 row-cols-1">

                                    
                                        @foreach($bottomcategories1 as $category)

                                        <?php

                                        $category_id = $category->category_id;
                                        $category_slug = $category->category_slug;
                                        $category_name = $category->category_name;

                                        $bottomcategories2 = Category::where('category_top', '=' ,$category_id)->where('category_active','=','1')->orderBy('category_order','ASC')->get();

                                        $bottomcount = count($bottomcategories2);

                                        ?>
                                        
                                        <div class="col">
                                         
                                        

                                        <a href="

                                            {{  route('category_details', ['category_slug' => $category_slug, 'category_id' => $category_id])  }}

                                            "><span class="d-inline-block px-3 font-600 text-uppercase text-secondary pb-2">{{ $category_name; }}</span></a>

                                        @if($bottomcount!=0)

                                        <ul>
                                        
                                        @foreach($bottomcategories2 as $category)

                                        <?php

                                        $category_id = $category->category_id;
                                        $category_slug = $category->category_slug;
                                        $category_name = $category->category_name;

                                        ?>

                                        <li><a class="dropdown-item" href="

                                            {{  route('category_details', ['category_slug' => $category_slug, 'category_id' => $category_id])  }}

                                            ">{{ $category_name }}</a></li>

                                        @endforeach
                                        
                                        </ul>

                                        @endif


                                        </div>

                                   

                                        @endforeach

                                                        
                                                        
                                                    </div>

                                         
                                                    
                                                </li>
                                            </ul>
                                      


                                        @endif
                                          

                                        </li>

                                        @endforeach

                                        <li class="nav-item"><a class="nav-link" href="{{route('brands')}}">Brands</a></li>
                                       
                                        <li class="nav-item"><a class="nav-link" href="{{route('contact')}}">Contact</a></li>
                                    </ul>
                                </div>
                            </nav>
                        </div>
                        <div class="col-xl-5 col-md-3">
                            <div class="margin-right-1 d-flex align-items-center justify-content-end h-100">
                                <div class="product-search-one flex-grow-1 global-search touch-screen-view">
                                    <form id="searchform" class="form-inline search-pill-shape" action="{{route('search')}}" method="GET">
                                        <input id="searchinput" type="text" class="form-control search-field" name="query" placeholder="Product Name, ID, Brand...">
                                        
                                        <button type="submit" class="search-submit"><i class="flaticon-search flat-mini text-white"></i></button>
                                    </form>
                                </div>
                                <div class="search-view d-xxl-none">
                                    <a href="#" class="search-pop top-quantity d-flex align-items-center text-decoration-none">
                                        <i class="flaticon-search flat-mini text-dark mx-auto"></i>
                                    </a>
                                </div>
                                <div class="wishlist-view">
                                    <a href="{{ route('wishlist') }}" class="position-relative top-quantity d-flex align-items-center text-white text-decoration-none">
                                        <i class="flaticon-like flat-mini text-dark mx-auto"></i>
                                    </a>
                                </div>
                                
                                <div class="header-cart-1">
                                    <a href="{{ route('cart') }}" class="cart" title="View Cart">

                                        <div class="cart-icon"><i class="flaticon-shopping-cart flat-mini"></i> <span class="header-cart-count">{{ $count_cart_products }}</span></div>
                                        
                                    </a>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
        </header>
        <!--==================== Header Section End ====================-->

        @yield('content')

        <!--==================== Footer Section Start ====================-->
        <footer class="full-row bg-white border-footer p-0">
            <div class="container">
                <div class="row row-cols-lg-4 row-cols-sm-2 row-cols-1">
                    <div class="col">
                        <div class="footer-widget mb-5">
                            <div class="footer-logo mb-4">
                                <a href="#"><img src="{{asset('assets/images/logo/12.png')}}" alt="Image not found!" /></a>
                            </div>
                            <div class="widget-ecommerce-contact">
                                <div class="text-general font-fifteen mt-20">Amazing; products, pricing, service.</div>
                            </div>
                        </div>
                       
                    </div>
                    <div class="col">
                        <div class="footer-widget category-widget mb-5">
                            <h6 class="widget-title mb-sm-4">Top Categories</h6>
                            <ul>
                            
                            @foreach($top_categories as $category)

            @php  $category_slug = $category->category_slug; $category_id = $category->category_id; $category_name = $category->category_name;  @endphp

                            <li><a href="{{ route('category_details', ['category_slug' => $category_slug, 'category_id' => $category_id]) }}">{{$category_name}}</a></li>

                            @endforeach
                                
                            </ul>
                        </div>
                    </div>
                    <div class="col">
                        <div class="footer-widget category-widget mb-5">
                            <h6 class="widget-title mb-sm-4">Pages</h6>
                            <ul>
                                <li><a href="#">About</a></li>
                                <li><a href="{{route('contact')}}">Contact</a></li>

                            </ul>
                        </div>
                    </div>
                    <div class="col">
                        <div class="footer-widget widget-nav mb-5">

                            <h6 class="widget-title mb-sm-4">SOCIAL</h6>
                             <div class="footer-widget media-widget">



                @if(!empty($settings->facebook_link)) <a target="_blank" href="{{$settings->facebook_link}}"><i class="fab fa-facebook-f"></i></a> @endif

                @if(!empty($settings->twitter_link)) <a target="_blank" href="{{$settings->twitter_link}}"><i class="fab fa-twitter"></i></a> @endif

                @if(!empty($settings->instagram_link)) <a target="_blank" href="{{$settings->instagram_link}}"><i class="fab fa-instagram"></i></a> @endif

                            
                           
                            
                            
                        </div>

                        </div>
                    </div>
                </div>
            </div>
        </footer>
        

        <!--==================== Copyright Section Start ====================-->
        <div class="full-row copyright bg-white py-3">
            <div class="container">
                <div class="row">
                    <div class="col-md-6">
                        <span class="sm-mb-10 d-block">{{$settings->footertext}}</span>
                    </div>
                    <div class="col-md-6">
                        <ul class="list-ml-30 d-flex align-items-center justify-content-md-end">
                            <li>
                                <a><img src="assets/images/cards/1.png" alt=""></a>
                            </li>
                            <li>
                                <a><img src="assets/images/cards/2.png" alt=""></a>
                            </li>
                            <li>
                                <a><img src="assets/images/cards/3.png" alt=""></a>
                            </li>
                            <li>
                                <a><img src="assets/images/cards/4.png" alt=""></a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <!--==================== Copyright Section End ====================-->

        <!-- Scroll to top -->
        <a href="#" class="bg-primary text-white" id="scroll"><i class="fa fa-angle-up"></i></a>
        <!-- End Scroll To top -->



    </div>



    <!-- Include Scripts -->
    <script src="{{asset('assets/js/jquery.min.js')}}"></script>
    <script src="{{asset('assets/js/greensock.js')}}"></script>
    <script src="{{asset('assets/js/layerslider.transitions.js')}}"></script>
    <script src="{{asset('assets/js/layerslider.kreaturamedia.jquery.js')}}"></script>
    <script src="{{asset('assets/js/popper.min.js')}}"></script>
    <script src="{{asset('assets/js/bootstrap.min.js')}}"></script>
    <script src="{{asset('assets/js/owl.carousel.min.js')}}"></script>
    <script src="{{asset('assets/js/wow.js')}}"></script>
    <script src="{{asset('assets/js/jquery.fancybox.min.js')}}"></script>
    <script src="{{asset('assets/js/jquery.countdown.js')}}"></script>
    <script src="{{asset('assets/js/jquery.elevatezoom.js')}}"></script>
    <script src="{{asset('assets/js/paraxify.js')}}"></script>
    <script src="{{asset('assets/js/custom.js')}}"></script>

    

    <!-- Initializing the slider -->
    <script>
        $(document).ready(function() {
            $('#slider').layerSlider({
                sliderVersion: '6.0.0',
                type: 'responsive',
                responsiveUnder: 0,
                maxRatio: 1,
                hideUnder: 0,
                hideOver: 100000,
                skin: 'v6',
                navStartStop: false,
                skinsPath: '/assets/skins/',
                height: 960
            });
        });
    </script>

    <script type="text/javascript">
        
    $('#searchform').submit(function(event){

    var length = $.trim($('#searchinput').val()).length;

    if (length==0) {

    event.preventDefault();

    $('#searchinput').css('border','1px solid #33C6CC');

    }

    });

    </script>

    @yield('extrascript')




</body>

</html>

<!--==================== Footer Section End ====================-->