@extends('layouts.app')

@section('title') Cart @endsection

@section('content')

<!-- breadcrumb -->
        <div class="full-row bg-light py-5">
            <div class="container">
                <div class="row text-secondary">
                    <div class="col-sm-6">
                        <h3 class="mb-2 text-secondary">Cart</h3>
                    </div>
                    <div class="col-sm-6">
                        
                    </div>
                </div>
            </div>
        </div>
        <!-- breadcrumb -->

        <!--==================== Cart Section Start ====================-->
        <div class="full-row">
            <div class="container">

                @if($count_cartproducts==0)

                <p style="font-size: 22px;" align="center"><i class="fa fa-shopping-cart"></i><br>There is no item in your cart yet. <br> <a href="{{route('home')}}">Keep Shopping</a></p>

                @else

                <div class="row contentt">
                    <div class="col-xl-8 col-lg-12 col-md-12 col-12">
                        <form class="woocommerce-cart-form" action="#" method="post">
                            <table class="shop_table cart">
                                <tr>
                                    <th class="product-thumbnail">&nbsp;</th>
                                    <th class="product-name">Product</th>
                                    <th class="product-price">Unit Price</th>
                                    <th class="product-quantity">Quantity</th>
                                    <th class="product-subtotal">Subtotal</th>
									<th class="product-remove">&nbsp;</th>
                                </tr>


                                @php

                                $total = 0;

                                @endphp


                                @foreach($cartproducts as $cartproduct)

                                <?php 
                                
                                $cartproduct_id = $cartproduct->cartproduct_id;
                                $quantity = $cartproduct->product_quantity;
                                $product_id = $cartproduct->product_id;

                                $product = \App\Models\Product::where('product_id','=',$product_id)->first();

                                $brand_name = $product->brand_name;
                                $product_name = $product->product_name;
                                $product_coverimage = $product->product_coverimage;
                                $product_slug = $product->product_slug;

                                if ($product->product_sale=='1') {
                                    
                                $product_price = $product->product_price;

                                } else {

                                $product_price = $product->product_nodiscount_price;

                                }


                                $subtotal = $product_price*$quantity;
                                $total += $subtotal;


                                
 
                                ?>
                             
                                <tr class="woocommerce-cart-form__cart-item cart_item">
                                    <td class="product-thumbnail">
                                        <a target="_blank" href="{{ route('product_details', ['product_slug' => $product_slug, 'product_id' => $product_id]) }}"><img src="{{ asset($product_coverimage) }}" alt="Product image"></a>
                                    </td>
                                    <td class="product-name">

                                        <a target="_blank" href="{{ route('product_details', ['product_slug' => $product_slug, 'product_id' => $product_id]) }}">{{$brand_name}} <br>

                                        <span style="color: #707070;">

                                        @if(strlen($product_name)>50)

                                        {{substr($product_name,0,50)}}...

                                        @else

                                        {{$product_name}}

                                        @endif

                                        </span>



                                        </a>
                                        
                                    </td>
                                    <td class="product-price">
                                        
                                        @if($product->product_sale==1)

                                        <span style="color: #0A327B;">{{ $product_price }} USD</span>

                                        @else

                                        <span style="color: #0A327B;">{{ $product->product_nodiscount_price }} USD</span>

                                        @endif

                                    </td>
                                    <td class="product-quantity">

                                        @if($quantity!=1)

                                        <i style="color: #0A327B;cursor: pointer;" name='minus_{{ $cartproduct_id }}' class="fa fa-minus quantityminus"></i>

                                        @endif

                                        <input style="width: 50px;" readonly="" type="number" name="quantity" value="{{$quantity}}">

                                        @if($quantity<10)

                                        <i style="color: #0A327B;cursor: pointer;" name='plus_{{ $cartproduct_id }}' class="fa fa-plus quantityplus"></i>

                                        @endif

                                        </div>
                                    </td>
                                    <td class="product-subtotal">
                                        <span style="color: #0A327B;">{{ number_format((float)$subtotal, 2, '.', '') }} USD</span>
                                    </td>
									<td class="product-remove">
                                        <a style="cursor: pointer;" name="remove_{{$cartproduct_id}}" class="remove removebtn">×</a>
                                    </td>
                                </tr>


                                @endforeach


                                
                            </table>
                        </form>
                    </div>
                    <div class="col-xl-4 col-lg-12 col-md-12 col-12">
                        <div class="cart-collaterals">
                            <div class="cart_totals ">
                                <h2>Cart totals</h2>
                                <table>
                                    <tr>
                                        <th>Subtotal</th>
                                        <td>
                                            <span style="color: #0A327B;font-weight: 500;">{{ number_format((float)$total, 2, '.', '') }} USD</bdi>
                                            </span>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th>Shipping</th>
                                        <td>

                                        

                                        @if($total >= $settings->freeshipping)

                                        @php $shipping_fee = 0; @endphp

                                        @else

                                        @php $shipping_fee = $settings->shipping_fee; @endphp

                                        @endif

                                       

                                            <ul>
                                                <li>

                                                                                                        
                                                    <label style="color: #0A327B;font-weight: 500;" for="shipping_method_0_free_shipping1">{{ number_format((float)$shipping_fee, 2, '.', '') }} USD</label>

                                                </li>
                                                
                                            </ul>
                                            
                                        </td>
                                    </tr>
                                    <tr class="order-total">
                                        <th>Total</th>
                                        <td><strong><span class="woocommerce-Price-amount amount">{{ number_format((float)$total+$shipping_fee, 2, '.', '') }} USD</span></strong> </td>
                                    </tr>
                                </table>
                                <div class="wc-proceed-to-checkout">
                                    <a href="{{ route('checkout') }}" class="checkout-button">Checkout</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                @endif

            </div>
        </div>
        <!--==================== Cart Section End ====================-->

@endsection


@section('extrascript')

<script type="text/javascript">

//Remove-----------
    
$('.removebtn').click(function(){

$('.contentt').html('<p style="font-size:22px;" align="center">Loading...</p>');

var button = $(this);
var id1=$(this).attr("name");
var cartproduct_id=id1.substring(7);

var data = { 'cartproduct_id':cartproduct_id, '_token': "{{ csrf_token() }}" };

$.ajax({


type : 'POST',
url : '/remove_from_cart',
data : $.param(data),
success : function(sonuc){

sonuc=$.trim(sonuc);
           
$('.contentt').html(sonuc);


 }

 });

});

//Remove End------------------

//Plus Start------------------

$('.quantityplus').click(function(){

var button = $(this);
var id1=$(this).attr("name");
var cartproduct_id=id1.substring(5);

var data = { 'cartproduct_id':cartproduct_id, '_token': "{{ csrf_token() }}" };

$.ajax({


type : 'POST',
url : '/cart_quantity_plus',
data : $.param(data),
success : function(sonuc){

sonuc=$.trim(sonuc);

if (sonuc=='nostock') {

alert('Stock is not enough for that quantity.');

} else {

$('.contentt').html(sonuc);

}


}

 });

});

//Plus End--------------------


//Minus Start------------------

$('.quantityminus').click(function(){

var button = $(this);
var id1=$(this).attr("name");
var cartproduct_id=id1.substring(6);

var data = { 'cartproduct_id':cartproduct_id, '_token': "{{ csrf_token() }}" };

$.ajax({


type : 'POST',
url : '/cart_quantity_minus',
data : $.param(data),
success : function(sonuc){

sonuc=$.trim(sonuc);


$('.contentt').html(sonuc);



}

 });

});

//Minus End--------------------

</script>

@endsection