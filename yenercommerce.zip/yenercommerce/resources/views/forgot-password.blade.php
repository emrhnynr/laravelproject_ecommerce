@extends('layouts.app')

@section('title') Forgot Password @endsection

@section('content')

<div class="full-row">
            <div class="container">
                <div class="row">
                    <div class="col">
                        <div class="woocommerce">
                            <div class="row">
                                <div class="col-lg-6 col-md-8 col-12 mx-auto">
                                    <div class="registration-form">
                                        <h3>Forgot Password</h3>
                                        <form id="submitform" onsubmit="return false;">

                                           @csrf

                                           

                                            <p>
                                                <label for="reg_email">Email address&nbsp;<span class="required">*</span></label>
                                                <input type="email" class="form-control" maxlength="150" name="user_email" id="user_email" />
                                            </p>

                                           
                                           
                                           <p>Please enter your email address. We will send a link to reset your password.</p>

                                            

                                            <div style="display: none;" class="alert alert-warning warning"><i class="fa fa-info-circle"></i></div>
                                            
                                            <p>
                                                <button type="submit" class="btn btn-primary rounded-0 submitbtn" value="Submit">Submit</button>
                                            </p>

                                            
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

@endsection

@section('extrascript')

<script type="text/javascript">
    
$('#submitform').submit(function(){


 var user_email = $.trim($('#user_email').val());
 
 if (user_email.length<6) {

 $('.warning').show();
 $('.warning').html("<i class='fa fa-info-circle'></i> Email field can't be shorter than 6 characters.");

 } else {

 $('.warning').hide();
 $('.submitbtn').html('Sending...');
 $('.submitbtn').attr('disabled',true);

 var data = $("#submitform").serializeArray();
 var csrf_token = $("input[name=_token]").val();
 data.push({name: "_token", value: csrf_token});

 $.ajax({


            type : 'POST',
            url : '/user/forgot_password_process',
            data : $.param(data),
            success : function(sonuc){

            sonuc = $.trim(sonuc);

            if (sonuc=='mailnotexist'){

            $('.warning').show();
            $('.warning').html("<i class='fa fa-info-circle'></i> This email address not exist. Please check.");
            $('.submitbtn').attr('disabled',false);
            $('.submitbtn').html('Submit');


            } else if (sonuc=='ok') {

            $('.submitbtn').css('background-color','green');
            $('.submitbtn').html('Password reset link has sent! Please check your email.');

            }

 }

 });

 }


});

</script>

@endsection