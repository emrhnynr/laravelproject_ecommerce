@extends('layouts.app')

@section('title') Wishlist @endsection

@section('content')

 <!-- breadcrumb -->
        <div class="full-row bg-light py-5">
            <div class="container">
                <div class="row text-secondary">
                    <div class="col-sm-6">
                        <h3 class="mb-2 text-secondary">Wishlist</h3>
                    </div>
                    
                </div>
            </div>
        </div>
        <!-- breadcrumb -->

        <!--==================== Wishlist Section Start ====================-->
        <div class="full-row">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <form action="" id="yith-wcwl-form" class="table-responsive-lg">



                            @if(count($products)==0)

                            <p align="center" style="font-size:19px;">There is no product in your wishlist yet.</p>

                            @else

                            <div style="display: none;" class="alert alert-success"><i class="fa fa-check"></i> This product has removed from your wishlist.</div>                      

                            <table class="shop_table cart wishlist_table wishlist_view traditional table" data-pagination="no" data-per-page="5" data-page="1" data-id="3989" data-token="G5CZRAZPRKEY">

                                @csrf

                                <thead>
                                    <tr>
                                        <th class="product-remove"> <span class="nobr"> </span></th>
                                        <th class="product-thumbnail"></th>
                                        <th class="product-name"> <span class="nobr"> Product </span></th>
                                        <th class="product-price"> <span class="nobr"> Price </span></th>
                                        
                                    </tr>
                                </thead>
                                <tbody class="wishlist-items-wrapper">


                                    @foreach($products as $product)

                                    <?php

                                    $product_name = $product->product_name;
                                    $product_price = $product->product_price;
                                    $product_id = $product->product_id;
                                    $product_slug = $product->product_slug;
                                    $brand_name = $product->brand_name;
                                    $product_sale = $product->product_sale;
                                    $product_coverimage = $product->product_coverimage;

                                    ?>
                                    

                                    <tr class="favourite_{{$product_id}} trproduct" id="yith-wcwl-row-97" data-row-id="97">
                                        <td class="product-remove">
                                            <div>
                                                <a style="cursor: pointer;" class="remove remove_from_wishlist" name="favourite_{{$product_id}}" title="Remove this product">×</a>
                                            </div>
                                        </td>
                                        <td class="product-thumbnail">
                                            <a href="{{ route('product_details', ['product_slug' => $product_slug, 'product_id' => $product_id]) }}"> <img src="{{ asset($product_coverimage) }}" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt=""> </a>
                                        </td>
                                        <td class="product-name"> <a href="{{ route('product_details', ['product_slug' => $product_slug, 'product_id' => $product_id]) }}">{{$brand_name}} {{$product_name}}</a></td>
                                        <td class="price"> 

                                        @if($product_sale==1)

                                        <del>{{ $product->product_nodiscount_price }}</del> - {{ $product_price }} USD

                                        @else

                                        {{ $product->product_nodiscount_price }} USD

                                        @endif

                                        </td>
                                        
                                    </tr>


                                    @endforeach



                                </tbody>
                            </table>

                            @endif

                        </form>
                    </div>
                </div>
            </div>
        </div>
        <!--==================== Wishlist Section End ====================-->

@endsection


@section('extrascript')

<script type="text/javascript">
    
$('.remove_from_wishlist').click(function(){

   
var button = $(this);
var id1=$(this).attr("name");
var product_id=id1.substring(10);


var data = { 'product_id':product_id, '_token': "{{ csrf_token() }}" };
    

 $.ajax({


            type : 'POST',
            url : '/user/remove_from_wishlist_table_process',
            data : $.param(data),
            success : function(sonuc){

            sonuc = $.trim(sonuc);

 

            if (sonuc=='ok') {

            $('.favourite_'+product_id).remove();
            $('.alert-success').show();

            var left = $('.trproduct').length;
            if (left==0) {

            $('.wishlist_table').replaceWith('<p align="center" style="font-size:19px;">There is no product in your wishlist yet.</p>');

            }

            }

 }

 });


});

</script>

@endsection