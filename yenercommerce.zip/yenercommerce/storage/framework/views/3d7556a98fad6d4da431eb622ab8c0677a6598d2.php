

<?php $__env->startSection('title'); ?> Reset Password <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="full-row">
            <div class="container">
                <div class="row">
                    <div class="col">
                        <div class="woocommerce">
                            <div class="row">
                                <div class="col-lg-6 col-md-8 col-12 mx-auto">
                                    <div class="registration-form">
                                        <h3>Reset Password</h3>
                                        <form id="submitform" onsubmit="return false;">

                                           <?php echo csrf_field(); ?>

                                           <br>

                                           

                                            <p>
                                                
                                                <input type="email" name="user_email" readonly="" class="form-control" value="<?php echo e($user1->user_email); ?>" />
                                            </p>

                                                <input type="hidden" value="<?php echo e($user_forgotcode); ?>" name="user_forgotcode">

                                             <p>
                                                
                                                <label for="reg_email">Password&nbsp;<span class="required">*</span></label>
                                                <input type="password" maxlength="100" name="user_password" id="user_password" class="form-control" />
                                            </p>

                                             <p>
                                                
                                                <label for="reg_email">Password (Again)&nbsp;<span class="required">*</span></label>
                                                <input type="password" maxlength="100" name="user_password_confirmation" id="user_password_confirmation" class="form-control" />
                                            </p>

                                           
                                           
                                           <p>Please enter your new password.</p>

                                            

                                            <div style="display: none;" class="alert alert-warning warning"><i class="fa fa-info-circle"></i></div>
                                            
                                            <p>
                                                <button type="submit" class="btn btn-primary rounded-0 submitbtn" value="Submit">Submit</button>
                                            </p>

                                            
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('extrascript'); ?>

<script type="text/javascript">
    
$('#submitform').submit(function(){


var user_password = $('#user_password').val();
var user_password_confirmation = $('#user_password_confirmation').val();
 
if (user_password.length<8){

$('.warning').show();
$('.warning').html("<i class='fa fa-info-circle'></i> Password field can't be shorter than 8 characters.");

} else if (user_password_confirmation!=user_password){

$('.warning').show();
$('.warning').html("<i class='fa fa-info-circle'></i> Passwords don't match. Please type again.");

} else {

 $('.warning').hide();
 $('.submitbtn').html('Processing...');
 $('.submitbtn').attr('disabled',true);

 var data = $("#submitform").serializeArray();
 var csrf_token = $("input[name=_token]").val();
 data.push({name: "_token", value: csrf_token});

 $.ajax({


            type : 'POST',
            url : '/user/reset_password_process',
            data : $.param(data),
            success : function(sonuc){

            sonuc = $.trim(sonuc);

            if (sonuc=='ok') {

            $('.submitbtn').css('background-color','green');
            $('.submitbtn').html('New password is ready! You can sign-in.');

            }

 }

 });

 }


});

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\AppServ\www\laravel-dersler\laravel-yenercommerce\resources\views/reset-password.blade.php ENDPATH**/ ?>