

<?php $__env->startSection('title'); ?> Page not found <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="full-row" style="padding: 100px 0">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-md-6 col-lg-5">
                        <div class="text-center">
                            <span class="fa fa-exclamation-triangle text-primary" style="font-size: 60px"></span>
                            <h2 class="my-4">404 Page not found</h2>
                            <p>The page you are looking for dosen’t exist or another error occourd go back to home or another source</p>
                            <a class="btn btn-secondary mt-5" href="<?php echo e(route('home')); ?>">Return to home</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\AppServ\www\laravel-dersler\laravel-yenercommerce\resources\views/404.blade.php ENDPATH**/ ?>