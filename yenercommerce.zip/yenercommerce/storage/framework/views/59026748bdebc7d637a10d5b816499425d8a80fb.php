

<?php $__env->startSection('title'); ?> Orders <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="full-row bg-light py-5">
            <div class="container">
                <div class="row text-secondary">
                    <div class="col-sm-6">
                        <h3 style="font-weight: 200;font-family: arial;" class="mb-2 text-secondary">My Orders</h3>
                    </div>
                    <div class="col-sm-6">
                        
                    </div>
                </div>
            </div>
        </div>
        <!-- breadcrumb -->

        <!--==================== Wishlist Section Start ====================-->
        <div style="padding-top: 20px;" class="full-row">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <form id="yith-wcwl-form" class="table-responsive-lg">

                        <?php if(count($orders)==0): ?>

                        <h4 style="font-family: Arial;" align="center">No order data yet.</h4>

                        <?php else: ?>

                        <table class="shop_table cart wishlist_table wishlist_view traditional table">
                        <thead>
                        <tr>
                                       
                        <th class="product-name"><span class="nobr">Order ID</span></th>
                        <th class="product-name"><span class="nobr">Order Date</span></th>
                        <th class="product-name"><span class="nobr">Count of Products</span></th>
                        <th class="product-name"><span class="nobr">Subtotal</span></th>
                        <th class="product-price"> <span class="nobr">Interest</span></th>
                        <th class="product-price"> <span class="nobr">Shipping Fee</span></th>                       
                        <th class="product-price"> <span class="nobr">Total</span></th>
                        <th class="product-stock-status"> <span class="nobr"> Status </span></th>
                        <th class="product-add-to-cart"> <span class="nobr"> </span></th>
                                        
                                        
                        </tr>
                        </thead>
                        <tbody class="wishlist-items-wrapper">
                        
                        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <?php

                        $created_at = $order->created_at;
                        $d = new DateTime($created_at);
                        $order_date =  $d->format('d/m/Y');

                        $countof_products = count( \App\Models\OrderProduct::where('order_id','=',$order->order_id)->get()->pluck('orderproduct_id') );

                        ?>
                                    
                        <tr>
                                        
                        <td class="product-name"> <?php echo $order->order_id; ?></td>
                        <td class="product-name"> <?php echo $order_date; ?></td>
                        <td class="product-name"> <?php echo $countof_products; ?></td>
                        <td class="product-name"> <?php echo $order->order_subtotal; ?> USD</td>                       
                        <td class="product-name"> <?php echo $order->order_interest; ?> USD</td>
                        <td class="product-name"> <?php echo $order->order_shipping_fee; ?> USD</td>
                        <td class="product-name"> <?php echo $order->order_total; ?> USD</td>

                        <?php if($order->order_status=='preparing'): ?>

                        <td class="product-name"><span style="color:#FA3B12;" class="wishlist-in-stock"><i class="far fa-clock"></i> Preparing</span></td>
                            
                        <?php elseif($order->order_status=='onshipping'): ?>

                        <td class="product-name"><span style="color:#225E88;" class="wishlist-in-stock"><i class="fas fa-truck"></i> On Shipping</span></td>
                                                      
                        <?php elseif($order->order_status=='delivered'): ?>
                           
                        <td class="product-name"><span style="color:green;" class="wishlist-in-stock"><i class="fas fa-check"></i> Delivered</span></td>
                        

                        <?php endif; ?>

                        <td class="product-add-to-cart">
                        <!-- Date added -->
                        <!-- Add to cart button --><a href="<?php echo e(route('order_details', ['order_id' => $order->order_id])); ?>" class="button add_to_cart_button add_to_cart alt" aria-label="">Details</a>
                                            
                        </td>



                        </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                        </table>

                        <?php endif; ?>

                        </form>
                    </div>
                </div>
            </div>
        </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\AppServ\www\laravel-dersler\laravel-yenercommerce\resources\views/orders.blade.php ENDPATH**/ ?>