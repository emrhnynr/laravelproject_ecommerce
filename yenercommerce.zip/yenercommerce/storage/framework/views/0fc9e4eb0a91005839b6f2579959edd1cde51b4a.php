

<?php $__env->startSection('title'); ?> <?php echo e($product->brand_name); ?> <?php echo e($product->product_name); ?> <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="full-row">



            <div class="container">
                <div class="row single-product-wrapper">
                    <div class="col-12 col-md-6 col-lg-5">
                        <div class="product-images">
                            <div class="images-inner">
                                <div class="woocommerce-product-gallery woocommerce-product-gallery--with-images woocommerce-product-gallery--columns-4 images" data-columns="4" style="opacity: 1; transition: opacity 0.25s ease-in-out 0s;">
                                    <figure class="woocommerce-product-gallery__wrapper">
                                        <img id="single-image-zoom" src="<?php echo e(asset($product->product_coverimage)); ?>" alt="Thumb Image" data-zoom-image="assets/images/products/squire-233.png" />

                                        <div id="gallery_09" class="product-slide-thumb">
                                            <div class="owl-carousel four-carousel dot-disable nav-arrow-middle owl-mx-5">

                                            

                                             <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                <div class="item">
                                                    <a class="active" href="<?php echo e(asset($image->image_path)); ?>" data-image="<?php echo e(asset($image->image_path)); ?>" data-zoom-image="<?php echo e(asset($image->image_path)); ?>">
                                                        <img src="<?php echo e(asset($image->image_path)); ?>" alt="Product Image" />
                                                    </a>
                                                </div>

                                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                
                                            </div>
                                        </div>
                                    </figure>
                                </div>
                            </div>
                        </div>
                    </div>


                    

                    <div class="col-12 col-md-6 col-lg-7">
                        <div class="summary entry-summary">
                            <div class="summary-inner">
                                
                                <div class="entry-breadcrumbs">
                                    <nav class="breadcrumb-divider-slash" aria-label="breadcrumb">
                                        <ol class="breadcrumb">
                                            <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>

                                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 

                                            <li class="breadcrumb-item">

                                                <a href="<?php echo e(route('category_details', ['category_slug' => $category->category_slug, 'category_id' => $category->category_id])); ?>"><?php echo e($category->category_name); ?></a>

                                            </li>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            
                                            <li class="breadcrumb-item active" aria-current="page"><?php echo e($product->brand_name); ?> <?php echo e($product->product_name); ?></li>
                                        </ol>
                                    </nav>
                                </div>
                                <h1 class="product_title entry-title"><?php echo e($product->brand_name); ?> <?php echo e($product->product_name); ?></h1>
                                
                                <p class="price">

                                <?php if($product->product_sale==1): ?>

                                <span class="woocommerce-Price-amount amount">
                                       <bdi>

                                        <span class="woocommerce-Price-currencySymbol">
                                        <del style="color: #707070;"><?php echo e($product->product_nodiscount_price); ?></del> 
                                        <span style="color: green;"><?php echo e($product->product_price); ?> USD</span>

                                        </bdi>
                                </span>

                                <?php

                                 $discount_amount = $product->product_nodiscount_price-$product->product_price;
                                 $discount_percentage = round(($discount_amount*100)/$product->product_nodiscount_price);

                                ?>

                                <div class="product-price-discount"><span class="on-sale"><span><?php echo e($discount_percentage); ?></span>% Off</span></div>

                                <?php else: ?>

                                
                                <span class="woocommerce-Price-amount amount">
                                        <bdi><span class="woocommerce-Price-currencySymbol"><?php echo e($product->product_nodiscount_price); ?> USD</span></bdi>
                                </span>


                                <?php endif; ?>

                                
                                    
                                </p>

                                

                                
                                

                                <?php if(($product->product_stock)>0): ?>

                                <div class="stock-availability in-stock">In Stock</div>

                                <?php else: ?>

                                <div style="color: red;" class="stock-availability in-stock">Out of Stock</div>

                                <?php endif; ?>
                                
                                <div class="product-brands">
                                    <a class="brand-image" href="<?php echo e(route('brand_details', ['brand_slug' => $brand->brand_slug, 'brand_id' => $brand->brand_id])); ?>"> 

                                        <img src="<?php echo e(asset($brand->brand_logo)); ?>" class="attachment-full size-full" alt="" width="80" height="80"> 

                                    </a>
                                </div>
                                
                                
                                <form id="add_to_cart_form" class="variations_form cart kapee-swatches-wrap" onsubmit="return false;">


                                <?php echo csrf_field(); ?>


                                <input type="hidden" name="product_id" value="<?php echo e($product->product_id); ?>" id="product_id">

                                    
                                <div class="single_variation_wrap">
                                        
                                           
                                       <select class="form-control" name="product_quantity">
                                       
                                       <?php $i=0;

                                       while ($i<10) {
                                                     
                                       $i++; ?>

                                       <option value="<?php echo $i; ?>"><?php echo $i; ?></option>

                                       <?php } ?>
                                               
                                       </select>     
                                        
                                    <div class="woocommerce-variation-add-to-cart variations_button woocommerce-variation-add-to-cart-enabled">


                                    <?php if($product->product_stock>0): ?>
                                    
                                    <button type="submit" class="addcartbtn single_add_to_cart_button button alt single_add_to_cart_ajax_button">Add to cart</button>

                                    <?php else: ?>

                                    <button type="button" class="single_add_to_cart_button button alt single_add_to_cart_ajax_button"><i class="fas fa-ban"></i> Out of Stock</button>

                                    <?php endif; ?>
                                           
                                    
                                    </div>
                                    </div>

                                </form>


                                <span class="addtocartwarning" style="color:#EA350E;display: none;"></span>


                                <div class="yith-wcwl-add-to-wishlist wishlist-fragment">
                                    <div class="wishlist-button">

                                     <?php if(Auth::guard('user')->check()): ?>

                                     <?php if($in_favourites=='yes'): ?>

                                     <a style="cursor: pointer;color: red;" id="remove_from_wishlist" class="add_to_wishlist" aria-label="Remove from Wishlist">Remove from wishlist</a>

                                     <?php else: ?>

                                     <a style="cursor: pointer;color: green;" id="add_to_wishlist" class="add_to_wishlist" aria-label="Add to Wishlist">Add to Wishlist</a>

                                     <?php endif; ?>

                                     <?php else: ?>

                                     <a class="add_to_wishlist" href="<?php echo e(route('signin')); ?>" aria-label="Add to Wishlist">Add to Wishlist</a>


                                     <?php endif; ?>



                                    </div>
                                    
                                </div>
                                
                                <div class="bigbazar-wc-message"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!--==================== Product Description Section Start ====================-->
        <div class="full-row bg-light">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="bg-white p-50">
                            <div class="section-head border-bottom">
                                <div class="woocommerce-tabs wc-tabs-wrapper ps-0">
                                    <ul class="nav nav-pills wc-tabs" id="pills-tab-one" role="tablist">
                                        <li class="nav-item" role="presentation">
                                            <a class="nav-link active" id="pills-description-one-tab" data-bs-toggle="pill" href="#pills-description-one" role="tab" aria-controls="pills-description-one" aria-selected="true">Description</a>
                                        </li>
                                        <li class="nav-item" role="presentation">
                                            <a class="nav-link" id="pills-information-one-tab" data-bs-toggle="pill" href="#pills-information-one" role="tab" aria-controls="pills-information-one" aria-selected="true">Features</a>
                                        </li>
                                        <li class="nav-item" role="presentation">
                                            <a class="nav-link" id="pills-reviews-one-tab" data-bs-toggle="pill" href="#pills-reviews-one" role="tab" aria-controls="pills-reviews-one" aria-selected="true">Reviews(3)</a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <div class="woocommerce-tabs wc-tabs-wrapper ps-0 mt-0">
                                <div class="tab-content" id="pills-tabContent-one">
                                    <div class="tab-pane fade show active woocommerce-Tabs-panel woocommerce-Tabs-panel--description" id="pills-description-one" role="tabpanel" aria-labelledby="pills-description-one-tab">
                                        <div class="row">

                                            <div class="col-lg-12">
                                                <h2 class="my-3">Product Description</h2>
                                                
                                                <?php echo e($product->product_description); ?>


                                            </div>
                                            
                                        </div>
                                    </div>
                                    <div class="tab-pane fade" id="pills-information-one" role="tabpanel" aria-labelledby="pills-information-one-tab">
                                        <div class="row">
                                            <div class="col-8">
                                                <h2 class="my-3">Features</h2>
                                                <table class="woocommerce-product-attributes shop_attributes">

                                                    <?php $__currentLoopData = $features; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 

                                                    <tr class="woocommerce-product-attributes-item woocommerce-product-attributes-item--attribute_pa_color">
                                                        <th class="woocommerce-product-attributes-item__label"><?php echo e($feature->feature_title); ?> :</th>
                                                        <td class="woocommerce-product-attributes-item__value">
                                                            <p><?php echo e($feature->feature_content); ?></p>
                                                        </td>
                                                    </tr>

                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    

                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="tab-pane fade" id="pills-reviews-one" role="tabpanel" aria-labelledby="pills-reviews-one-tab">
                                        <div class="row">
                                            <div class="col-8">
                                                <div id="comments">
                                                    <h2 class="woocommerce-Reviews-title my-3">(3) Customer Review</h2>
                                                    <ol class="commentlist">
                                                        <li>
                                                            <div class="comment_container">
                                                                <img src="assets/images/avatar.png" class="avatar" alt="Image not found!">
                                                                <div class="comment-text">
                                                                    <div class="star-rating" role="img" aria-label="Rated 5 out of 5">
                                                                        <i class="flaticon-star-1"></i>
                                                                        <i class="flaticon-star-1"></i>
                                                                        <i class="flaticon-star-1"></i>
                                                                        <i class="flaticon-star-1"></i>
                                                                        <i class="flaticon-star-1"></i>
                                                                    </div>
                                                                    <p class="meta">
                                                                        <strong class="woocommerce-review__author">Admin </strong>
                                                                        <span class="woocommerce-review__dash">–</span>
                                                                        <span class="woocommerce-review__published-date">September 26, 2019</span>
                                                                    </p>
                                                                    <div class="description">
                                                                        <p>Aliquam nisi class massa dictum, quam morbi interdum commodo inceptos molestie cum euismod ut Libero lacus fames feugiat. Torquent sed dis litora velit justo interdum non iaculis
                                                                            libero porta orci. Egestas Turpis class, sed feugiat sed euismod magnis viverra.</p>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </li>
                                                    </ol>
                                                </div>
                                                <div id="review_form_wrapper">
                                                    <div id="review_form">
                                                        <div id="respond" class="comment-respond">
                                                            <h5 id="reply-title" class="comment-reply-title my-20">Add A Review</h5>
                                                            <form action="#" method="post" id="commentform" class="comment-form">
                                                                <div class="row g-3">
                                                                    <div class="col-6">
                                                                        <label for="comment">Your Name<span class="required">*</span></label>
                                                                        <input type="text" class="form-control">
                                                                    </div>
                                                                    <div class="col-6">
                                                                        <label for="comment">Your Email<span class="required">*</span></label>
                                                                        <input type="email" class="form-control">
                                                                    </div>
                                                                    <div class="col-12">
                                                                        <div class="comment-form-comment">
                                                                            <label for="comment">Your review<span class="required">*</span></label>
                                                                            <textarea id="comment" name="comment" cols="45" rows="8" required=""></textarea>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-12">
                                                                        <div class="form-submit">
                                                                            <button name="submit" type="submit" id="submit" class="btn btn-primary">Submit</button>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <input type="hidden" id="_wp_unfiltered_html_comment_disabled" name="_wp_unfiltered_html_comment" value="0bbb6c8c11">
                                                            </form>
                                                        </div>
                                                        <!-- #respond -->
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--==================== Product Description Section End ====================-->

        <!--==================== Related Products Section Start ====================-->
        <div class="full-row">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="section-head border-bottom d-flex justify-content-between align-items-center mb-2">
                            <div class="d-flex section-head-side-title">
                                <h4 class="text-dark mb-0">Related Products</h4>
                            </div>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="products product-style-2 owl-mx-5">
                            <div class="product-carousel five-carousel owl-carousel owl-item-mb-50 owl-nav-hover-primary nav-top-right dot-disable e-bg-light e-hover-wrapper-absolute e-hover-image-zoom">
                                
                                <?php $__currentLoopData = $similar_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                                <?php

                                $product_id = $product->product_id;
                                $product_name = $product->product_name;
                                $product_slug = $product->product_slug;
                                $product_coverimage = $product->product_coverimage;
                                $product_price = $product->product_price;
                                $product_sale = $product->product_sale;
                                $brand_name = $product->brand_name;

                                ?>


                                <div class="item">
                                    <div class="product type-product">
                                        <div class="product-wrapper">
                                            <div class="product-image">
                                                <a href="<?php echo e(route('product_details', ['product_slug' => $product_slug, 'product_id' => $product_id])); ?>" class="woocommerce-LoopProduct-link"><img src="<?php echo e(asset($product_coverimage)); ?>" alt="Product Image"></a>
                                                
                                            </div>
                                            <div class="product-info">
                                                <h4 class="product-brandname"><?php echo e($brand_name); ?></h4>
                                                <h3 class="product-title"><a href="<?php echo e(route('product_details', ['product_slug' => $product_slug, 'product_id' => $product_id])); ?>"><?php echo e($product_name); ?></a></h3>
                                                <div class="product-price">
                                                    <div class="price">

                                                       <?php if($product_sale==1): ?>

                                                       <ins><del><?php echo e($product->product_nodiscount_price); ?></del> - <?php echo e($product_price); ?> USD</ins>

                                                       <?php else: ?>

                                                       <ins><?php echo e($product->product_nodiscount_price); ?> USD</ins>

                                                       <?php endif; ?>
                                                       
                                                    </div>
                                                    
                                                </div>
                                                
                                            </div>
                                        </div>
                                    </div>
                                </div>


                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--==================== Related Products Section End ====================-->

        

<?php $__env->stopSection(); ?>


<?php $__env->startSection('extrascript'); ?>


<script>
        //initiate the plugin and pass the id of the div containing gallery images
        $("#single-image-zoom").elevateZoom({
            gallery: 'gallery_09',
            zoomType: "inner",
            cursor: "crosshair",
            galleryActiveClass: 'active',
            imageCrossfade: true,
            loadingIcon: 'http://www.elevateweb.co.uk/spinner.gif'
        });
        //pass the images to Fancybox
        $("#single-image-zoom").bind("click", function(e) {
            var ez = $('#single-image-zoom').data('elevateZoom');
            $.fancybox(ez.getGalleryList());
            return false;
        });



        $('#add_to_wishlist').click(function(){

        var product_id = $('#product_id').val();
        var csrf_token = $("input[name=_token]").val();

        var data = { 'product_id':product_id, '_token':csrf_token };
    

 $.ajax({


            type : 'POST',
            url : '/user/add_to_wishlist_process',
            data : $.param(data),
            success : function(sonuc){

            sonuc = $.trim(sonuc);


            if (sonuc=='ok') {

            $('#add_to_wishlist').replaceWith('<span style="color:green;font-size:15px;"><i class="fas fa-check"></i> Added to wishlist!</span>');

            }

 }

 });

        });




        $('#remove_from_wishlist').click(function(){

        var product_id = $('#product_id').val();
        var csrf_token = $("input[name=_token]").val();

        var data = { 'product_id':product_id, '_token':csrf_token };
    

 $.ajax({


            type : 'POST',
            url : '/user/remove_from_wishlist_process',
            data : $.param(data),
            success : function(sonuc){

            sonuc = $.trim(sonuc);



            if (sonuc=='ok') {

            $('#remove_from_wishlist').replaceWith('<span style="color:green;font-size:15px;"><i class="fas fa-ban"></i> Removed from wishlist!</span>');

            }

 }

 });

        });  



        $('#add_to_cart_form').submit(function(){

        $('.addcartbtn').prop('disabled',true);
        $('.addcartbtn').html('Adding...');
        var data = $("#add_to_cart_form").serializeArray();

        $.ajax({


        type : 'POST',
        url : '/user/add_to_cart_process',
        data : $.param(data),
        success : function(sonuc){

        sonuc = $.trim(sonuc);

        if (sonuc=='ok') {

        $('.addtocartwarning').hide();
        $('.addcartbtn').html('<i class="fas fa-check"></i> Added to Cart');
        $('.addcartbtn').css('background-color','green');

        } else if (sonuc=='nostock'){

        $('.addtocartwarning').show();
        $('.addtocartwarning').html('<i class="fas fa-info"></i> Out of stock as you specified.');
        $('.addcartbtn').prop('disabled',false);
        $('.addcartbtn').html('Add to Cart');

        }

        }

        });


        });

        
        


</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\AppServ\www\laravel-dersler\laravel-yenercommerce\resources\views/product_details.blade.php ENDPATH**/ ?>