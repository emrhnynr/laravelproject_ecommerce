

<?php $__env->startSection('title'); ?> Change Password <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="full-row">
            <div class="container">
                <div class="row">
                    <div class="col">
                        <div class="woocommerce">
                            <div class="row">
                                <div class="col-lg-6 col-md-8 col-12 mx-auto">
                                    <div class="registration-form">
                                        <h3>Change Password</h3>


                                        <form id="updateform" onsubmit="return false;">

                                           <?php echo csrf_field(); ?>
                                         

                                            <p>
                                                <label for="reg_email">Current Password&nbsp;<span class="required">*</span></label>
                                                <input type="password" class="form-control" maxlength="100" name="user_currentpassword" id="user_currentpassword" />
                                            </p>


                                            <p>
                                                <label for="reg_email">New Password&nbsp;<span class="required">*</span></label>
                                                <input type="password" class="form-control" maxlength="100" name="user_password" id="user_password" />
                                            </p>


                                            <p>
                                                <label for="reg_email">New Password (Again)&nbsp;<span class="required">*</span></label>
                                                <input type="password" class="form-control" maxlength="100" name="user_password_confirmation" id="user_password_confirmation" />
                                            </p>

                                        
                                            

                                            <div style="display: none;" class="alert alert-warning warning"><i class="fa fa-info-circle"></i></div>
                                            
                                            <p>
                                                <button type="submit" class="btn btn-primary rounded-0 updatebtn" value="Change">Change</button>
                                            </p>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('extrascript'); ?>

<script type="text/javascript">
    
$('#updateform').submit(function(){

 var user_currentpassword = $('#user_currentpassword').val();
 var user_password = $('#user_password').val();
 var user_password_confirmation = $('#user_password_confirmation').val();

if (user_currentpassword.length<8){

$('.warning').show();
$('.warning').html("<i class='fa fa-info-circle'></i> Current Password field can't be shorter than 8 characters.");

} else if (user_password.length<8){

$('.warning').show();
$('.warning').html("<i class='fa fa-info-circle'></i> New Password field can't be shorter than 8 characters.");

} else if (user_password_confirmation!=user_password){

$('.warning').show();
$('.warning').html("<i class='fa fa-info-circle'></i> New Passwords don't match. Please type again.");

} else {

 $('.warning').hide();
 $('.updatebtn').attr('disabled',true);
 $('.updatebtn').html('Changing...');

 var data = $("#updateform").serializeArray();
 var csrf_token = $("input[name=_token]").val();
 data.push({name: "_token", value: csrf_token});

 
 $.ajax({


            type : 'POST',
            url : '/user/change_password_process',
            data : $.param(data),
            success : function(sonuc){

            sonuc = $.trim(sonuc);

            if (sonuc=='ok') {

            $('.updatebtn').css('background-color', 'green');
            $('.updatebtn').html('Change is successful!');
            $('#updateform')[0].reset();

            } else if (sonuc=='wrongpassword'){

            $('.warning').show();
            $('.warning').html("<i class='fa fa-info-circle'></i> Current password is incorrect.");
            $('.updatebtn').attr('disabled',false);
            $('.updatebtn').html('Change');

            }

              

         }

 });

}

});

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\AppServ\www\laravel-dersler\laravel-yenercommerce\resources\views/change-password.blade.php ENDPATH**/ ?>