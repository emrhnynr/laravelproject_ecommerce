

<?php $__env->startSection('title'); ?> Checkout <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>



        <!--==================== Checkout Section Start ====================-->
        <div id="main-content" class="full-row site-content">
            <div class="container">
                <div class="row ">
                    <div id="primary" class="content-area col-md-12">
                        <article id="post-19" class="post-19 page type-page status-publish hentry">
                            <div class="entry-content">
                                <div class="woocommerce">
                                    
                                    <div class="woocommerce-form-login-toggle">
                                        
                                    


                                    <div class="woocommerce-form-coupon-toggle">
                                       

                   
                                    


                                    <form onsubmit="return false;" class="checkout woocommerce-checkout" id="checkoutform">



                                       <?php echo csrf_field(); ?>

                                        <div class="row">
                                            <div class="col-lg-7">
                                                <div class="col2-set" id="customer_details">
                                                    <div class="woocommerce-billing-fields">
                                                        <h3>Billing details</h3>
                                                        <div class="woocommerce-billing-fields__field-wrapper">


                                                            <p class="form-row form-row-first validate-required" id="billing_first_name_field" data-priority="10">
                                                                <label for="billing_first_name" class="">First Name&nbsp;<abbr class="required" title="required">*</abbr></label>
                                                                <span class="woocommerce-input-wrapper">
                                                                    <input type="text" class="input-text " name="order_firstname" id="order_firstname" maxlength="100">
                                                                </span>
                                                            </p>



                                                            <p class="form-row form-row-first validate-required" id="billing_first_name_field" data-priority="10">
                                                                <label for="billing_first_name" class="">Last Name&nbsp;<abbr class="required" title="required">*</abbr></label>
                                                                <span class="woocommerce-input-wrapper">
                                                                    <input type="text" class="input-text " name="order_lastname" id="order_lastname" maxlength="100">
                                                                </span>
                                                            </p>


                                                            <p class="form-row form-row-first validate-required" id="billing_first_name_field" data-priority="10">
                                                                <label for="billing_first_name" class="">Phone Number&nbsp;<abbr class="required" title="required">*</abbr></label>
                                                                <span class="woocommerce-input-wrapper">
                                                                    <input type="text" class="input-text " name="order_phonenumber" id="order_phonenumber" maxlength="20">
                                                                </span>
                                                            </p>


                                                            <p class="form-row form-row-wide address-field update_totals_on_change validate-required" id="billing_country_field">
                                                                <label for="billing_country" class="">City&nbsp;<abbr class="required" title="required">*</abbr></label>
                                                                <span class="woocommerce-input-wrapper">
                                                                    <select name="order_city" id="order_city" class="country_to_state country_select select2-hidden-accessible">
                                                                        <option value="notselected">Select</option>

                                                                        
                                                                    <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                                        <option value="<?php echo e($city->city_id); ?>"><?php echo e($city->city_name); ?></option>

                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                                                    
                                                                        
                                                                    </select>
                                                                </span>
                                                            </p>
                                                            

                                                            <p class="form-row form-row-wide address-field update_totals_on_change validate-required" id="billing_country_field">
                                                                <label for="billing_country" class="">District&nbsp;<abbr class="required" title="required">*</abbr></label>
                                                                <span class="woocommerce-input-wrapper">
                                                                    <select name="order_district" id="order_district" class="country_to_state country_select select2-hidden-accessible">
                                                                        

                                                                        
                                                                   <option selected="">Select a city first</option>


                                                                    
                                                                        
                                                                    </select>
                                                                </span>
                                                            </p>


                                                            <p class="form-row notes" id="order_comments_field" data-priority=""><label for="order_comments" class="">Order Address <span class="required">*</span></label><span class="woocommerce-input-wrapper"><textarea name="order_address" class="input-text " id="order_address" maxlength="1000" rows="3" cols="5"></textarea></span></p>


                                                            <p class="form-row notes" id="order_comments_field" data-priority=""><label for="order_comments" class="">Order Note <span class="optional">(Optional)</span></label><span class="woocommerce-input-wrapper"><textarea name="order_note" class="input-text " id="order_note" maxlength="500" rows="2" cols="5"></textarea></span></p>



                                                            
                                                        </div>
                                                    </div>
                                                    
                                                </div>
                                            </div>
                                            <div class="col-lg-5">
                                                <div class="order-review-inner">
                                                    <h3 id="order_review_heading">Your order</h3>
                                                    <div id="order_review" class="woocommerce-checkout-review-order">
                                                        <table class="shop_table woocommerce-checkout-review-order-table">
                                                            <thead>
                                                                <tr>
                                                                    <th class="product-name">Product</th>
                                                                    <th class="product-total">Subtotal</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody>

                                                            	<?php $__currentLoopData = $cartproducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cartproduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                            	<?php

                                                            	$product_id = $cartproduct->product_id;
                                                            	$quantity = $cartproduct->product_quantity;

                                                            	$product = \DB::table('products')->where('product_id','=',$product_id)->first();

                                                            	 ?>


                                                                <tr class="cart_item">
                                                                    <td class="product-name">

                                                                        <?php echo e($product->product_name); ?>&nbsp; 

                                                                        <strong class="product-quantity">
                                                                        ×&nbsp;<?php echo e($quantity); ?>

                                                                        </strong> 

                                                                    </td>
                                                                    <td class="product-total">
                                                                        <span class="woocommerce-Price-amount amount">

                                                                        <?php if($product->product_sale=='1'): ?>

                                                                        <?php echo e(number_format((float)$product->product_price * $quantity, 2, '.', '')); ?> USD

                                                                        <?php else: ?>

                                                                        <?php echo e(number_format((float)$product->product_nodiscount_price * $quantity, 2, '.', '')); ?> USD

                                                                        <?php endif; ?>

                                                                        </span>
                                                                    </td>
                                                                </tr>


                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                                
                                                            </tbody>
                                                            <tfoot>

                                                            	


                                                                <tr class="cart-subtotal">
                                                                    <th>Subtotal</th>
                                                                    <td><span style="color: #0A327B;" class="woocommerce-Price-amount amount">
                                                                    	<?php echo e(number_format((float)$products_total, 2, '.', '')); ?> USD
                                                                        </span>
                                                                    </td>
                                                                </tr>


                                                                <tr class="order-total">
                                                                    <th>Shipping Fee</th>
                                                                    <td><strong><span style="color: #0A327B;" class="woocommerce-Price-amount amount"><?php echo e(number_format((float)$shipping_fee, 2, '.', '')); ?> USD</span></strong> </td>
                                                                </tr>

                                                                

                                                                <tr class="woocommerce-shipping-totals shipping installmenttr">
                                                                <th>Installment</th>
                                                                <td data-title="Shipping">

                                                                

                                                                <div class="radio">
                                                                <label>
                                                                <input type="radio" name="installment" id="install_oneshot" checked="">
                                                                One Shot
                                                                </label>
                                                                </div>


                                                                <?php $__currentLoopData = $installments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $installment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                                <div class="radio">
                                                                <label>
                                                                <input type="radio" name="installment" id="install_<?php echo e($installment->installment_id); ?>">
                                                                <?php echo e($installment->installment_amount); ?>

                                                                </label>
                                                                </div>

                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                                                                </tr>

                                                                

                                                                <tr class="order-total interesttr">
                                                                    <th>Interest</th>
                                                                    <td><strong><span style="color: #0A327B;" class="woocommerce-Price-amount amount">0.00 USD</span></strong> </td>
                                                                </tr>

                                                                
                                                                <tr class="order-total totaltr">
                                                                    <th>Total</th>
                                                                    <td><strong><span style="color: #0A327B;" class="woocommerce-Price-amount amount">
                                                                    <?php echo e(number_format((float)$total, 2, '.', '')); ?> USD
                                                                </span></strong> </td>
                                                                </tr>




                                                                
                                                            </tfoot>
                                                        </table>
                                                        <div id="payment" class="woocommerce-checkout-payment">

                                                        	<br>

                                                        	<h3 style="font-family: arial;font-weight: 200;color: black;">Payment <i class="far fa-credit-card"></i><hr></h3>

                                                            <p class="form-row form-row-first validate-required" id="billing_first_name_field" data-priority="10">
                                                                <label for="billing_first_name" class="">Card Number&nbsp;<abbr class="required" title="required">*</abbr></label>
                                                                <span class="woocommerce-input-wrapper">
                                                                    <input type="text" class="input-text" placeholder="16 digits card number" name="cardnumber" id="cardnumber" maxlength="22">
                                                                </span>
                                                            </p>


                                                            <p class="form-row form-row-first validate-required" id="billing_first_name_field" data-priority="10">
                                                                <label for="billing_first_name" class="">Card Holder&nbsp;<abbr class="required" title="required">*</abbr></label>
                                                                <span class="woocommerce-input-wrapper">
                                                                    <input type="text" class="input-text " name="cardholder" id="cardholder" maxlength="100">
                                                                </span>
                                                            </p>


                                                            <div class="row">
                                                                
                                                                <div class="col-lg-4 col-md-6 col-xs-6">


                                                                    <p class="form-row form-row-wide address-field update_totals_on_change validate-required" id="billing_country_field">
                                                                
                                                                <span class="woocommerce-input-wrapper">
                                                                   <select style="background: white;" name="expirymonth" class="country_to_state country_select select2-hidden-accessible">
                    <option value="monthnotselected" selected="">Month</option>
                    <option style='color: black;'>01</option>
                    <option style='color: black;'>02</option>
                    <option style='color: black;'>03</option>
                    <option style='color: black;'>04</option>
                    <option style='color: black;'>05</option>
                    <option style='color: black;'>06</option>
                    <option style='color: black;'>07</option>
                    <option style='color: black;'>08</option>
                    <option style='color: black;'>09</option>
                    <option style='color: black;'>10</option>
                    <option style='color: black;'>11</option>
                    <option style='color: black;'>12</option>
                  </select>
                                                                </span>
                                                            </p>
                                                                    

                                                                </div>

                                                                <div class="col-lg-4 col-md-6 col-xs-6">


                                                                    <p class="form-row form-row-wide address-field update_totals_on_change validate-required" id="billing_country_field">
                                                                
                                                                <span class="woocommerce-input-wrapper">
                                                                   <select style="background: white;" name="expiryyear" class="country_to_state country_select select2-hidden-accessible">
                    <option value="yearnotselected" selected="">Year</option>
                    <option style='color: black;'>2020</option>
                    <option style='color: black;'>2021</option>
                    <option style='color: black;'>2022</option>
                    <option style='color: black;'>2023</option>
                    <option style='color: black;'>2024</option>
                    <option style='color: black;'>2025</option>
                    <option style='color: black;'>2026</option>
                    <option style='color: black;'>2027</option>
                    <option style='color: black;'>2028</option>
                    <option style='color: black;'>2029</option>
                    <option style='color: black;'>2030</option>
                    <option style='color: black;'>2031</option>
                    <option style='color: black;'>2032</option>
                  </select>
                                                                </span>
                                                            </p>
                                                                    

                                                                </div>


                                                                <div class="col-lg-4 col-md-6 col-xs-6">


                                                                    <p class="form-row form-row-wide address-field update_totals_on_change validate-required" id="billing_country_field">
                                                                
                                                                <span class="woocommerce-input-wrapper">
                                                                   
                                                                   <input type="text" placeholder="CVC" class="input-text " name="cvc" id="cvc" maxlength="3">

                                                                </span>
                                                            </p>
                                                                    

                                                                </div>

                                                            </div>

                                                        	<br>
                                                            
                                                            <div class="form-row place-order">
                                                                

                                                                <div style="display: none;" class="alert alert-warning warning"></div>


                                                                <button type="submit" class="button alt checkoutbutton" name="woocommerce_checkout_place_order" id="place_order" value="Place order" data-value="Place order">Place order</button>

                                                                                                    </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                            <!-- .entry-content -->
                        </article>
                        <!-- #post-## -->
                    </div>
                    <!-- .entry-content-wrapper -->
                </div>
                <!-- .row -->
            </div>
            <!-- .container -->
        </div>
        <!--==================== Checkout Section End ====================-->

<?php $__env->stopSection(); ?>


<?php $__env->startSection('extrascript'); ?>

<script type="text/javascript">

jQuery.fn.ForceNumericOnly =
function()
{
return this.each(function()
{
$(this).keydown(function(e)
{
var key = e.charCode || e.keyCode || 0;
            // allow backspace, tab, delete, enter, arrows, numbers and keypad numbers ONLY
            // home, end, period, and numpad decimal
return (
key == 8 || 
key == 9 ||
key == 13 ||
key == 32 ||
key == 46 ||
(key >= 35 && key <= 40) ||
(key >= 48 && key <= 57) ||
(key >= 96 && key <= 105));
});
});
};

$("#order_phonenumber,#cvc").ForceNumericOnly();

//---------------------------------------------------------------
	
$('#order_city').change(function(){

var city_id = $(this).val();
var data = { 'city_id':city_id, '_token': "<?php echo e(csrf_token()); ?>" };

$.ajax({

type : 'POST',
url : '/select_city',
data : $.param(data),
success : function(sonuc){

sonuc=$.trim(sonuc);


$('#order_district').html(sonuc);

            
}

});



});


//-----------------------------------


$('input[type=radio][name=installment]').change(function() {

var id1=$(this).attr("id");
var installment_id=id1.substring(8);

$('input[type=radio][name=installment]').attr('disabled',true);
$('.checkoutbutton').attr('disabled',true);
$('.interesttr,.totaltr').remove();

var data = { 'installment_id':installment_id, '_token': "<?php echo e(csrf_token()); ?>" };

$.ajax({

type : 'POST',
url : '/change_installment',
data : $.param(data),
success : function(sonuc){

sonuc=$.trim(sonuc);

$('input[type=radio][name=installment]').attr('disabled',false);
$('.checkoutbutton').attr('disabled',false);

$('.interesttr,.totaltr').remove();
$('.installmenttr').after(sonuc);




            
}

});



});


//-----------------------------------

$('#checkoutform').submit(function(){

var cardnumber=$.trim($('[name="cardnumber"]').val());
var cardholder=$.trim($('[name="cardholder"]').val());
var expirymonth=$('[name="expirymonth"]').val();
var expiryyear=$('[name="expiryyear"]').val();
var cvc=$.trim($('[name="cvc"]').val());



var order_firstname = $.trim($('#order_firstname').val());
var order_lastname = $.trim($('#order_lastname').val());
var order_phonenumber = $.trim($('#order_phonenumber').val());
var order_city = $('#order_city').val();
var order_address = $.trim($('#order_address').val());


if (order_firstname.length<2) {

$('.warning').show();
$('.warning').html('<i class="fa fa-info-circle"></i> Please enter your first name correctly.');

      }  else if (order_lastname.length<2){

$('.warning').show();
$('.warning').html('<i class="fa fa-info-circle"></i> Please enter your last name correctly.');

      } else if (order_phonenumber.length<10){

$('.warning').show();
$('.warning').html('<i class="fa fa-info-circle"></i> Please enter your phone number correctly.');

      } else if (order_city=='notselected'){

$('.warning').show();
$('.warning').html('<i class="fa fa-info-circle"></i> Please select a city and district.');

      } else if (order_address.length<15){

$('.warning').show();
$('.warning').html('<i class="fa fa-info-circle"></i> Please type some more on order address.');

      } else if (cardnumber.length<16) {

$('.warning').show();
$('.warning').html("<i class='fa fa-info-circle'></i> Card number can't be shorter than 16 digits.");


} else if(cardholder.length<4){

$('.warning').show();
$('.warning').html('<i class="fa fa-info-circle"></i> Please enter cardholder correctly.');

} else if(expirymonth=="monthnotselected"){

$('.warning').show();
$('.warning').html('<i class="fa fa-info-circle"></i> Please select card expiry month.');

} else if(expiryyear=='yearnotselected'){

$('.warning').show();
$('.warning').html('<i class="fa fa-info-circle"></i> Please select card expiry year.');

} else if (cvc.length!=3) {

$('.warning').show();
$('.warning').html('<i class="fa fa-info-circle"></i> CVC should have 3 digits.');

 } else {
 
$('.checkoutbutton').prop('disabled',true);
$('.checkoutbutton').html('Processing...');
$('.warning').hide();

var data = $("#checkoutform").serializeArray();
var csrf_token = $("input[name=_token]").val();
data.push({name: "_token", value: csrf_token});

$.ajax({
type : 'POST',
url : '/user/checkout_process',
data : $.param(data),
success : function(sonuc){

sonuc = $.trim(sonuc);
             
if (sonuc=="virtual_terminal_issue") {

$('.warning').show();
$('.warning').html('An error occured. Please check your credit card information and try again.');
$('.checkoutbutton').prop('disabled',false);
$('.checkoutbutton').html('Place order');

} else if (sonuc=='ok') {

location.href='/orders';
             
}


}

});

}

});

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\AppServ\www\laravel-dersler\laravel-yenercommerce\resources\views/checkout.blade.php ENDPATH**/ ?>