

<?php $__env->startSection('title'); ?> Wishlist <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="full-row" style="padding: 100px 0">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-md-6 col-lg-5">
                        <div class="text-center">
                            <span class="fa fa-user text-primary" style="font-size: 60px"></span>
                            
                            <p style="font-size: 19px;margin-top: 20px;">You need <a href="<?php echo e(route('signin')); ?>"> Sign-In</a> to add products your wishlist.</p>
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\AppServ\www\laravel-dersler\laravel-yenercommerce\resources\views/wishlist_nosession.blade.php ENDPATH**/ ?>