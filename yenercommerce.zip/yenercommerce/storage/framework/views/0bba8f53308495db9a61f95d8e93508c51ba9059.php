

<?php $__env->startSection('title'); ?> Cart <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<!-- breadcrumb -->
        <div class="full-row bg-light py-5">
            <div class="container">
                <div class="row text-secondary">
                    <div class="col-sm-6">
                        <h3 class="mb-2 text-secondary">Cart</h3>
                    </div>
                    <div class="col-sm-6">
                        
                    </div>
                </div>
            </div>
        </div>
        <!-- breadcrumb -->

        <!--==================== Cart Section Start ====================-->
        <div class="full-row">
            <div class="container">

                <?php if($count_cartproducts==0): ?>

                <p style="font-size: 22px;" align="center"><i class="fa fa-shopping-cart"></i><br>There is no item in your cart yet. <br> <a href="<?php echo e(route('home')); ?>">Keep Shopping</a></p>

                <?php else: ?>

                <div class="row contentt">
                    <div class="col-xl-8 col-lg-12 col-md-12 col-12">
                        <form class="woocommerce-cart-form" action="#" method="post">
                            <table class="shop_table cart">
                                <tr>
                                    <th class="product-thumbnail">&nbsp;</th>
                                    <th class="product-name">Product</th>
                                    <th class="product-price">Unit Price</th>
                                    <th class="product-quantity">Quantity</th>
                                    <th class="product-subtotal">Subtotal</th>
									<th class="product-remove">&nbsp;</th>
                                </tr>


                                <?php

                                $total = 0;

                                ?>


                                <?php $__currentLoopData = $cartproducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cartproduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <?php 
                                
                                $cartproduct_id = $cartproduct->cartproduct_id;
                                $quantity = $cartproduct->product_quantity;
                                $product_id = $cartproduct->product_id;

                                $product = \App\Models\Product::where('product_id','=',$product_id)->first();

                                $brand_name = $product->brand_name;
                                $product_name = $product->product_name;
                                $product_coverimage = $product->product_coverimage;
                                $product_slug = $product->product_slug;

                                if ($product->product_sale=='1') {
                                    
                                $product_price = $product->product_price;

                                } else {

                                $product_price = $product->product_nodiscount_price;

                                }


                                $subtotal = $product_price*$quantity;
                                $total += $subtotal;


                                
 
                                ?>
                             
                                <tr class="woocommerce-cart-form__cart-item cart_item">
                                    <td class="product-thumbnail">
                                        <a target="_blank" href="<?php echo e(route('product_details', ['product_slug' => $product_slug, 'product_id' => $product_id])); ?>"><img src="<?php echo e(asset($product_coverimage)); ?>" alt="Product image"></a>
                                    </td>
                                    <td class="product-name">

                                        <a target="_blank" href="<?php echo e(route('product_details', ['product_slug' => $product_slug, 'product_id' => $product_id])); ?>"><?php echo e($brand_name); ?> <br>

                                        <span style="color: #707070;">

                                        <?php if(strlen($product_name)>50): ?>

                                        <?php echo e(substr($product_name,0,50)); ?>...

                                        <?php else: ?>

                                        <?php echo e($product_name); ?>


                                        <?php endif; ?>

                                        </span>



                                        </a>
                                        
                                    </td>
                                    <td class="product-price">
                                        
                                        <?php if($product->product_sale==1): ?>

                                        <span style="color: #0A327B;"><?php echo e($product_price); ?> USD</span>

                                        <?php else: ?>

                                        <span style="color: #0A327B;"><?php echo e($product->product_nodiscount_price); ?> USD</span>

                                        <?php endif; ?>

                                    </td>
                                    <td class="product-quantity">

                                        <?php if($quantity!=1): ?>

                                        <i style="color: #0A327B;cursor: pointer;" name='minus_<?php echo e($cartproduct_id); ?>' class="fa fa-minus quantityminus"></i>

                                        <?php endif; ?>

                                        <input style="width: 50px;" readonly="" type="number" name="quantity" value="<?php echo e($quantity); ?>">

                                        <?php if($quantity<10): ?>

                                        <i style="color: #0A327B;cursor: pointer;" name='plus_<?php echo e($cartproduct_id); ?>' class="fa fa-plus quantityplus"></i>

                                        <?php endif; ?>

                                        </div>
                                    </td>
                                    <td class="product-subtotal">
                                        <span style="color: #0A327B;"><?php echo e(number_format((float)$subtotal, 2, '.', '')); ?> USD</span>
                                    </td>
									<td class="product-remove">
                                        <a style="cursor: pointer;" name="remove_<?php echo e($cartproduct_id); ?>" class="remove removebtn">×</a>
                                    </td>
                                </tr>


                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                
                            </table>
                        </form>
                    </div>
                    <div class="col-xl-4 col-lg-12 col-md-12 col-12">
                        <div class="cart-collaterals">
                            <div class="cart_totals ">
                                <h2>Cart totals</h2>
                                <table>
                                    <tr>
                                        <th>Subtotal</th>
                                        <td>
                                            <span style="color: #0A327B;font-weight: 500;"><?php echo e(number_format((float)$total, 2, '.', '')); ?> USD</bdi>
                                            </span>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th>Shipping</th>
                                        <td>

                                        

                                        <?php if($total >= $settings->freeshipping): ?>

                                        <?php $shipping_fee = 0; ?>

                                        <?php else: ?>

                                        <?php $shipping_fee = $settings->shipping_fee; ?>

                                        <?php endif; ?>

                                       

                                            <ul>
                                                <li>

                                                                                                        
                                                    <label style="color: #0A327B;font-weight: 500;" for="shipping_method_0_free_shipping1"><?php echo e(number_format((float)$shipping_fee, 2, '.', '')); ?> USD</label>

                                                </li>
                                                
                                            </ul>
                                            
                                        </td>
                                    </tr>
                                    <tr class="order-total">
                                        <th>Total</th>
                                        <td><strong><span class="woocommerce-Price-amount amount"><?php echo e(number_format((float)$total+$shipping_fee, 2, '.', '')); ?> USD</span></strong> </td>
                                    </tr>
                                </table>
                                <div class="wc-proceed-to-checkout">
                                    <a href="<?php echo e(route('checkout')); ?>" class="checkout-button">Checkout</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <?php endif; ?>

            </div>
        </div>
        <!--==================== Cart Section End ====================-->

<?php $__env->stopSection(); ?>


<?php $__env->startSection('extrascript'); ?>

<script type="text/javascript">

//Remove-----------
    
$('.removebtn').click(function(){

$('.contentt').html('<p style="font-size:22px;" align="center">Loading...</p>');

var button = $(this);
var id1=$(this).attr("name");
var cartproduct_id=id1.substring(7);

var data = { 'cartproduct_id':cartproduct_id, '_token': "<?php echo e(csrf_token()); ?>" };

$.ajax({


type : 'POST',
url : '/remove_from_cart',
data : $.param(data),
success : function(sonuc){

sonuc=$.trim(sonuc);
           
$('.contentt').html(sonuc);


 }

 });

});

//Remove End------------------

//Plus Start------------------

$('.quantityplus').click(function(){

var button = $(this);
var id1=$(this).attr("name");
var cartproduct_id=id1.substring(5);

var data = { 'cartproduct_id':cartproduct_id, '_token': "<?php echo e(csrf_token()); ?>" };

$.ajax({


type : 'POST',
url : '/cart_quantity_plus',
data : $.param(data),
success : function(sonuc){

sonuc=$.trim(sonuc);

if (sonuc=='nostock') {

alert('Stock is not enough for that quantity.');

} else {

$('.contentt').html(sonuc);

}


}

 });

});

//Plus End--------------------


//Minus Start------------------

$('.quantityminus').click(function(){

var button = $(this);
var id1=$(this).attr("name");
var cartproduct_id=id1.substring(6);

var data = { 'cartproduct_id':cartproduct_id, '_token': "<?php echo e(csrf_token()); ?>" };

$.ajax({


type : 'POST',
url : '/cart_quantity_minus',
data : $.param(data),
success : function(sonuc){

sonuc=$.trim(sonuc);


$('.contentt').html(sonuc);



}

 });

});

//Minus End--------------------

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\AppServ\www\laravel-dersler\laravel-yenercommerce\resources\views/cart.blade.php ENDPATH**/ ?>