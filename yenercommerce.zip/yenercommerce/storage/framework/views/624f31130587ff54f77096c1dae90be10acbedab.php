

<?php $__env->startSection('title'); ?> Sign-In <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="full-row">
            <div class="container">
                <div class="row">
                    <div class="col">
                        <div class="woocommerce">
                            <div class="row">
                                <div class="col-lg-6 col-md-8 col-12 mx-auto">
                                    <div class="registration-form">
                                        <h3>Sign-In</h3>

                                        <?php if(count($errors)>0): ?> 

                                        <div class="alert alert-warning">

                                        <ul>

                                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                            
                                            <li><?php echo e($error); ?></li>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </ul>

                                        </div>

                                        <?php endif; ?>

                                        <form id="signinform" onsubmit="return false;">

                                           <?php echo csrf_field(); ?>

                                           

                                            <p>
                                                <label for="reg_email">Email address&nbsp;<span class="required">*</span></label>
                                                <input type="email" class="form-control" maxlength="150" name="user_email" id="user_email" />
                                            </p>

                                           
                                            <p>
                                                <label for="reg_email">Password&nbsp;<span class="required">*</span></label>
                                                <input type="password" class="form-control" maxlength="100" name="user_password" id="user_password" />
                                            </p>


                                            

                                            <div style="display: none;" class="alert alert-warning warning"><i class="fa fa-info-circle"></i></div>
                                            
                                            <p>
                                                <button type="submit" class="btn btn-primary rounded-0 signinbtn" value="Sign-In">Sign-In</button>
                                            </p>

                                            <div class="col-md-12 col-xs-12 col-sm-12" align="right">
                                                <a href="<?php echo e(route('forgot_password')); ?>">Forgot Password?</a>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('extrascript'); ?>

<script type="text/javascript">
    
$('#signinform').submit(function(){


 var user_email = $.trim($('#user_email').val());
 var user_password = $('#user_password').val();

 $('.warning').hide();
 $('.signinbtn').html('Signing-In...');

var data = $("#signinform").serializeArray();
var csrf_token = $("input[name=_token]").val();
data.push({name: "_token", value: csrf_token});


$.ajax({


            type : 'POST',
            url : '/user/signin_process',
            data : $.param(data),
            success : function(sonuc){

              sonuc = $.trim(sonuc);



               if (sonuc=='ok') {

              location.href = '/';

              } else if(sonuc=='loginfail') {

                $('.warning').show();
                $('.warning').html("<i class='fa fa-info-circle'></i> Email or password is incorrect.");
                $('.signinbtn').attr('disabled',false);
                $('.signinbtn').html('Sign-In');

              }

         }

 });



});

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\AppServ\www\laravel-dersler\laravel-yenercommerce\resources\views/signin.blade.php ENDPATH**/ ?>