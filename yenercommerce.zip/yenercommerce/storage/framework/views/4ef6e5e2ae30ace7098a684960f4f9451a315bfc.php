<!DOCTYPE html>
<html lang="en">

<?php

 use App\Models\Category;


 if (Auth::guard('user')->check() and $user->user_banned=='1') { ?>
          
 <script>

 window.onload = function(){ document.getElementById('logoutform').submit() }

</script>

 <?php } ?>

 

<head>
    <!-- Meta Tag -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Yener Commerce">

    <meta name="author" content="root">
    
    <title><?php echo $__env->yieldContent('title'); ?> | Yener Commerce</title>

    <!-- Favicon -->
    <link rel="shortcut icon" href="<?php echo e(asset('assets/images/favicon.png')); ?>">

    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css2?family=Jost:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">

    <!--  CSS Style -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/all.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/animate.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/webfonts/flaticon/flaticon.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/owl.carousel.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/jquery.fancybox.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/layerslider.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/template.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/category/optical-shop.css')); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" integrity="sha512-9usAa10IRO0HhonpyAIVpjrylPvoDwiPUiKdWk5t3PyolY1cOd4DSE0Ga+ri4AuTroPR5aQvXU9xC6qOPnzFeg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    
    <?php echo $__env->yieldContent('extralink'); ?>


    <?php echo $__env->yieldContent('extrastyle'); ?>

</head>

<body>

    <div id="page_wrapper" class="bg-light">
        <!--==================== Header Section Start ====================-->
        <header class="ecommerce-header bg-white p-0">
            <div class="top-header d-none d-lg-block py-2 border-0 font-400">
                <div class="container-lg-fluid px-lg-5">
                    <div class="row align-items-center">
                        <div class="col-lg-4 sm-mx-none">
                           
                        </div>
                        <div class="col-lg-8 d-flex">

        

                            <ul class="top-links d-flex ms-auto align-items-center">

                                <?php if(auth()->guard('user')->check()): ?>
                               
                                <li class="my-account-dropdown">
                                    <a style="cursor: pointer;" class="has-dropdown"><i class="flaticon-user-3 flat-mini me-1"></i>Hi, <?php echo e($user->user_name); ?></a>
                                    <ul class="my-account-popup">

                                        <li><a href="<?php echo e(route('my-account')); ?>"><span class="menu-item-text">My Account</span></a></li>
                                        <li><a href="<?php echo e(route('change-password')); ?>"><span class="menu-item-text">Change Password</span></a></li>
                                        <li><a href="<?php echo e(route('cart')); ?>"><span class="menu-item-text">Cart</span></a></li>
                                        <li><a href="<?php echo e(route('orders')); ?>"><span class="menu-item-text">Orders</span></a></li>
                                        <li><a href="javascript:void(0)" onclick=" $('#logoutform').submit(); ">Logout</a></li>

                                        <form id="logoutform" action="<?php echo e(route('userlogout')); ?>" method="POST">
                                            
                                        <?php echo csrf_field(); ?>    

                                        </form>

                                    </ul>
                                </li>

                                <?php endif; ?>

                                <?php if(auth()->guard('user')->guest()): ?>


                                <li class="my-account-dropdown">
                                    <a style="cursor: pointer;" class="has-dropdown"><i class="flaticon-user-3 flat-mini me-1"></i>Sign-In / Sign-Up</a>
                                    <ul class="my-account-popup">

                                        <li><a href="<?php echo e(route('signin')); ?>"><span class="menu-item-text">Sign-In</span></a></li>
                                        <li><a href="<?php echo e(route('signup')); ?>"><span class="menu-item-text">Sign-Up</span></a></li>
                                       
                                    </ul>
                                </li>

                                <?php endif; ?>

                            </ul>
                        </div>
                    </div>
                </div>
            </div>



            <div class="main-nav py-4 d-none d-lg-block">
                <div class="container-fluid px-lg-5">
                    <div class="row">
                        <div class="col-xl-7 col-md-9">
                            <nav class="navbar navbar-expand-lg nav-dark nav-primary-hover nav-line-active">
                                <a class="navbar-brand" href="<?php echo e(route('home')); ?>"><img class="nav-logo" src="<?php echo e(asset('assets/images/logo/12.png')); ?>" alt="Image not found !"></a>
                                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                                <i class="flaticon-menu-2 flat-small text-primary"></i>
                                </button>
                                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                                    <ul class="navbar-nav ms-lg-5">
                                        <li class="nav-item dropdown">
                                            <a class="nav-link" href="<?php echo e(route('home')); ?>">Home</a>


                                            
                                        </li>

                                       <?php $__currentLoopData = $top_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $top_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                       <?php

                                       $category_id = $top_category->category_id;
                                       $category_slug = $top_category->category_slug;
                                       $category_name = $top_category->category_name;
                                       $bottomcategories1 = Category::where('category_top', '=' ,$category_id)->where('category_active','=','1')->orderBy('category_order','ASC')->get();
                                       $bottomcount = count($bottomcategories1); ?>

                                       
                                        <li class="nav-item dropdown mega-dropdown">
                                            <a class="nav-link dropdown-toggle" href="

                                            <?php echo e(route('category_details', ['category_slug' => $category_slug, 'category_id' => $category_id])); ?>


                                            "><?php echo e($category_name); ?></a>

                                 
                                       <?php if($bottomcount!=0): ?>



                                            <ul class="dropdown-menu mega-dropdown-menu">
                                                <li class="mega-container">

                                        
                                        

                                        <div class="row row-cols-lg-4 row-cols-sm-2 row-cols-1">

                                    
                                        <?php $__currentLoopData = $bottomcategories1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <?php

                                        $category_id = $category->category_id;
                                        $category_slug = $category->category_slug;
                                        $category_name = $category->category_name;

                                        $bottomcategories2 = Category::where('category_top', '=' ,$category_id)->where('category_active','=','1')->orderBy('category_order','ASC')->get();

                                        $bottomcount = count($bottomcategories2);

                                        ?>
                                        
                                        <div class="col">
                                         
                                        

                                        <a href="

                                            <?php echo e(route('category_details', ['category_slug' => $category_slug, 'category_id' => $category_id])); ?>


                                            "><span class="d-inline-block px-3 font-600 text-uppercase text-secondary pb-2"><?php echo e($category_name); ?></span></a>

                                        <?php if($bottomcount!=0): ?>

                                        <ul>
                                        
                                        <?php $__currentLoopData = $bottomcategories2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <?php

                                        $category_id = $category->category_id;
                                        $category_slug = $category->category_slug;
                                        $category_name = $category->category_name;

                                        ?>

                                        <li><a class="dropdown-item" href="

                                            <?php echo e(route('category_details', ['category_slug' => $category_slug, 'category_id' => $category_id])); ?>


                                            "><?php echo e($category_name); ?></a></li>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        
                                        </ul>

                                        <?php endif; ?>


                                        </div>

                                   

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                        
                                                        
                                                    </div>

                                         
                                                    
                                                </li>
                                            </ul>
                                      


                                        <?php endif; ?>
                                          

                                        </li>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        <li class="nav-item"><a class="nav-link" href="<?php echo e(route('brands')); ?>">Brands</a></li>
                                       
                                        <li class="nav-item"><a class="nav-link" href="<?php echo e(route('contact')); ?>">Contact</a></li>
                                    </ul>
                                </div>
                            </nav>
                        </div>
                        <div class="col-xl-5 col-md-3">
                            <div class="margin-right-1 d-flex align-items-center justify-content-end h-100">
                                <div class="product-search-one flex-grow-1 global-search touch-screen-view">
                                    <form id="searchform" class="form-inline search-pill-shape" action="<?php echo e(route('search')); ?>" method="GET">
                                        <input id="searchinput" type="text" class="form-control search-field" name="query" placeholder="Product Name, ID, Brand...">
                                        
                                        <button type="submit" class="search-submit"><i class="flaticon-search flat-mini text-white"></i></button>
                                    </form>
                                </div>
                                <div class="search-view d-xxl-none">
                                    <a href="#" class="search-pop top-quantity d-flex align-items-center text-decoration-none">
                                        <i class="flaticon-search flat-mini text-dark mx-auto"></i>
                                    </a>
                                </div>
                                <div class="wishlist-view">
                                    <a href="<?php echo e(route('wishlist')); ?>" class="position-relative top-quantity d-flex align-items-center text-white text-decoration-none">
                                        <i class="flaticon-like flat-mini text-dark mx-auto"></i>
                                    </a>
                                </div>
                                
                                <div class="header-cart-1">
                                    <a href="<?php echo e(route('cart')); ?>" class="cart" title="View Cart">

                                        <div class="cart-icon"><i class="flaticon-shopping-cart flat-mini"></i> <span class="header-cart-count"><?php echo e($count_cart_products); ?></span></div>
                                        
                                    </a>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
        </header>
        <!--==================== Header Section End ====================-->

        <?php echo $__env->yieldContent('content'); ?>

        <!--==================== Footer Section Start ====================-->
        <footer class="full-row bg-white border-footer p-0">
            <div class="container">
                <div class="row row-cols-lg-4 row-cols-sm-2 row-cols-1">
                    <div class="col">
                        <div class="footer-widget mb-5">
                            <div class="footer-logo mb-4">
                                <a href="#"><img src="<?php echo e(asset('assets/images/logo/12.png')); ?>" alt="Image not found!" /></a>
                            </div>
                            <div class="widget-ecommerce-contact">
                                <div class="text-general font-fifteen mt-20">Amazing; products, pricing, service.</div>
                            </div>
                        </div>
                       
                    </div>
                    <div class="col">
                        <div class="footer-widget category-widget mb-5">
                            <h6 class="widget-title mb-sm-4">Top Categories</h6>
                            <ul>
                            
                            <?php $__currentLoopData = $top_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <?php  $category_slug = $category->category_slug; $category_id = $category->category_id; $category_name = $category->category_name;  ?>

                            <li><a href="<?php echo e(route('category_details', ['category_slug' => $category_slug, 'category_id' => $category_id])); ?>"><?php echo e($category_name); ?></a></li>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                            </ul>
                        </div>
                    </div>
                    <div class="col">
                        <div class="footer-widget category-widget mb-5">
                            <h6 class="widget-title mb-sm-4">Pages</h6>
                            <ul>
                                <li><a href="#">About</a></li>
                                <li><a href="<?php echo e(route('contact')); ?>">Contact</a></li>

                            </ul>
                        </div>
                    </div>
                    <div class="col">
                        <div class="footer-widget widget-nav mb-5">

                            <h6 class="widget-title mb-sm-4">SOCIAL</h6>
                             <div class="footer-widget media-widget">



                <?php if(!empty($settings->facebook_link)): ?> <a target="_blank" href="<?php echo e($settings->facebook_link); ?>"><i class="fab fa-facebook-f"></i></a> <?php endif; ?>

                <?php if(!empty($settings->twitter_link)): ?> <a target="_blank" href="<?php echo e($settings->twitter_link); ?>"><i class="fab fa-twitter"></i></a> <?php endif; ?>

                <?php if(!empty($settings->instagram_link)): ?> <a target="_blank" href="<?php echo e($settings->instagram_link); ?>"><i class="fab fa-instagram"></i></a> <?php endif; ?>

                            
                           
                            
                            
                        </div>

                        </div>
                    </div>
                </div>
            </div>
        </footer>
        

        <!--==================== Copyright Section Start ====================-->
        <div class="full-row copyright bg-white py-3">
            <div class="container">
                <div class="row">
                    <div class="col-md-6">
                        <span class="sm-mb-10 d-block"><?php echo e($settings->footertext); ?></span>
                    </div>
                    <div class="col-md-6">
                        <ul class="list-ml-30 d-flex align-items-center justify-content-md-end">
                            <li>
                                <a><img src="assets/images/cards/1.png" alt=""></a>
                            </li>
                            <li>
                                <a><img src="assets/images/cards/2.png" alt=""></a>
                            </li>
                            <li>
                                <a><img src="assets/images/cards/3.png" alt=""></a>
                            </li>
                            <li>
                                <a><img src="assets/images/cards/4.png" alt=""></a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <!--==================== Copyright Section End ====================-->

        <!-- Scroll to top -->
        <a href="#" class="bg-primary text-white" id="scroll"><i class="fa fa-angle-up"></i></a>
        <!-- End Scroll To top -->



    </div>



    <!-- Include Scripts -->
    <script src="<?php echo e(asset('assets/js/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/greensock.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/layerslider.transitions.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/layerslider.kreaturamedia.jquery.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/owl.carousel.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/wow.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/jquery.fancybox.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/jquery.countdown.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/jquery.elevatezoom.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/paraxify.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/custom.js')); ?>"></script>

    

    <!-- Initializing the slider -->
    <script>
        $(document).ready(function() {
            $('#slider').layerSlider({
                sliderVersion: '6.0.0',
                type: 'responsive',
                responsiveUnder: 0,
                maxRatio: 1,
                hideUnder: 0,
                hideOver: 100000,
                skin: 'v6',
                navStartStop: false,
                skinsPath: '/assets/skins/',
                height: 960
            });
        });
    </script>

    <script type="text/javascript">
        
    $('#searchform').submit(function(event){

    var length = $.trim($('#searchinput').val()).length;

    if (length==0) {

    event.preventDefault();

    $('#searchinput').css('border','1px solid #33C6CC');

    }

    });

    </script>

    <?php echo $__env->yieldContent('extrascript'); ?>




</body>

</html>

<!--==================== Footer Section End ====================--><?php /**PATH C:\AppServ\www\laravel-dersler\laravel-yenercommerce\resources\views/layouts/app.blade.php ENDPATH**/ ?>