<?php $__env->startSection('content'); ?>

<div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>
                    <?php if($category_top=='0'): ?>

                    Top Categories

                    <?php else: ?>

                    '<?php echo e($category->category_name); ?>' Sub Categories

                    <?php endif; ?>
                    </h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <a target="_blank" class="btn btn-success" href="<?php echo e(route('admin.add_category', ['category_top' => '0'])); ?>">Add Sub Category +</a>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">



                    


                    <?php if(count($categories)==0): ?>

                    <h4 align="center">Sub-Categories Not Found.</h4>


                    <?php else: ?>

                    <table id="datatable" class="table table-striped table-bordered">
                      <thead>
                        <tr>
                         
                          <th>Category Name</th>
                          <th>Order</th>
                          <th>Status</th>

                          

                          
                          
                         
                          <th></th>
                          
                          
                          
                         
                        </tr>
                      </thead>


                      <tbody>

        

        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoryx): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <?php 

        $category_id = $categoryx['category_id'];
        $category_name = $categoryx['category_name'];
        $category_order = $categoryx['category_order'];
        $category_active = $categoryx['category_active']; 

        ?>

        <tr class="category_<?php echo $category_id; ?>">
                          
                          

        <td><?php echo $category_name; ?></td>
        <td><?php echo $category_order; ?></td>

        <?php if($category_active=='1'): ?>

        <td style="color: green;">Active</td>

        <?php else: ?>

        <td style="color: red;">Not Active</td>

        <?php endif; ?>
                                       
        <td align="right">

        <a class="btn btn-warning btn-sm" href="<?php echo e(route('admin.edit_category', ['category_id' => $category_id])); ?>">Edit</a>

        <a class="btn btn-primary btn-sm" href="<?php echo e(route('admin.categories', ['category_top' => $category_id])); ?>">Sub-Categories</a>

        

        
        </td>



                            

                            

                         </div>
                        
                          
                          
        </tr>
          
       
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        
                        
                        
                      </tbody>
                    </table>


        <?php endif; ?>



                   
                    
                  </div>
                </div>
              </div>

             

              

            </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\AppServ\www\laravel-dersler\laravel-yenercommerce\resources\views/admin/categories.blade.php ENDPATH**/ ?>