

<?php $__env->startSection('title'); ?> My Account <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="full-row">
            <div class="container">
                <div class="row">
                    <div class="col">
                        <div class="woocommerce">
                            <div class="row">
                                <div class="col-lg-6 col-md-8 col-12 mx-auto">
                                    <div class="registration-form">
                                        <h3>My Account</h3>


                                        <form id="updateform" onsubmit="return false;">

                                           <?php echo csrf_field(); ?>
                                         

                                            <p>
                                                <label for="reg_email">Email address&nbsp;<span class="required">*</span></label>
                                                <input type="email" class="form-control" value="<?php echo e($user->user_email); ?>" maxlength="150" name="user_email" id="user_email" />
                                            </p>


                                            <p>
                                                <label for="reg_email">Name&nbsp;<span class="required">*</span></label>
                                                <input type="text" class="form-control" value="<?php echo e($user->user_name); ?>" maxlength="100" name="user_name" id="user_name" />
                                            </p>


                                            <p>
                                                <label for="reg_email">Surname&nbsp;<span class="required">*</span></label>
                                                <input type="text" class="form-control" value="<?php echo e($user->user_surname); ?>" maxlength="100" name="user_surname" id="user_surname" />
                                            </p>

                                        
                                            

                                            <div style="display: none;" class="alert alert-warning warning"><i class="fa fa-info-circle"></i></div>
                                            
                                            <p>
                                                <button type="submit" class="btn btn-primary rounded-0 updatebtn" value="Update">Update</button>
                                            </p>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('extrascript'); ?>

<script type="text/javascript">
    
$('#updateform').submit(function(){


 var user_name = $.trim($('#user_name').val());
 var user_surname = $.trim($('#user_surname').val());
 var user_email = $.trim($('#user_email').val());

 if (user_name.length<2) {

 $('.warning').show();
 $('.warning').html("<i class='fa fa-info-circle'></i> Name field can't be shorter than 2 characters.");

 } else if (user_surname.length<2){

 $('.warning').show();
 $('.warning').html("<i class='fa fa-info-circle'></i> Surname field can't be shorter than 2 characters.");

 } else if (user_email.length<6){

 $('.warning').show();
 $('.warning').html("<i class='fa fa-info-circle'></i> Email field can't be shorter than 6 characters.");

 } else {

 $('.warning').hide();
 $('.updatebtn').attr('disabled',true);
 $('.updatebtn').html('Updating');

 var data = $("#updateform").serializeArray();
 var csrf_token = $("input[name=_token]").val();
 data.push({name: "_token", value: csrf_token});

 
 $.ajax({


            type : 'POST',
            url : '/user/update_process',
            data : $.param(data),
            success : function(sonuc){

            sonuc = $.trim(sonuc);

            if (sonuc=='ok') {

            $('.updatebtn').css('background-color', 'green');
            $('.updatebtn').html('Update is successful!');

            } else if (sonuc=='existmail'){

            $('.warning').show();
            $('.warning').html("<i class='fa fa-info-circle'></i> This email address is already exist.");
            $('.updatebtn').attr('disabled',false);
            $('.updatebtn').html('Update');

            }

              

         }

 });

}

});

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\AppServ\www\laravel-dersler\laravel-yenercommerce\resources\views/my_account.blade.php ENDPATH**/ ?>