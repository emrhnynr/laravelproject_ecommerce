<?php $__env->startSection('content'); ?>


              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Edit Category : <?php echo e($category->category_name); ?></h2>
                    
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <br />

                    

                    <form id="editcategoryform" onsubmit="return false;" data-parsley-validate class="form-horizontal form-label-left">

                    <?php echo csrf_field(); ?>
                      
                     <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Status <span class="required">*</span>
                        </label>
                        <div class="col-md-7 col-sm-7 col-xs-12">
                          
                          <select class="form-control" name="category_active">

                          <option <?php if ($category->category_active=='1') {?> selected='' <?php } ?> value="1">Active</option>
                          <option <?php if ($category->category_active=='0') {?> selected='' <?php } ?> value="0">Not Active</option>

                          </select>

                        </div>
                      </div>


                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Category Name <span class="required">*</span>
                        </label>
                        <div class="col-md-7 col-sm-7 col-xs-12">
                          <input type="text" id="category_name" value="<?php echo e($category->category_name); ?>" maxlength="400" name="category_name"  class="form-control col-md-7 col-xs-12">
                        </div>
                      </div>

                      
                      <input type="hidden" id="kategori_id" value="<?php echo e($category->category_id); ?>" name="category_id">
                      
                      
                      <div class="form-group">
                        
                        <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
                          <div style="display: none;" class="alert alert-warning warning"></div>
                          
                          <button type="submit" class="btn btn-success editbutton">Edit</button>
                        </div>
                      </div>

                    </form>
                  </div>
                </div>
              </div>
            

<?php $__env->stopSection(); ?>

            <?php $__env->startSection('extrascript'); ?>

            <script type="text/javascript">              
              
            $('#editcategoryform').submit(function(){
          
            var category_name = $.trim($('#category_name').val());
        
    
            var form = $('#editcategoryform')[0];
            var data = new FormData(form);

            if (category_name.length==0){

            $('.warning').show();
            $('.warning').html("<i class='fa fa-info-circle'></i> Category name can't be empty.");

            } else {

       
            $('.warning').hide();
            $('.editbutton').prop('disabled',true);
            $('.editbutton').html('Editing...');

            $.ajax({

            type : 'POST',
            url : '/admin/edit_category_process',
            data : $('#editcategoryform').serialize(),
            success : function(sonuc){

            sonuc = $.trim(sonuc);
            
            if (sonuc=="ok") {

            location.reload();
                
            }

            }
        
            });

            }

            });

            </script>

            <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\AppServ\www\laravel-dersler\laravel-yenercommerce\resources\views/admin/edit-category.blade.php ENDPATH**/ ?>