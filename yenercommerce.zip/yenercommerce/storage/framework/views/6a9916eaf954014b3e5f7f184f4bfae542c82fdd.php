

<?php $__env->startSection('title'); ?> Brands <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="full-row" style="padding: 100px 0;background-color: #fff;">
    
    <div class="container">

        <h1 style="font-family: Arial;color: black;" align="center">All Brands<hr></h1>
        
        <div class="row">

            <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <?php

             $brand_id = $brand->brand_id;
             $brand_logo = $brand->brand_logo;
             $brand_slug = $brand->brand_slug;

            ?>
            
            
                <div style="height: 220px;margin-top: 20px;" class="col-md-2 col-sm-2 col-6">
                
                <a href="<?php echo e(route('brand_details', ['brand_slug' => $brand_slug, 'brand_id' => $brand_id])); ?>">

  <div align="center" style="border: 1px solid #e7e7e7;border-radius: 5px;padding: 10px;height: 220px;display: flex;justify-content: center;align-items: center;" class="logo">

                    <img class="img-responsive" src="<?php echo e(asset( $brand_logo )); ?>">  

                    </div>

                </a>

                </div>
            

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>

    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\AppServ\www\laravel-dersler\laravel-yenercommerce\resources\views/brands.blade.php ENDPATH**/ ?>