<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateBrandsTable extends Migration
{
    

    public function up()
    {
        Schema::create('brands', function (Blueprint $table) {

            $table->id('brand_id');
            $table->string('brand_name')->nullable();
            $table->string('brand_slug')->nullable();
            $table->string('brand_logo',330)->nullable();

        });
    }

   
    public function down()
    {
        Schema::dropIfExists('brands');
    }
}
