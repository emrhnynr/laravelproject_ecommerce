<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddPaidToProductimagesTable extends Migration
{
    
    public function up()
    {
        Schema::table('productimages', function (Blueprint $table) {
            
        $table->string('image_path')->nullable();

        });
    }

    
    public function down()
    {
        Schema::table('productimages', function (Blueprint $table) {
           
        });
    }
}
