<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateUsersTable extends Migration
{
    
    public function up()
    {
        Schema::create('users', function (Blueprint $table) {

            $table->id('user_id');
            $table->timestamps();
            $table->string('user_email', 200)->nullable();
            $table->string('user_name', 200)->nullable();
            $table->string('user_surname', 200)->nullable();
            $table->string('user_password', 200)->nullable();
            $table->enum('user_type',['user','admin'])->default('user');
            $table->string('user_activationcode', 200)->nullable();
            $table->enum('user_activated', ['0','1'])->default('0');
            $table->enum('user_seen', ['0','1'])->default('0');
            $table->enum('user_banned', ['0','1'])->default('0');

        });
    }

    
    public function down()
    {
        Schema::dropIfExists('users');
    }
}
