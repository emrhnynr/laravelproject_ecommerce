<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateSettingsTable extends Migration
{
    

    public function up()
    {
        Schema::create('settings', function (Blueprint $table) {

            $table->id();
            $table->string('logo',300)->nullable();
            $table->text('footertext')->nullable();
            $table->string('phonenumber',50)->nullable();
            $table->string('mail')->nullable();
            $table->text('address')->nullable();
            $table->decimal('shipping_fee',10,2)->nullable();
            $table->decimal('freeshipping',10,2)->nullable();
            $table->string('return_code',100)->nullable();
            $table->string('return_namesurname')->nullable();
            $table->text('return_address')->nullable();
            $table->string('instagram_link',400)->nullable();
            $table->string('facebook_link',400)->nullable();
            $table->string('twitter_link',400)->nullable();
            
        });

    }

 
    public function down()
    {
        Schema::dropIfExists('settings');
    }
}
