<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateProductimagesTable extends Migration
{
    
    public function up()
    {
        Schema::create('productimages', function (Blueprint $table) {


            $table->id('image_id');
            $table->biginteger('product_id')->unsigned()->nullable();
            $table->integer('image_order')->unsigned()->nullable();

            $table->foreign('product_id')->references('product_id')->on('products')->onDelete('cascade');
            

        });
    }

    

    public function down()
    {
        Schema::dropIfExists('productimages');
    }
}
