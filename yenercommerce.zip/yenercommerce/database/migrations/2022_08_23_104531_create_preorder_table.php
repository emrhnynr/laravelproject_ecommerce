<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreatePreorderTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('preorder', function (Blueprint $table) {

            $table->id('preorder_id');
            $table->timestamps();
            $table->biginteger('user_id')->unsigned()->nullable();
            $table->biginteger('cartproduct_id')->unsigned()->nullable();
            $table->decimal('product_price',10,2)->nullable();

            $table->foreign('user_id')->references('user_id')->on('users')->onDelete('cascade');
            $table->foreign('cartproduct_id')->references('cartproduct_id')->on('cartproducts')->onDelete('cascade');           

        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('preorder');
    }
}
