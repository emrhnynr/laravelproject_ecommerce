<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateOrderproductsTable extends Migration
{
    
    public function up()
    {
        Schema::create('orderproducts', function (Blueprint $table) {

            $table->id('orderproduct_id');
            $table->timestamps();
            $table->biginteger('user_id')->unsigned()->nullable();
            $table->biginteger('order_id')->unsigned()->nullable();
            $table->integer('product_quantity')->unsigned()->nullable();
            $table->decimal('product_price',10,2)->nullable();
            $table->decimal('product_total',10,2)->nullable();

            $table->foreign('user_id')->references('user_id')->on('users')->onDelete('cascade');
            $table->foreign('order_id')->references('order_id')->on('orders')->onDelete('cascade');


        });
    }

    
    public function down()
    {
        Schema::dropIfExists('orderproducts');
    }
}
