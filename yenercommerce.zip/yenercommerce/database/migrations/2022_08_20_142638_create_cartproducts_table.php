<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateCartproductsTable extends Migration
{
    
    public function up()
    {
        Schema::create('cartproducts', function (Blueprint $table) {

            $table->id('cartproduct_id');
            $table->timestamps();
            $table->biginteger('user_id')->unsigned()->nullable();
            $table->biginteger('product_id')->unsigned()->nullable();
            $table->integer('product_quantity')->nullable();

            $table->foreign('user_id')->references('user_id')->on('users')->onDelete('cascade');
            $table->foreign('product_id')->references('product_id')->on('products')->onDelete('cascade');

        });
    }

    
    public function down()
    {
        Schema::dropIfExists('cartproducts');
    }
}
