<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateCitiesTable extends Migration
{
    
    public function up()
    {
        Schema::create('cities', function (Blueprint $table) {

            $table->id('city_id');
            $table->string('city_name')->nullable();

        });
    }

    
    public function down()
    {
        Schema::dropIfExists('cities');
    }
}
