<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateOrdersTable extends Migration
{
    
    public function up()
    {
        Schema::create('orders', function (Blueprint $table) {

            $table->id('order_id');
            $table->timestamps();
            $table->biginteger('user_id')->unsigned()->nullable();
            $table->string('order_firstname')->nullable();
            $table->string('order_lastname')->nullable();
            $table->string('order_phonenumber',50)->nullable();
            $table->string('order_location')->nullable();
            $table->string('order_mail')->nullable();
            $table->text('order_address')->nullable();
            $table->decimal('order_subtotal',10,2)->nullable();
            $table->decimal('order_shipping_fee',10,2)->nullable();
            $table->decimal('order_interest_rate',3,2)->nullable();
            $table->decimal('order_interest',10,2)->nullable();
            $table->decimal('order_total',10,2)->nullable();
            $table->enum('order_status',['preparing','onshipping','delivered'])->default('preparing');
            $table->text('order_note')->nullable();
            $table->enum('order_seen',['0','1'])->default('0');

            $table->foreign('user_id')->references('user_id')->on('users')->onDelete('cascade');



        });
    }

   
    public function down()
    {
        Schema::dropIfExists('orders');
    }
}
