<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateProductfeaturesTable extends Migration
{
    
    public function up()
    {
        Schema::create('productfeatures', function (Blueprint $table) {


            $table->id('feature_id');
            $table->biginteger('product_id')->unsigned()->nullable();
            $table->string('feature_title')->nullable();
            $table->string('feature_content')->nullable();

            $table->foreign('product_id')->references('product_id')->on('products')->onDelete('cascade');
            

        });
    }

    
    public function down()
    {
        Schema::dropIfExists('productfeatures');
    }
}
