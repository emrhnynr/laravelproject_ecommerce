<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateCategoryproductsTable extends Migration
{
    
    public function up()
    {
        Schema::create('categoryproducts', function (Blueprint $table) {

            $table->id('categoryproducts_id');
            $table->biginteger('category_id')->unsigned()->nullable();
            $table->biginteger('product_id')->unsigned()->nullable();

            $table->foreign('category_id')->references('category_id')->on('categories')->onDelete('cascade');
            $table->foreign('product_id')->references('product_id')->on('products')->onDelete('cascade');
           
        });
    }

    public function down()
    {
        Schema::dropIfExists('categoryproducts');
    }
}
