<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateHomelistTable extends Migration
{
    
    public function up()
    {
        Schema::create('homelist', function (Blueprint $table) {

            $table->id('list_id');
            $table->integer('list_order')->unsigned()->nullable();
            $table->string('list_name')->nullable();

        });
    }

    
    public function down()
    {
        Schema::dropIfExists('homelist');
    }
}
