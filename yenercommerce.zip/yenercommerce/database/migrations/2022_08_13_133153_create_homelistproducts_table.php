<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateHomelistproductsTable extends Migration
{
    
    public function up()
    {
        Schema::create('homelistproducts', function (Blueprint $table) {

            $table->id();
            $table->biginteger('list_id')->unsigned()->nullable();
            $table->biginteger('product_id')->unsigned()->nullable();

            $table->foreign('list_id')->references('list_id')->on('homelist')->onDelete('cascade');
            $table->foreign('product_id')->references('product_id')->on('products')->onDelete('cascade');

        });
    }

    
    public function down()
    {
        Schema::dropIfExists('homelistproducts');
    }
}
