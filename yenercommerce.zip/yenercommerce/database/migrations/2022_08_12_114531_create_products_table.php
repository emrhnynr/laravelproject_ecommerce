<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateProductsTable extends Migration
{
   

    public function up()
    {
        Schema::create('products', function (Blueprint $table) {

            $table->id('product_id');
            $table->timestamps();
            $table->string('product_name',300)->nullable();
            $table->string('product_slug',330)->nullable();
            $table->text('product_description')->nullable();
            $table->string('product_coverimage',300)->nullable();
            $table->decimal('product_price',10,2)->nullable();
            $table->decimal('product_nodiscount_price',10,2)->nullable();
            $table->integer('product_stock')->unsigned()->nullable();
            $table->integer('brand_id')->unsigned()->nullable();
            $table->string('brand_name',120)->nullable();
            $table->integer('category_id')->unsigned()->nullable();
            $table->enum('product_sale', ['0','1'])->nullable();
            $table->string('product_video')->nullable();


        });
    }

    
    public function down()
    {
        Schema::dropIfExists('products');
    }
}
