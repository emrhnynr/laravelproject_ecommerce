<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\ContactController;
use App\Http\Controllers\CategoryController;
use App\Http\Controllers\BrandController;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\AdminController;


Route::fallback(function(){

return view('404');

});

//Admin Panel Start ---------------

Route::get('/admin', [AdminController::class, 'home'])->name('admin.home');
Route::get('/admin/sign-in', [AdminController::class, 'signin'])->name('admin.signin');
Route::post('/admin/signin_process', [AdminController::class, 'signin_process'])->name('admin.signin_process')->middleware('guest:admin');

Route::group(['prefix' => '/admin','middleware' => ['auth:admin']], function() {

Route::post('/adminlogout', [AdminController::class, 'adminlogout'])->name('admin.adminlogout');
Route::get('/general-settings', [AdminController::class, 'general_settings'])->name('admin.general_settings');
Route::post('/general_settings_process', [AdminController::class, 'general_settings_process'])->name('admin.general_settings_process');
Route::get('/add-category/{category_top}', [AdminController::class, 'add_category'])->name('admin.add_category');
Route::get('/categories/{category_top}', [AdminController::class, 'categories'])->name('admin.categories');
Route::get('/edit-category/{category_id}', [AdminController::class, 'edit_category'])->name('admin.edit_category');
Route::post('/edit_category_process', [AdminController::class, 'edit_category_process'])->name('admin.edit_category_process');

});


//Admin Panel End -----------------


Route::get('/', [HomeController::class, 'home'])->name('home');

Route::prefix('/contact')->group(function(){

Route::get('/', [ContactController::class, 'contact'])->name('contact');
Route::POST('/submitcontactform', [ContactController::class, 'submitcontactform'])->name('submitcontactform');

});


Route::prefix('/category')->group(function(){

Route::get('/{category_slug}/{category_id}', [CategoryController::class, 'category_details'])->name('category_details');

});

Route::prefix('/brands')->group(function(){

Route::get('/', [BrandController::class, 'brands'])->name('brands');
Route::get('/{brand_slug}/{brand_id}', [BrandController::class, 'brand_details'])->name('brand_details');

});	


Route::prefix('/product')->group(function(){

Route::get('/{product_slug}/{product_id}', [ProductController::class, 'product_details'])->name('product_details');

});




Route::get('/search', [ProductController::class, 'search'])->name('search');

Route::get('/sign-in', [UserController::class, 'signin'])->name('signin')->middleware('guest:user');
Route::get('/sign-up', [UserController::class, 'signup'])->name('signup')->middleware('guest:user');
Route::get('/forgot-password', [UserController::class, 'forgot_password'])->name('forgot_password')->middleware('guest:user');
Route::get('/reset-password/{user_forgotcode}', [UserController::class, 'reset_password'])->name('reset_password')->middleware('guest:user');
Route::get('/orders', [UserController::class, 'orders'])->name('orders')->middleware('auth:user');
Route::get('/order/{order_id}', [UserController::class, 'order_details'])->name('order_details')->middleware('auth:user');

Route::get('/my-account', [UserController::class, 'my_account'])->name('my-account')->middleware('auth:user');
Route::get('/change-password', [UserController::class, 'change_password'])->name('change-password')->middleware('auth:user');
Route::post('/userlogout', [UserController::class, 'userlogout'])->name('userlogout')->middleware('auth:user');


Route::get('/cart', [UserController::class, 'cart'])->name('cart');
Route::post('/remove_from_cart', [UserController::class, 'remove_from_cart'])->name('remove_from_cart');
Route::post('/cart_quantity_plus', [UserController::class, 'cart_quantity_plus'])->name('cart_quantity_plus');
Route::post('/cart_quantity_minus', [UserController::class, 'cart_quantity_minus'])->name('cart_quantity_minus');

Route::get('/checkout', [UserController::class, 'checkout'])->name('checkout');

Route::get('/wishlist', [UserController::class, 'wishlist'])->name('wishlist');

Route::post('/select_city', [UserController::class, 'select_city'])->name('select_city');
Route::post('/change_installment', [UserController::class, 'change_installment'])->name('change_installment');



Route::prefix('/user')->group(function(){

Route::post('/signup_process', [UserController::class, 'signup_process'])->name('user.signup_process')->middleware('guest:user');
Route::post('/signin_process', [UserController::class, 'signin_process'])->name('user.signin_process')->middleware('guest:user');
Route::post('/update_process', [UserController::class, 'update_process'])->name('user.update_process')->middleware('auth:user');
Route::post('/checkout_process', [UserController::class, 'checkout_process'])->name('user.checkout_process')->middleware('auth:user');
Route::post('/change_password_process', [UserController::class, 'change_password_process'])->name('user.change_password_process')->middleware('auth:user');
Route::post('/forgot_password_process', [UserController::class, 'forgot_password_process'])->name('user.forgot_password_process')->middleware('guest:user');
Route::post('/reset_password_process', [UserController::class, 'reset_password_process'])->name('user.reset_password_process')->middleware('guest:user');
Route::post('/add_to_wishlist_process', [UserController::class, 'add_to_wishlist_process'])->name('user.add_to_wishlist_process')->middleware('auth:user');
Route::post('/add_to_cart_process', [UserController::class, 'add_to_cart_process'])->name('user.add_to_cart_process');
Route::post('/remove_from_wishlist_process', [UserController::class, 'remove_from_wishlist_process'])->name('user.remove_from_wishlist_process')->middleware('auth:user');
Route::post('/remove_from_wishlist_table_process', [UserController::class, 'remove_from_wishlist_table_process'])->name('user.remove_from_wishlist_table_process')->middleware('auth:user');

});